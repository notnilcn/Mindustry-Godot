<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H07 — Audio + weather: session 4 summary (2026-10-14)

Executor: DeepSeek V4.1 Flash. Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session4`,
branch `parity/session-4`, bridge 7000, display :13. Cross-plan rules: `H-environment.md` §1-6.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T1 voice policy | done (unit tests + in-engine `active_voice_counts`) | `9604cf09` |
| T2 block action sounds | done (unit tests + in-engine factory events) | `848d609d` |
| T3 mech/floor steps | done (unit tests + in-engine walking dagger) | `bed7e4b5` |
| T4 bullet/ability sounds | done (unit tests + in-engine duo events; abilities headless) | `e414cac9` |
| T5 addWeather + create_weather | done (7 unit tests + fresh Frozen Forest + Ground Zero resume) | `961a26b0` |
| T6 weather draw (particles/rain/splashes) | done (7 unit tests + rain/snow/sandstorm/off screenshots) | `7b6d93ec` |
| T7 weather noise layers | done (2 unit tests + fog veil/drift pixel checks) | `c4f354be` |
| T8 Arc rawNoise | done (2 unit tests; in-engine covered by T6's windHowl loop) | `d2f3dabd` |
| T9 weather env attrs (SolidPump) | done headless-only (optional in-engine skipped per plan) | `71a59006` |
| T10 menu/launch/editor music | done (unit test + full in-engine track readbacks) | `2c2c5975` |
| T11 continuous-weapon SoundLoop | done headless-only (in-engine optional per plan) | `0be9c49c` |
| T12 in-engine re-verification | done, **no commit** (build beam + payload + weather loops) | — |
| T13 sandstorm wind displacement | skipped: waiting for H01 T4 (`entities/comp/unit/velocity.rs`/`move_at` absent; H01 T4 not on main either) | — |

Extra (unplanned, blocker fix committed separately): `8a39f6fc` — save resume overflow fix.

`git log --oneline main..HEAD`:

```
0be9c49c Gameplay H07 T11: continuous-weapon SoundLoop (vela, navanax)
2c2c5975 Fixes PAR-0072: menu/planet-launch/editor music selection
71a59006 Gameplay H07 T9: weather water/spores env attributes reach SolidPump (Attribute.env)
d2f3dabd Gameplay H07 T8: Arc 1-D Perlin rawNoise for the weather sound oscillator
c4f354be Fixes PAR-0127: weather noise layers (fog, sandstorm, sporestorm) complete the weather draw
7b6d93ec PAR-0127: draw live weather (particles, rain, splashes) on the weather/debris bands
961a26b0 Fixes PAR-0203: PlanetGenerator.addWeather for fresh sectors
bed7e4b5 Gameplay H07 T3: mech step and floor walk sounds
e414cac9 Gameplay H07 T4: bullet hit/despawn pitch range, bullet heal sound, ability sounds
8a39f6fc Save resume: ItemModule.total wraps like Java when reading saves
848d609d Gameplay H07 T2: block action sounds (unit create, mender, doors, mass drivers, force projector, payload void)
9604cf09 Gameplay H07 T1: one-shot voice policy (checkFrame intensify, SoundPriority admission, falloff offset)
```

## Tests (exact commands, last run after T11)

From `WT/client/rust`:

```
CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock cargo test -p mind-core --lib --features msav-import
  -> 2351 passed / 0 failed / 4 ignored
CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock cargo test -p mind-headless --lib
  -> 132 passed / 0 failed
CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock cargo test -p mind-gdext --lib
  -> 36 passed / 0 failed
CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock cargo run -q -p mind-headless -- parity goldens
  -> 0 FAIL lines
CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings
  -> clean; cargo fmt clean. No GDScript/`.tscn` edits, parse gate not applicable.
```

Baseline before H07 on this branch: 2202 (main @ ffbe84dd). New tests added: 4 (T1) + 6 (T2) + 4 (T3) + 4 (T4) + 7 (T5) + 7 (T6) + 2 (T7) + 2 (T8) + 1 (T9) + 1 (T10) + 1 (T11) + 1 (save fix). No golden was regenerated (the audio/events_sim.json snapshot does not contain the affected bullets).

## In-engine evidence

All under `REPO/runs/` (shared symlink; never committed):

* `20261014-s4-H07-T1/` — 10 duos + 10 copper item-sources + team-2 wall targets: `active_voice_counts()["shootDuo"]` peaked at **2** (<= 6) over 12 samples, 9-19 bullets in flight, `drain_log []`. `evidence.json`, `H07-T1-ten-duos-firing.png`.
* `20261014-s4-H07-T2/` — ground-factory (137,64) + power-source (139,64), plan 0: dagger appears at (1096,512), `events_applied 17 -> 18`, `drain_log []`. (First fixture at (142,70) produced units that die instantly: tile (142,70) is outside the unit map-area kill boundary — manual spawns there vanish too.)
* `20261014-s4-H07-T3/` — team-1 dagger (1120,520) ordered to (1040,560), paused `step(40)`: `events_applied 7 -> 9 -> 11` while positions move (1073,543)->(1057,551)->(1044,558).
* `20261014-s4-H07-T4/` — item-source -> duo -> team-2 wall: `events_applied 9 -> 25`, `drain_log []` (ability sounds headless-only).
* `20261014-s4-H07-T5/` — fresh Frozen Forest (64): `weather_json` = `snowing` (72000/216000/18000/54000); Ground Zero resume keeps `{"entries":[],"active":[]}`. Clean `rm -rf $U` + `--import` run after (profile mutation per plan).
* `20261014-s4-H07-T6/` — `rain.png` (blue diagonal streaks), `snow.png` + `snow-dark.png` (white flakes; `windHowl` loop = 1), `sandstorm.png` (tan haze), `rain-wide.png`, `rain-off.png` (`showweather=false` hides everything). `evidence.json`.
* `20261014-s4-H07-T7/` — fog over the dark terrain (`fog-dark-1/2.png`, drifting), on/off pixel check (mean |diff| 19.3; pixel (200,200) 196,202,208 -> 224,232,240), `sandstorm.png`. `evidence.json`.
* `20261014-s4-H07-T10/` — menu `current_track()=="menu"` (playing), planet dialog `"launch"`, close `"menu"`, editor `"editor"` (`editor_ui_visible true`), Ground Zero `""` within 4 s. `evidence.json`.
* `20261014-s4-H07-T12/` — `loop_voice_count("loopBuild")==1`, `loop_volume 0.098`, plan progress 0.875; payload pickup/drop `events_applied 1 -> 2 -> 5`; `loop_voice_count("rain")==1`, `loop_volume 0.0188`, `drain_log []`. `evidence.json`.
* Every run end: newest session log `grep -c panic` = 0.

## Deviations from Java

* T1: Java records `lastVolume`/`lastTimePlayed` before `sourcePlayBus` (a SoLoud-denied play still records); the port records only on a successful Play/Replace (`priority.rs` `plan_one_shot` doc).
* T2: payload mass driver receive sound plays at transfer time instead of 11 ticks later (`effectDelayTimer`; the port has no receive-effect branch) — `payload_mass_driver.rs` site comment.
* T2: `emit_world_sound`'s pitch RNG is a new view-only `AudioViewRng` (Fx stream); Java's `Mathf.range` is the unseeded global. `building_centre_of(world, e)` reads the `BlockTable` instead of taking a `ContentRegistry` (behaviors have no content handle at `update_tile`).
* T3: `inFogTo` step gating not applied (fog is H03); `floor.walkEffect` is H03's (comment left at `steps.rs`).
* T4: the Fx pitch draw is skipped for `none`/`unset` bullets (keeps the view stream minimal; Java draws anyway from its unseeded RNG).
* T5: tie-break by block id ascending (Java `ObjectIntMap` hash order unspecified); sector-circle darkness term omitted (needs Arc 2-D `Noise`); `WeatherEntry.cooldown = minFrequency` instead of `Mathf.random(min,max)` (`weather_system` re-rolls it on PlayEvent).
* T6: `showweather` — the imported profile ships `false` (data); the renderer honors it. Camera zoom 4.0 -> the field sized from `minScale` 1.5 yields the Java-visible subset (like Java).
* T7: the Noise pass reads the weather def directly because `fog` has no `WeatherFx` (`drawParticles=false`); `build_noise_layers` stays for the scorching env pass.

## Blockers

1. **T13 skipped**: `entities/comp/unit/velocity.rs` (`move_at`/`move_pref`/`impulse`/`vel_update`, H01 T4) is absent on this branch and on `main`; the plan's "skipped: waiting for H01 T4" applies.
2. **Final `git merge --no-edit main` conflicts** in `client/rust/mind-core/src/world/building_io.rs` (main's save-path changes overlap the `ItemModule.total` wrapping fix from `8a39f6fc`). Aborted per the session rules; the coordinator should carry that one-line `wrapping_add` fix forward when merging (see ledger note below).
3. **Pre-H07 profile save was unreadable** (`building_io.rs:402` overflow) until `8a39f6fc`; the poisoned old saves are set aside in `/tmp/opencode/s4-poisoned-save/`. Unplanned but blocking: every sector resume panicked before the fix.
4. `(142,70)` on Ground Zero is outside the unit map-area kill boundary (units spawn and die instantly there); documented in the T2 evidence, not an H07 bug.

## Ledger changes to apply (plan §4, expanded)

* `PAR-0203` -> **verified** (T5): 7 planet.rs unit tests + fresh Frozen Forest `snowing` 72000/216000/18000/54000; note the sector-circle darkness omission.
* `PAR-0127` -> **verified** (T6+T7): screenshots rain/snow-dark/sandstorm/fog-dark + on/off pixel checks; `windHowl` loop live. Note: natural weather now needs a fresh sector (T5); Ground Zero resume stays `[]`. The imported profile has `showweather=false`.
* `PAR-0072` -> **verified** (T10): menu/launch/editor `current_track` readbacks + the `launch_in_planet_dialog_crossfades_from_menu` test.
* `PAR-0202` -> **still open**: T13 skipped, re-run in wave 3 after H01 T4.
* `PAR-0071` / `PAR-0205` -> add T12 in-engine notes (build-beam voice + volume, payload pickup/drop events, rain loop).
* New items to file (all **verified** by their task):
  * "Every gun overlaps: no checkFrame intensify / no per-sound voice limit / no falloff offset" (T1).
  * "Unit factory, reconstructor, mender, door, mass driver, force-projector and payload-void sounds missing" (T2).
  * "Mech step and floor walk (water/mud) sounds missing" (T3).
  * "Bullet hit/despawn pitch never varies; heal bullets and unit abilities silent" (T4).
  * "Snow wind-howl volume uses the wrong noise function" (T8).
  * "Rain/sporestorm env attributes ignored by the water extractor (Attribute.env)" (T9; AttributeCrafter half -> H02 via `env_attr`).
  * "Continuous-weapon beam loop sound (vela/navanax) missing" (T11).
  * (new, from the blocker fix) "Sector saves cannot be resumed: fillItems item totals overflow i32 in the save reader" — fixed by `8a39f6fc` (suggested id; no PAR id existed).
