<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J02 — Terrain, floor and menu-background rendering

**Goal.** The floor layer draws exactly what `Floor.drawBase` draws: edge blending, autotiled
and tiled floors, liquid-over-overlay alpha. Map previews and the minimap colour every tile like
`MapIO`. The main-menu background matches `MenuRenderer`.

**Evidence.** Twin report F2, F12 (preview colours), F14; frames `diff/46-edges-zoom.png`
(sand/stone boundary), `diff/11-core-zoom.png` (core-zone stripes), `diff/09-custom-side.png`
and `diff/10-mapplay-side.png` (scrap circle), `diff/00-menu-side.png`.

**Depends on.** Nothing. The editor renderer (`mind-gdext/src/editor/editor_renderer.rs`) shares
`tile_quads`, so T1/T2 fix both views. Re-run the PAR-0109 editor frames afterwards.

## T1 — Floor edge blending (`Floor.drawEdges` / `drawNonLayer` / `drawBlended`) — HIGH

- Java (`world/blocks/environment/Floor.java`):
  - `drawBase` = `drawMain`, then `drawEdges` if `drawEdgeIn`, then `drawOverlay`, then the
    liquid-overlay alpha pass (`:249-262`).
  - `drawEdges` gathers, per d8 neighbour, the floor or overlay `ob` with `ob.drawEdgeOut`,
    `doEdge` (`ob.realBlendId(other) > realBlendId(tile)`), the same `cacheLayer` and non-null
    `edges`. `drawBlended` then sorts blenders by id (the tile's own floor last) and draws
    `edge(x, y, 1 - dx, 1 - dy)` from the 3x3 split of `<blendGroup>-edge` (`:363-424`,
    `edges` split at `:171-180`).
  - `drawNonLayer` draws edges of floors on *other* cache layers (water edges over shallow etc.)
    from `FloorRenderer` (`:343-361`, `graphics/FloorRenderer.java:325`).
  - `realBlendId` packs overlay and floor ids for liquid floors with non-ore overlays (`:407-414`).
- Port: `tile_quads` (`mind-gdext/src/render/floor.rs:489-560`) emits only the base, overlay and
  wall quads. There are no `-edge` lookups and no blend ids. The content model also lacks
  `drawEdgeIn`, `drawEdgeOut`, `blendId`/`blendGroup` resolution and `canShadow`
  (`J-field-audit.tsv`, row `Floor.java`).
- Change:
  1. Add `blend_group`/`blend_id`/`draw_edge_in`/`draw_edge_out` to the floor def. Defaults
     per Java: `blendGroup = this`, `blendId = blendGroup.id`, both edge flags true. Carry the
     overrides from `Blocks.java` (e.g. `crater-stone` → `blendGroup = stone`, `Blocks.java:352`) and from the mod parser.
  2. Port `doEdge`/`realBlendId`/`drawBlended` into `mind-core::render` as a pure function that
     returns the ordered edge quads for a tile. Unit-test it against hand-computed Java output for
     sand|stone, core-zone|stone and water|sand corners.
  3. Emit the edge quads in `tile_quads` for the tile's own cache layer, and in the
     `drawNonLayer` pass for other layers. Invalidate the 3x3 neighbourhood on tile change (the
     chunk rebuild already exists).
- Accept: a Godot capture of the Ancient Caldera crop matches `java/46-conv-sel.png`
  (`diff/46-edges-zoom.png` left half). The sandbox core shows core-zone stripes as in
  `diff/11-core-zoom.png`. Then re-check the PAR-0109 editor frames.
- Ledger: new item "Floor transitions render as hard tile edges (no Floor.drawEdges)".

## T2 — Autotiled, tiled and liquid-overlay floors (`Floor.drawMain`) — MEDIUM

- Java `drawMain` (`Floor.java:264-292`) has three branches:
  1. `tilingVariants > 0`: a `tilingSize` square of regions chosen per block of tiles.
  2. `autotile`: an 8-neighbour bitmask through `TileBitmask.values`, with
     `autotileVariants`/`autotileMidVariants`. Vanilla `metal-tiles-1..10`, `dark-panel-*`
     variants and `dark-metal` set `autotile = true`, two with mid-variants
     (`Blocks.java:843-897`).
  3. The plain random variant.

  `drawBase` also redraws a liquid floor at `1 - overlayAlpha` over its overlay (`:257-261`;
  `overlayAlpha = 0.35f` at `Blocks.java:300`).
- Port: floors always use the variant branch. `TileBitmask` exists in
  `mind-core/src/render/tile_bitmask.rs` / `world/blocks/tile_bitmask.rs`, but only walls use it
  (`blocks.rs`).
- Change: add the autotile and tiling branches to the floor quad builder, reusing the bitmask
  table. Add the liquid-overlay alpha re-draw.
- Accept: a map with metal tiles (e.g. a shipped Serpulo preset with `metal-tiles-*`) matches a
  fresh Java capture. A `mind-core` test pins the bitmask → region index for the 47-case table.

## T3 — Preview and minimap colours = `MapIO.colorFor` — HIGH (open since round I)

- Java `MapIO.colorFor(floor, wall, overlay, team)` (`io/MapIO.java:229-237`):
  - `overlay.wallOre` → overlay colour.
  - solid wall → wall colour.
  - `!overlay.useColor` → floor colour.
  - Otherwise a non-`OverlayFloor` overlay is blended at alpha 128 over the floor, and an
    `OverlayFloor` uses its own colour.

  `OreBlock` sets `mapColor = ore.color` and `useColor = true` (`OreBlock.java:22-33`). Minimap
  tiles use `Block.minimapColor` (`MapIO.java:169-174,220-244`).
- Port: `mind-core/src/io/map/preview.rs:186-191` approximates `useColor` by `has_color`
  ("`Floor.useColor` is not ported yet"). Ores whose `mapColor` comes from the item colour (scrap)
  fall back to the floor colour. The live minimap (`mind-gdext/src/render/minimap.rs`) shares the
  gap: the sandbox scrap circle is missing in both.
- Change: add `use_color` to block defs (`Block.java` default false, `OreBlock` true, plus any
  Blocks.java overrides). Set ore `map_color` from the item colour at content build. Port
  `colorFor` exactly and use it in the previews, the minimap texture and editor previews.
- Accept: the sandbox preview, Map Play preview and in-game minimap show the grey scrap circle
  (`java/09-custom.png`, `java/11-sandbox.png`). The preview cache version bumps
  (`*_v2.png` → `_v3`) so stale caches regenerate.
- Ledger: PAR-0114 → fixing (scrap ore). Close it together with J01 T2.

## T4 — Menu background = `MenuRenderer` — MEDIUM

- Java `MenuRenderer` (`graphics/MenuRenderer.java`):
  - generates a random world (already ported in `mind-gdext/src/render/menu.rs`).
  - `cache()` (`:169-208`) draws a shadow framebuffer (black 1x1 per wall tile), floors with
    `drawBase` (so edges, via T1), overlays, then walls.
  - `render()` (`:211-239`) is a static camera scaled to cover the screen. It draws the floor
    cache, the shadow texture offset by (-4,-4) world units, the wall cache, `drawFlyers()`, then
    the `darkness` overlay.
  - `drawFlyers` (`:241-262` + `flyers()`) moves `flyers` copies (`Mathf.chance(0.2) ?
    random(35) : random(15)`) of one random type from `{flare, horizon, zenith, mono, poly, mega,
    alpha, beta, gamma}` at `flyerRot = 45` across the view with `drawShadow` + `draw`.
- Port: `client/ui/menu_background.gd` shows one baked `Texture2D` from
  `MindRender.build_menu_texture`. `menu.rs` already tracks `flyers()`, the rotation and the clock,
  but nothing draws them, and the bake has no shadow layer.
- Change:
  1. Bake the shadow layer into the texture (or draw it as a second rect).
  2. Add a `MenuFlyers` node under `Ui/MenuBackground` that draws the flyer sprites and their
     shadows each frame from `menu.rs` positions. Use the unit draw from J03, or the unit's full
     icon as an interim step, and record that as a deviation until J03 lands.
- Accept: side by side with `java/00-menu.png`, walls cast shadows and a flyer squadron crosses
  the screen.

## T5 — Static wall shadows/darkness check — LOW

- After T1, re-capture the Ground Zero and Caldera wall edges against Java. `BlockRenderer`'s
  wall shadow pass (`graphics/BlockRenderer.java`, `shadowEvents`) and `TallBlock.shadowOffset`
  (missing field in the audit) should match. Fix any residual or record it.

## Done criteria

T1–T4 landed. The Caldera crop, sandbox core, sandbox preview/minimap and main menu frames match
the twin-run Java frames. A summary is in `docs/J02-terrain-rendering_summary.md`.
