<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J07 — Planet page rendering and campaign residuals

**Goal.** The planet page draws what `PlanetRenderer` draws (orbits, atmosphere, clouds, framing),
the tech tree presents sector nodes like Java, and the campaign blocks and rules that are still
stubs get their Java behaviour.

**Evidence.** Twin report rows 02-03, 40 and F13; frames `diff/02-planet-side.png`,
`diff/03-sector-side.png`, `diff/tmp-side.png` (planet after Back), `diff/40-tech-side.png`.
Ledger PAR-0296 (Accelerator stub, `seeded`).

**Note.** The two profiles differ: the Java profile has the full tech tree, Godot has 282/375
unlocks. Before comparing frames, set the Godot unlock state to match: import the operator's
zip on a throwaway profile, never on the Java one.

## T1 — Orbit lines (`PlanetRenderer.renderOrbit`) — MEDIUM

- Java: `renderTransparent` (`graphics/g3d/PlanetRenderer.java:146-169`) ends with
  `renderOrbit` when `params.drawUi`. `renderOrbit` (`:171-179`) draws a `lineLoop` of
  `points = radius * 10` around `planet.parent.position` at `orbitRadius`, colour `Pal.gray` with
  `alpha = params.uiAlpha`, skipped when `!planet.drawOrbit`. This is the grey arc crossing the
  Java frame (`java/02-planet.png`, upper left).
- Port: `ui/planet_view.gd` + `MindCampaign` planet payload (`mind-gdext/src/campaign.rs:5261-5272`)
  carry the atmosphere data but no orbit.
- Change: add the orbit radius, parent position and `drawOrbit` to the planet payload. Draw it
  as an `ImmediateMesh` line loop in the planet `SubViewport` with the same camera.

## T2 — Atmosphere, clouds and camera framing — MEDIUM

- Java:
  - `planet.drawAtmosphere(atmosphere, cam)` uses the hex mesh
    `MeshBuilder.buildHex(white, 2, 1.5f)` and the atmosphere shader with radii
    `radius + atmosphereRadIn/Out`. It is gated on `settings "atmosphere"` (`:35,156-158`).
  - `drawClouds` runs first (`:149`).
  - Camera: `camPos.setLength((radius + camRadius) * camLength + (zoom - 1) * (radius +
    camRadius) * 2)` (`:65`). The Java globe fills more of the frame than Godot's
    (`diff/02-planet-side.png`).
- Port: the atmosphere billboard exists (`planet_view.gd:37-38`), but the rim is thinner and
  darker than Java's purple halo. Clouds are unverified. The camera distance is shorter.
- Change: compare the shader uniforms and the mesh (hex billboard vs Java hex sphere), port
  `drawClouds` if it is missing, and match `camLength`/`camRadius`. Verify with the
  `atmosphere` setting toggled.
- Accept: the planet page frame matches `java/02-planet.png` within the gate after unlock
  normalisation.

## T3 — Tech tree presentation — LOW

- Java `ResearchDialog`:
  - The dialog background is transparent over the planet (`java/40-tech.png`).
  - Sector nodes draw the preset's `uiIcon` (the sector icon). The Godot nodes use the generic
    map glyph (`godot/40-tech.png`, the "house" nodes).
  - The planet header is a framed `Styles.flatTogglet`-style button.
- Change: resolve preset icons in the research node payload, make the backdrop translucent, and
  frame the planet header.

## T4 — Interplanetary Accelerator launch (`Accelerator`) — MEDIUM (PAR-0296)

- Java `world/blocks/campaign/Accelerator.java`:
  - `updateTile` (`:129-…`): heat/charge.
  - The launch button and `launchCandidates` selection (`:42`; `Planet.launchCandidates`,
    `type/Planet.java:161`).
  - The full launch animator (`:322-…`): charge rings, `ringRadBase/ringSpacing/ringPow`,
    lightning, zoom interps, `launchSound`.
  - `unlock right before launch` (`:276`), then the planet transfer.
  The audit lists 28 missing fields.
- Port: `world/behavior/campaign.rs:21-70` implements only the heat charge state machine.
- Change: port the config button (with J05 T3), the launch sequence (camera + FX via the cutscene
  path from I02 T1 pods) and the planet transfer through the campaign facade.
- Accept: a charged accelerator on a captured Serpulo sector launches to Erekir like Java
  (capture both).

## T5 — Campaign rule and generator residuals — MEDIUM

1. `Planet.prebuildBase` (`type/Planet.java:133`) and `allowCampaignRules`
   (`:139,221`, `isVanilla()`) are missing in the port. Check `campaign_rules.rs` /
   `CampaignRulesDialog` gating against Java.
2. `ErekirPlanetGenerator`: the port's header says `state.rules.*`,
   `Schematics.placeLaunchLoadout` and `Waves.generate` "are not applied"
   (`mind-core/src/maps/planet/erekir.rs:7-13`). Implement them like the Serpulo generator (I04
   T17 did this for Serpulo) or record why generated Erekir sectors are unreachable.
3. Sector Abandon semantics: Java hides the planet page and kills the cores, ending in game over
   (`PlanetDialog.java:1166-1177`). The port deletes the record and the save (I04 T10 deviation).
4. The `HudFragment.scheduleToast` 3.5 s shared slot (I04 T2 deviation,
   `HudFragment.java:729-740`; port note at `hud_fragment.gd:535`).
5. `SectorPreset.showSectorLandInfo` (missing in the audit): the land-info toast on arrival.

## Done criteria

T1, T2 and T4 landed and matched. T3/T5 landed or recorded with Java locations. A summary is in
`docs/J07-planet-campaign_summary.md`.
