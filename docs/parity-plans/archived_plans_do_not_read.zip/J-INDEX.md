<!-- SPDX-License-Identifier: GPL-3.0-only -->
# Round J — plan index (2026-10-16)

Source: the round-J twin verification + code audit, `docs/J-round-twin-verification.md`
(evidence in `runs/20261016-J-twin/`), the field-coverage table `J-field-audit.tsv` (script
`tools/j_fieldcov.py`), and the open deviations in `docs/I0*-*_summary.md`. Shared rules are in
`J-environment.md`. Every executor reads it first.

## 1. Plans

| Plan | Title | Priority | Main findings | Touches |
|---|---|---|---|---|
| [J01](J01-world-load-saves.md) | World load fidelity, map import, saves | **P0** | F1 map generation filters never applied (no ores/boulders on custom maps); F12 3 user maps + 7 presets fail import; F9 save previews, Load order, Save & Quit label | `mind-gdext/sim_host.rs`, `mind-core/world/context.rs`, `io/json`, `load_dialog.gd`, `paused_dialog.gd` |
| [J02](J02-terrain-rendering.md) | Terrain, floor and menu-background rendering | **P0** | F2 no floor edge blending; autotiled/tiled floors; preview/minimap `useColor` (scrap); F14 menu flyers/shadows | `mind-gdext/render/floor.rs`, `io/map/preview.rs`, `render/minimap.rs`, `menu.rs`, `menu_background.gd` |
| [J03](J03-turret-unit-draw.md) | Turret and unit draw fidelity | **P0** | F3 `DrawTurret` stub (no shadow/outline/parts/liquid), idle head orientation, pack-time outlines; F4 no legs/treads/wrecks/segments/payload draw; ability draws | `render/blocks.rs`, `fx/draw_turret.rs`, `render/units.rs`, `mind-tools` pack |
| [J04](J04-combat-production-sim.md) | Combat targeting + production/power sim residuals | **P1** | F7 closest-only targeting (no `UnitSorts`/`minRange`/`trackingRange`/`newTargetInterval`); F8 `ConsumeItemExplode`, `itemDurationMultipliers`, electrolyzer output directions, generator explosions; turret deposit cooldown; I01/I02 residuals | `mind-core` turrets/power/crafters/units |
| [J05](J05-block-config-ui.md) | Block configuration panels + hovered-block info | **P1** | F5 `ItemSelection` grid, UnitFactory/Reconstructor command rows, core/dummy/launch-pad panels; `Building.display` bars (core Capacity) | `block_config_fragment.gd`, `input/desktop.rs config_spec`, `placement_fragment.gd` |
| [J06](J06-ui-skin-dialogs.md) | UI skin, dialog shells, per-dialog fidelity | **P1** | F6 settings sliders; F10 Game Over; F11 `TextButton`+icon skin, `BaseDialog`/`showConfirm` shells, keybind markup, Map Play clipping, palette affordability tint | `ui/theme`, `mind_widgets.gd`, `mind_dialog.gd`, many dialogs |
| [J07](J07-planet-campaign.md) | Planet page rendering + campaign residuals | P2 | F13 orbit lines, atmosphere/camera, tech-tree sector icons; Accelerator launch (PAR-0296); Erekir generator hooks; abandon/toast deviations | `planet_view.gd`, `campaign.rs`, `world/behavior/campaign.rs` |
| [J08](J08-editor-logic-residuals.md) | Map editor + logic residuals | P2 | editor building icons/palette order; T12.x residue; map assets dialog; logic font/printchar; display/canvas/picker residue | `editor_renderer.rs`, editor dialogs, `display_context.rs`, `logic_dialog.gd` |
| [J09](J09-mods-content-parser.md) | Mod parser coverage + mod content everywhere | P2 | ~120 parse-relevant `ClassMap` aliases missing; `mod_fields.md` TODOs; base-only catalog/previews; plan-20 data-asset client half | `mind-core/mods`, `parity/mod_classmap.json`, `input/mod.rs`, `editor/preview.rs` |
| [J10](J10-twin-reverify-residuals.md) | Twin harness, small residuals, final re-walk | P1 (T1), last (T3) | harness helpers; inert bloom/linear settings; skip-wave double click; harness hazards; round-K twin report | `tools/`, skills, docs |

**Priorities.**
- **P0** changes what a player sees on every map: terrain, resources, turrets, units.
- **P1** is gameplay rules and high-traffic UI.
- **P2** is completeness.

## 2. Schedule (at most 4 parallel Godot sessions; see `J-environment.md` §4)

| Wave | Session 1 (main) | Session 2 | Session 3 | Session 4 |
|---|---|---|---|---|
| A | J10 T1 (harness), then coordinator | J01 T1–T2 | J02 T1–T3 | J03 T1–T3 |
| B | J10 T2 | J01 T3–T6, then J04 T1 | J02 T4–T5, then J06 T1–T3 | J03 T4–T7 |
| C | merges + ledger | J04 T2–T6 | J06 T4–T9 | J05 |
| D | J10 T3 (round-K twin re-walk) | J07 | J08 | J09 |

Conflict hot spots:
- `mind-gdext/src/sim_host.rs` (J01, J03, J05).
- `mind-gdext/src/render/floor.rs` + `editor_renderer.rs` (J02, J08).
- `turrets/mod.rs` (J03 T2, J04 T1).
- `mind_widgets.gd`/`theme_builder.gd` (J05, J06).

Merge `main` into each worktree before starting a task that touches them.

## 3. Explicitly out of scope (operator decisions)

- **Multiplayer**: I08 T7–T13 and ledger PAR-0121, PAR-0122, PAR-0124, PAR-0125, PAR-0151 stay
  deferred. Do not start them in round J. The multiplayer-only inert settings (`playerchat`,
  `playerindicators`, `showpings`, `showotherbuildplans`) and the `net/` classes in the audit
  wait with them.
- **Platform**: Steam (`docs/platform/steam-parity.md`), Discord RPC (`discord.md`), mobile/iOS
  packaging (`mobile.md`, `store-packaging.md`) and Web (`web.md`, not a target) keep their
  recorded status.
- **Script mods** (JS) remain a recorded deviation (J09 T5).

## 4. Ledger changes proposed by round J (coordinator applies to `chains.json`)

| Item | Change | Plan |
|---|---|---|
| PAR-0114 | stays `fixing`: scrap ore missing from previews/minimap; 3 maps without previews | J01 T2, J02 T3 |
| PAR-0092 | reopen: config panels are a text grid, not `ItemSelection` | J05 T1–T3 |
| PAR-0126 | reopen: legs, treads, wrecks, segments not drawn | J03 T4–T5 |
| PAR-0110 | note: editor palette order/`spawn` entry, core drawn grey | J08 T1–T2 |
| PAR-0144 | note: Core Database opaque background | J06 T9 |
| PAR-0296 | `seeded` → plan: Accelerator launch | J07 T4 |
| PAR-0338 | `seeded` → plan: 7 presets fail import | J01 T2 |
| PAR-0089 | `fixing` → plan: sublimate activation window | J04 T6 |
| PAR-0345/0347 | plan: harness hazards | J10 T2 |
| PAR-0348/0349 | plan | J03 T7, J04 T6 |
| new | Custom maps load without generation filters (no ores/boulders) | J01 T1 |
| new | Floor transitions render as hard tile edges (no `Floor.drawEdges`) | J02 T1 |
| new | Turrets draw without shadow/outline/parts/liquid; idle head off-axis | J03 T1–T3 |
| new | Turrets always target the closest unit | J04 T1 |
| new | Combustion/steam generators ignore explosive items and pyratite duration | J04 T2 |
| new | Settings sliders render as bare Godot sliders | J06 T3 |
| new | Game Over shows Waves Defeated 0, no Time Played, accent rows | J06 T6 |
| new | Map Play content clipped for portrait previews | J06 T7 |
| new | Load Game: no previews, oldest-first; pause menu says Quit on autosave slots | J01 T4–T5 |
| new | Keybind dialog shows raw `[red]` markup | J06 T4 |

## 5. Where results go

Each plan's executor writes `docs/J<NN>-<slug>_summary.md`. The coordinator writes
`docs/J-round-execution-summary.md` (same shape as `docs/I-round-execution-summary.md`), and J10
T3 writes `docs/K-round-twin-verification.md`.
