<!-- SPDX-License-Identifier: GPL-3.0-only -->
# Round-J twin verification + code audit (2026-10-16)

Verifier: Claude Opus 5.5. Main @ `fe8fb0e4` (the round-I twin-verify fix merges are all in; the
`libmind_gdext.so` build at 17:40 was newer than every Rust source change). Both clients ran at the
same time on the xrdp display `:10`: the Java reference
(`../Mindustry/desktop/build/libs/Mindustry.jar`, `parity-java-home`, 1152x648, origin (65,129) and
later (1255,789)) and the Godot session 1 (bridge 6970, embedded game at screen (704,489)). Frames:
`runs/20261016-J-twin/{java,godot,diff}/` (`diff/*-side.png` = Java left, Godot right;
`diff/*-zoom.png` = crops at 2x). Multiplayer was skipped (deferred by the operator).

This round went past the menus: it played custom games end to end (sandbox placement,
item-source feeding, waves, game over, survival construction on Ancient Caldera), walked the
editor, settings pages, keybinds, Load Game, Core Database and the tech tree, and spawned legged
units in Godot. A code audit ran next to it (§3). Its full field-coverage table is
`docs/parity-plans/J-field-audit.tsv`.

Profile note: the Java profile has the full tech tree imported. The Godot session-1 profile has
282/375 unlocks and its own campaign history, so campaign frames differ in *state* (objective step,
sectors under attack). Those differences are not counted as findings. The custom-game comparisons
start from the same map files, so those frames are like-for-like.

Side effects: Java `settings.bin` was backed up before launch and restored
byte-identical afterwards. The Java client created three custom-game autosaves (`saves/32..34.msav*`)
and the Godot client created six (`AncientCaldera*`, `sandbox*`). All of them were moved into
`runs/20261016-J-twin/{java,godot}-session-saves/`. Both clients rewrote their Ground Zero autosave
(`sector-serpulo-170.msav`) when the sector was entered; there was no pre-run copy, so these were
not restored.

## 1. Verdicts per surface

| # | Surface | Verdict | Notes (Java vs Godot) |
|---|---|---|---|
| 00 | Main menu | PARTIAL | Layout and Discord logo now match. The Java background (static camera) draws wall drop-shadows, floor edge blending and a squadron of one random flyer type crossing the screen. The Godot bake has hard floor edges, no shadows and no flyers (`graphics/MenuRenderer.java:169-262` vs `client/ui/menu_background.gd`, `mind-gdext/src/render/menu.rs`). |
| 01 | Play submenu | PARTIAL | Same items. Java draws the opened parent (Play/Database) with an accent border; Godot shows only a faint hover tint. |
| 02-03 | Planet page + sector panel | PARTIAL | Hex grid, labels and sector panel rows match. Godot is missing the planet orbit arc lines and draws a thinner, darker atmosphere rim than Java's bright purple halo. "Under attack!" is left-aligned (Java centred). Godot shows a keyboard-focus outline on Go and a filled grey Stats button. |
| 04-05 | Ground Zero HUD | MATCH (layout) | Objective panel, palette, minimap and coordinates match (the states differ by profile). |
| 06 | Pause menu (campaign) | MISMATCH (skin) | Same buttons. Java uses black `defaultt` buttons with a grey border and a 32 px icon on the left; Godot uses flat slate-filled buttons with a small inline glyph, and Save & Quit fills the full width instead of `dw + 10`. |
| 07 | Quit confirm | PARTIAL | Same text. Godot draws a boxed panel with small inline-glyph buttons. |
| 09 | Custom Game list | PARTIAL | Capital Ship Crash, [Orange]Attack and anthill v5 still have no preview or mode icons (MSAV import failure). The order differs (Java `MapPriority.recent`). The sandbox preview is missing its scrap-ore circle. |
| 10 | Map Play (sandbox) | MATCH | Floating layout now matches. Godot's preview still lacks the scrap ore. |
| 41 | Map Play (Ancient Caldera) | MISMATCH | Godot's content is shifted right and clipped at the dialog edge (mode table, Customize Rules, preview and high score are all cut). |
| 11-12 | Sandbox world | PARTIAL | Rules, core, HUD and palette match. Java draws the `core-zone` floor's edge sprites (hazard stripes) around the core; Godot draws none, because floor edge blending is not implemented (§2, F2). The minimap is missing the scrap ore. |
| 13 | Turret palette | PARTIAL | Same 18 turrets. Godot's grid clips the first column at the panel's left edge. The category buttons have dark cell backgrounds that Java does not draw. |
| 14-16 | Place duo | PARTIAL | Placement, ghost and requirement rows (`Copper */35`) match. The placed duo differs: Godot's head is rotated off-axis while idle (Java faces up at rotation 90) and has no dark outline ring (`<name>-outline` / outlined icon). |
| 21-23 | Item source config | MISMATCH | Java opens `ItemSelection` with no title: a 4-column grid of item icons that closes on select, while the hover box shows the block name and a Health bar. Godot opens a titled panel with a text grid (`Clear`, `X`, then item names; the visible list starts at Metaglass) Java closes on select. The Godot pick was staged through `MindInput.configure_building` (not a real click), and the panel stayed open afterwards. Whether Godot draws the selected item colour in the source's centre is unverified (J05 T5). |
| 17, 25 | Sandbox waves | MATCH | The dashed drop-zone circle and wave counter match. In Godot one of two rapid skip-wave clicks (300 ms apart) did not register: a fresh game went wave 1 → 2, not 3. Java was not given the same double click, so this is unconfirmed (J10 T2). |
| 26 | Pause menu (custom game) | MISMATCH | Java's last button reads **Save & Quit** because the custom game runs on an autosave slot (`PausedDialog.java:116`, `isAutosave()`). Godot reads **Quit**, even though it did write `sandboxOct16655.msav`. |
| 27-28 | Database submenu + Core Database | PARTIAL | Content and order match. Godot covers the menu with an opaque slate background; Java dims it translucently. |
| 29-34 | Editor (maps → info → open → menu → exit) | PARTIAL | The editor now renders y-up, hides the HUD and takes real clicks, and the exit confirm returns to the main menu. These round-I bugs are fixed. Remaining: Map Info and the editor menu are boxed panels with left-shifted flat buttons (Java fills the screen and centres large-icon buttons). The editor draws the core as a grey square (Java shows the core sprite on its zone). The block palette has a red `S` (spawn) entry in row 2 that shifts every later entry (Java order differs). The selected-entry highlight is faint, and check rows use square boxes (Java round toggles). |
| 35 | Settings category menu | MATCH | |
| 36-37 | Settings > Graphics | MISMATCH | Slider rows are broken in Godot. Each is a thin default Godot `HSlider` line struck through the title text, about 25 px tall. Java draws a framed 40 px `defaultSlider` row with a knob, and the title and value sit on top of it. Check rows match. Java shows each row's description tooltip on hover. The injected wheel did not scroll the Godot page (harness or input; unverified). |
| 38 | Controls (Rebind Keys) | MISMATCH | Godot prints raw markup (`A [red]/[] D`), draws key names in white (Java accent) and stretches the table to full width (Java a centred column). |
| 39 | Load Game | MISMATCH | Godot has no save previews (Java shows each save's minimap), sorts oldest-first (Java newest-first, `LoadDialog.java:93`), squeezes Back/Import Save into tiny buttons at the very bottom, and draws white titles (Java accent). |
| 40 | Tech tree | PARTIAL | The node graph matches. Godot has an opaque slate background (Java transparent over the planet). Sector nodes use the generic map glyph instead of each preset's icon. The planet header has no button frame. |
| 42-49 | Ancient Caldera survival | MISMATCH | Java applies the map's generation filters on load (`World.FilterContext`), so ores and boulders appear, re-randomised each load: thorium on the first load, titanium plus scattered boulders on the second. Godot loads the raw tiles with **no ores and no boulders** (`tile_debug(139,38)` = stone/air where Java shows thorium). The wave panel wraps differently. The conveyor drag, 5-plan line, cost (200 → 195) and construction match. Hovering the core shows `Core: Shard` + Health in both; Godot is missing the **Capacity** bar. Tapping the core opens Godot's inventory popup with an oversized translucent background rect. Godot's palette does not grey out blocks the core cannot afford (Java `PlacementFragment.java:315`). |
| 44 | Game Over (custom) | MISMATCH | Java shows dark `StatLabel` rows that slide in and fade accent → darkest-gray, **Waves Defeated 2**, Buildings Built 5, Time Played. Godot leaves the rows bright accent, reads **Waves Defeated 0**, drops the Time Played row, prints the title twice and uses a small Menu button. |
| 52 | Legged units (Godot only) | MISMATCH | A spawned `atrax` and `arkyid` draw as bodies with no legs (no `LegsComp` leg/joint/foot draw). The leg simulation exists in `mind-core/src/entities/comp/unit/legs.rs`; the renderer never draws it. |

Round-I bugs confirmed fixed in this walk: editor clickability, HUD bleed, y-flip and exit target
(I §2 #1–3); the settings category menu; the Discord logo; the HUD core-items position; the
sandbox palette's editor-only blocks; `*/N` requirements; the language and mods dialog layouts;
the floating Map Play layout; the sun-lit globe; the tech tree as a node graph.

Round-I bugs still open: scrap ore missing from previews and the minimap (I §2 #6); the three
unimportable user maps and the map list order (I §2 #11); the boxed dialog family (I §2 #12, now
narrowed to Map Info, the editor menu, the pause menu, confirms, Load Game and Game Over).

## 2. Findings (ranked; the plan that owns each one in brackets)

1. **F1 Map generation filters are never applied on load** [J01 T1]. `World.loadMap` loads custom
   maps through `FilterContext`, which runs `map.filters()` (the `genfilters` tag, or the default
   ore/boulder stack) after the tiles load (`World.java:341-357,661-695`). The port has
   `mind_core::world::FilterContext` (`world/context.rs:167-250`) and `Map::filters`
   (`maps/map.rs:188-200`), but nothing constructs it. `MindSimHost::load_map_world`
   (`mind-gdext/src/sim_host.rs:3035`) → `load_grid_file` (`:9066`) decodes the raw grid only.
   Every custom map that relies on filters loads without ores or boulders.
2. **F2 Floor edge blending is not rendered** [J02 T1]. `Floor.drawBase/drawEdges/drawNonLayer/
   drawBlended/doEdge` (`Floor.java:249-440`, `FloorRenderer.java:325`) draw `<floor>-edge`
   transitions between floors and onto neighbours. The port's `tile_quads`
   (`mind-gdext/src/render/floor.rs:489-560`) emits only the base floor, the overlay and walls.
   Visible as hard square terrain boundaries everywhere (`diff/46-edges-zoom.png`) and as the
   missing `core-zone` stripes (`diff/11-core-zoom.png`).
3. **F3 Live turret drawing is a stub** [J03 T1-T3]. `blocks.rs:391-440` draws base + `region` +
   `-top` + `-heat` only. It is missing the outline (Java packs outlined turret icons; `DrawTurret`
   draws `outline`), the `Drawf.shadow` head shadow, `parts`/`ammoParts` (38 `RegionPart`s in
   `Blocks.java`), and the liquid draw. The `fx/draw_turret.rs` parts program is reachable only
   through the `spawn_turret_draw` debug probe and binds `AllRegions` (every name "found"). The idle
   head orientation is wrong too.
4. **F4 Unit rendering gaps** [J03 T4-T6]. No leg draw for `LegsUnit` (crawler … toxopid, Erekir
   legged units), no `treadRegions` for tanks, no `wreckRegions` on death, no `segmentRegions`
   (`UnitType.java:517-520,1159`). There are 0 hits for tread/wreck/segment/legs in
   `mind-gdext/src/render/units.rs`.
5. **F5 Block configuration UIs are a generic text grid** [J05]. `block_config_fragment.gd`
   `_build_options` builds `Clear`/`X`/name buttons. Java has `ItemSelection.buildTable` (icon grid,
   `selectionRows/Columns`, search past 16 entries, close on select) for 12 blocks, plus bespoke
   panels for UnitFactory (plans + commands), Reconstructor (command buttons), CoreBlock (team
   picker under `coreBuildAndConfig`), TargetDummy (fields), LaunchPad (destination) and the
   Accelerator.
6. **F6 Settings sliders render as bare Godot sliders** [J06 T3]. `MindWidgets.slider`
   (`ui/mind_widgets.gd:193`) sets the theme variation `defaultSlider`, but the theme defines no
   `slider`/`grabber_area`/`grabber` styles from `Styles.defaultSlider` (`Styles.java:374-378`:
   `sliderBack` and the `sliderKnob*` textures).
7. **F7 Turret targeting is closest-only** [J04 T1]. `find_target`
   (`turrets/mod.rs:2071-2100`) always uses `closest_target` with `targetUnderBlocks = true`. Not
   ported: `unitSort` (`UnitSorts.strongest/grouped`, set on ripple, foreshadow, lustre, scathe and malign,
   plus ammo-level sorts on ripple and titan),
   `ammo.unitSort` override, `unitFilter`/`buildingFilter`, the `TimedKillc` missile exclusion,
   `minRange` (ripple 50, plus `minRangeChange`), `newTargetInterval` (4 turrets) and
   `trackingRange` (2 turrets) (`Turret.java:44-117,340-356,571,638-660`).
8. **F8 Production and power residuals** [J04 T2-T5]. `ConsumeItemExplode`
   (combustion/steam generators damage themselves on explosive items; `Trigger.blastGenerator` is
   never fired), `itemDurationMultipliers` (pyratite ×3 in combustion/steam, phase ×15 in RTG),
   electrolyzer `liquidOutputDirections {1,3}`, and the `PowerGenerator` explosion fields
   (puddles, scorch, shake, fireballs) are missing (`J-field-audit.tsv` rows).
9. **F9 Saves presentation** [J01 T4-T5]. No save previews (Java writes
   `previews/save_slot_<index>.png` from the minimap on save, `Saves.java:343-378`; imported saves
   carry them too). The Load list is oldest-first. The pause menu never says Save & Quit for
   autosave slots.
10. **F10 Game Over dialog** [J06 T6]. The waves stat reads 0: `game_stats_json` reports
    `waves_lasted`, but the custom-game loss path never sets it to `wave` (Java `Control.java:133`,
    `Logic.java:436`). Also missing:
    the `StatLabel` colour tween, the Time Played row and the single title.
11. **F11 Dialog/button skin family** [J06 T1-T2, T4-T5, T7-T9]. `TextButton` + icon layout, the
    pause/editor-menu/confirm/Map Info/Load Game shells, opaque full-dialog backgrounds, keybind
    markup, the Map Play clipping on portrait previews, palette affordability greying and column
    clipping, and the selected-parent highlight in the menu.
12. **F12 Map import + previews** [J01 T2-T3]. Three user maps fail
    (`invalid type: map, expected a set`, `Error reading region "map"`) and 7 Serpulo presets fail
    the legacy import (PAR-0338). The preview and minimap colour path skips `Floor.useColor`
    overlays such as scrap (`mind-core/src/io/map/preview.rs:188`).
13. **F13 Planet page** [J07]. No orbit lines, a weaker atmosphere rim, generic sector icons in the
    tech tree, an opaque tech-tree background, and the Accelerator launch is a heat-only stub
    (PAR-0296).
14. **F14 Menu renderer** [J02 T4]. No flyers (`MenuRenderer.drawFlyers`, `:241-262`), no wall
    shadow buffer (`cache()`, `:169-184`), and no floor edges (via F2).

## 3. Code audit method and results

1. **Class citations.** Of 823 Java files under `core/src/mindustry`, 275 are never cited as
   `Foo.java` anywhere in the port. 56 are never even named. Outside `net/` (deferred), save
   versions 1–13 and Steam `service/`, the named-nowhere set is `editor/data/*` (the T12.9 assets
   views), `EffectsDialog` (logic effect picker), `ItemSelection`, `ArmorPlateAbility`,
   `EmptyDataAbility`, `ParticleRenderer`, `TiledFloor`/`TiledWall`/`WobbleProp`,
   `SingleBlockProducer`, ten `Consume*` subclasses and `DrawBlockParts`. Most of these are only
   reachable through `mod/ClassMap.java`, which makes them mod-parser gaps [J09].
2. **Field coverage** (`docs/parity-plans/J-field-audit.tsv`, script
   `docs/parity-plans/tools/j_fieldcov.py`). For every public class-body field in `world/`,
   `type/`, `entities/` and the rest of `core`, the script checks whether its name (case- and
   underscore-insensitive) appears anywhere in the port. 142 classes have missing names. Most are
   visual tuning (effect colours, glow scales). The behaviour-bearing ones are folded into
   J03/J04/J05/J07, for example `Block.destroyBullet/createRubble/baseShake/depositCooldown/
   allowResupply`, the `Turret` targeting fields, `Drill.blockedItem/drillEffect`,
   `GenericCrafter.liquidOutputDirections`, `ConsumeGenerator.itemDurationMultipliers`, the
   `PowerGenerator.explosion*` fields, `UnitType.wreckRegions/treadRegions/segmentRegions`,
   `Weapon.outlineRegion`, `Planet.prebuildBase/allowCampaignRules/launchCandidates`,
   `ShieldArcAbility.reflectBuildingDamage`, `EnergyFieldAbility.hitBuildings`,
   `UnitCommand.repair/assist/mine/…Command` statics, and `CommandAI.targetBuild/groupIndex`.
   A name hit does not prove the behaviour exists; a miss is a strong lead.
3. **Triggers.** 35 of the port's `Trigger` variants are never fired (several are draw-phase hooks the port
   does not need). Most are Steam
   achievements; the gameplay-relevant ones are `teamCoreDamage` (HUD "core under attack"; the
   port has its own path, so this needs re-checking), `unitCommandChange` (PlacementFragment
   rebuild) and `blastGenerator` (F8).
4. **Documented residuals.** The open deviations in `docs/I0*-*_summary.md` that round-I's
   twin-verify fixes did not address are folded into J04 (I01), J08 (I03/I06) and J09 (I07).

## 4. Ledger notes (for the coordinator; `chains.json` was not edited)

- Reopen or annotate: PAR-0114 (scrap ore and three missing previews still fail), PAR-0092 (the
  config panels work but are a text grid, not `ItemSelection`), PAR-0126 (legs, treads and wrecks
  are not drawn), PAR-0110 (editor palette order, core icon), PAR-0144 (Core Database background).
- New item candidates are listed per plan under "Ledger" in `docs/parity-plans/J*.md`.
