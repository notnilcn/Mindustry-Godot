<!-- SPDX-License-Identifier: GPL-3.0-only -->
# G04 summary — saves + campaign loop (session 5 = `parity/session-5`)

Executor: DeepSeek V4.1 Flash (opencode), worktree `Mindustry-Godot-session5`,
branch `parity/session-5`, bridge 7010, display :14.
Plan: `docs/parity-plans/G04-saves-campaign-loop.md`. Started 2026-10-13.
**Stopped after T3b + the in-engine batch for T1/T2/T4/T5/T7**; T8/T10/T11/T9/
T6/T12/V1 not started (budget). Summary state: current as of the last commit
`cf26107`.

Start state: `git merge --ff-only main` from `22f800d` to `aebe448`
(contains G00 marker `971412b`), `INTEGRATED` printed. Status clean except the
untracked `parity-ledger.json` symlink.

Dependency checks (`git log main --oneline | grep …`, re-checked after T5):
* `G02 T17` (per-kind save IO) — never appeared on main during the session;
  T3a/T3b were therefore done by this session.
* `G06` logic codecs — wave 2, not on main. T1 restores logic bodies with the
  port's existing codecs and logs leftovers at debug level (G06's).
* T4's `Sim::set_command_mode_satisfied` / `ObjectiveInputState` / gdext
  `#[func] MindSimHost::set_command_mode_satisfied` landed exactly as G08 T15
  expects.
* T5's `Sim::apply_rules_to_world(&Rules)` + `grid.limit_area` +
  `CampaignRuntime.rules_world_dirty` landed for G03 T11/G01 T13/G02 T8/G06 T4.
* T10/T11 (G03 T20's deps) did **not** land — see Blockers.

## Status table

| Task | Status | Commit | Notes |
|---|---|---|---|
| T1 PAR-0161 bodies | done | a78cd06 | fixture + native round trip; in-engine sorter check PASSED |
| T2 sector resume | done | c9cd517 | + markers fix 1779b98; in-engine PASSED |
| T3w wave timer | done (headless) | b64177e | in-engine blocked, see deviations |
| T4 objectives | done | d75c051 | + seam addendum cf26107; in-engine PASSED |
| T7 capture/derelict | done | f1e93a9, cf26107 | in-engine PASSED |
| T5 rules wholesale | done | b1e2f54 | in-engine PASSED |
| T3a missing codecs | done | 14b9da7 | 13 byte-layout tests |
| T3b payload prefix | done | 834f0a7 | payload read + factory/reconstructor prefix |
| T8 SectorInfo.write | pending | | not started (budget) |
| T10 launch pads | pending | | not started (budget) — G03 T20 dep unmet |
| T11 landing pads | pending | | not started (budget) — G03 T20 dep unmet |
| T9 unit rev 3 | pending | | not started (budget) |
| T6 Java entity import | pending | | not started (budget) |
| T12 settings hub | pending | | not started (budget) |
| V1 verify PAR-0162/0163 | pending | | not started (budget) |

## Commits (`git log --oneline main..HEAD`)

```
cf26107 Gameplay G04 T7: capture_sector queues the derelict conversion; team/objective debug seams
1779b98 Gameplay G04 T2: skip the legacy UBJson markers region (Java map reload fix)
834f0a7 PAR-0161: PayloadBlock body prefix and payload read for payload blocks, factories, reconstructors
14b9da7 PAR-0161: per-kind codecs for projectors, generators, reactors, heat, radar, stack conveyor, beam drill
b1e2f54 Gameplay G04 T5: adopt sector map/save rules wholesale, planet ruleSetter, campaign load overrides, limitMapArea
f1e93a9 Gameplay G04 T7: capture converts the enemy base to derelict, coreDestroyClear, save on capture
d75c051 Gameplay G04 T4: objectives persist completion, Timer in ticks, kill/unit/block inputs
b64177e Gameplay G04 T3w: wave countdown in ticks, isWaitingWave hold, runWave gate
c9cd517 Gameplay G04 T2: sector resume restores units, fires, puddles, markers, wave timer and stats
a78cd06 PAR-0161: restore per-kind building bodies on load (native v2 = Java chunk layout)
```

## Test commands + results (final tree, from `client/rust`, flocked, CARGO_BUILD_JOBS=6)

* `cargo test -p mind-core --lib --features msav-import` — **2033 passed /
  0 failed / 4 ignored** (baseline 1998 + 35 new tests).
* `cargo test -p mind-core --test legacy_msav_import --features msav-import` —
  **4 passed** (fixture bodies + content identity).
* `cargo test -p mind-headless --lib` — 131 passed / 1 failed: exactly the
  known G01 `units_scenarios::tests::committed_goldens_match`.
* `cargo run -q -p mind-headless -- parity goldens` — **97 PASS / 0 FAIL**.
* `cargo clippy -p mind-core -p mind-gdext -p mind-headless --all-targets
  --features mind-core/msav-import -- -D warnings` — clean.
* `cargo fmt -p mind-core -p mind-gdext` — clean.
* Goldens regenerated (named with the Java reason in the commit body):
  campaign sector golden `rules_checksum` 4781866c0cf4b1d8 -> dbb66943087cba6f
  (serpulo ruleSetter `Planets.java:82-88` + world-load overrides);
  sha256 updated in `parity/golden_manifest.json`. Content dump byte-identical.
* New tests: fixture `java_save_restores_per_kind_bodies` (drill 420.7119/1.0,
  conveyor copper, core 4000 + command_pos None, router team 0) and
  `java_save_content_order_is_identity`; sim_io `decode_save_bytes_carries_
  units_tags_and_markers`, `apply_decoded_entities_skips_core_units`,
  `meta_tick_parses_java_float`, `live_save_restores_drill_and_sorter_bodies`;
  runtime `wave_timer_counts_ticks`, `waiting_wave_holds_timer`,
  `wave_runs_without_timer_when_due`, `runtime_block_at_reports_building`,
  `game_state_check_respects_can_game_over`, `captured_flag_follows_rules`,
  `rules_world_dirty_rederives_limit_area`; map_objectives
  `timer_objective_counts_ticks`, `completed_flag_round_trips`,
  `destroy_units_counts_enemy_kills`; planet `serpulo_rule_setter_applies`;
  play `world_load_rules_give_wave_team_infinite_items`; build
  `limit_area_blocks_placement_outside`; building_io 13 byte-layout tests +
  `payload_conveyor_keeps_build_payload`, `unit_factory_body_matches_java`;
  sim `capture_converts_wave_team_to_derelict`,
  `time_destroy_spares_buildings_near_another_core`.

## In-engine evidence (`runs/20261013-s5-G04-batch/`, session 5 user dir)

Ground Zero (serpulo 170) resume from the imported profile:

* **T5** `tile_debug(100,30).limit_area == [90,20,70,60]` (before: null).
* **T1** sorter at (128,52) configured to copper
  (`building_config_json == {"type":"item","id":0}`) survived `run_exit_save`
  + Go (`building_config_json` still copper; tile_debug sim_name "sorter").
* **T2** spawned a team-1 dagger (unit count 2 = player + dagger) and resumed:
  `get_group_count("unit") == 2` and `get_hud_state().wavetime == 21600`
  (the save's value; before: 0 + every unit lost).
* **T4** objectives: after feeding `debug_add_core_items("copper", 400)` +
  placing a drill, objectives 0 (Item) and 1 (BuildCount) auto-completed;
  Timer 4 (duration 300) `countup 106.0` after `step(100)` and **completed at
  countup 300.0** after `step(200)` — 300 ticks = 5 s of sim, not 60x slow
  (before: 18000 ticks). After `run_exit_save` + Go all completed objectives
  (0,1,4,5,7,15) were still completed (persisted through the native v2 save).
* **T7** placed a team-2 copper-wall at (126,55) (`building_debug.team == 2`),
  `capture_sector()` + `step(3)` → `building_debug.team == 0` (derelict),
  `get_sector_state().captured == true`, save mtime moved
  (`t7-gz-derelict.png`; the Game Over "Sector Captured" dialog).
* Panic gate: `grep -c panic` on the newest log = **0** after every step.

## Deviations / blockers

1. **T3w in-engine blocked by the profile's sector fixtures**: no reachable
   sector combines `waveTimer:true` + a live player core. GZ has a core and
   `waves:true` but the imported save's `waveTimer` is false; fresh
   frozenForest(64)/biomassFacility(23)/ruinousShores(41)/tarFields(99)
   entries all come up `hasCore:false` (attack-style presets entered without a
   launch base) so `game_over:true` gates the countdown; saltFlats(98),
   extractionOutpost(213), overgrowth(142) are already captured
   (`waves:false`). Verified instead by `wave_timer_counts_ticks` (119 ticks →
   wavetime 1.0; +1 → wave 1 + 7200), `waiting_wave_holds_timer` and
   `wave_runs_without_timer_when_due`, plus the independent T4 in-engine proof
   that `Time.delta` counts 1/tick in the live schedule (106→300).
2. **Legacy UBJson markers**: T2's decode path first broke `start_sector`'s
   preset reload (`groundZero.msav` "Error reading region markers" → generator
   fallback → panic at (129,55)); fixed in 1779b98 by skipping legacy marker
   regions (deviation 5: UBJson not ported). Native v2 markers still round-trip.
3. **Border darkness**: `BlockDef` has no `ignoreBuildDarkness`, so
   `valid_place` keeps the unconditional `dark >= 3` check; `BuildHarness`
   scaffolds disable `grid.border_darkness` (they place at (0,0)).
4. **BeamDrill codec** uses `DrillState.progress/warmup` (the live fields);
   the parallel `BeamDrillState` component is vestigial in the port (never
   inserted) — recorded so G06/G01 can decide its fate.
5. **Profile mutations in this session's user dir**: GZ was captured during
   the T7 check (save + record updated; `sector-serpulo-170.msav` mtime/length
   changed) and the T1/T2 checks wrote a native v2 GZ save. Other sessions'
   user dirs are unaffected.
6. T10/T11 (G03 T20's dependency) were not reached; the coordinator should
   schedule them (or a follow-up G04 session) before G03's pod task.

## Ledger changes to apply

| Item | New status | Note |
|---|---|---|
| PAR-0161 | fixing -> verified | a78cd06 + 14b9da7 + 834f0a7: port v2 native format = Java tile chunk layout (v1 still loads), per-kind bodies restored for drills/conveyors/core + the T3a codec table, payload prefix/payload read; fixture test + in-engine sorter check (runs/20261013-s5-G04-batch). |
| new: sector resume drops units/fires/puddles/markers/wavetime/stats | fixing (or verified with T2 in-engine) | c9cd517 + 1779b98; GZ resume shows 2 units + wavetime 21600. |
| new: wave countdown 60x slow; isWaitingWave missing | fixing | b64177e; headless tests only (in-engine fixture blocked, see summary). |
| new: objectives completion not saved, Timer 60x slow, DestroyUnits never completes, DestroyBlock instant | verified | d75c051 + cf26107; in-engine countup 106->300 + completion persisted across resume. |
| new: capture leaves the enemy base active; coreDestroyClear missing | verified | f1e93a9 + cf26107; in-engine team 2 -> 0 + captured:true + save on capture. |
| new: sector map/save rules dropped (limitMapArea, weather, ...); planet ruleSetter + campaign load overrides missing | verified | b1e2f54; in-engine limit_area [90,20,70,60]. |
| new (filed by this session): T2 regression — legacy UBJson markers region broke preset reloads | fixed | 1779b98 (item can be closed/merged with the T2 item). |
| new (plan §4, not yet available): launch pads never launch; landing pads never land (T10/T11) | pending | not started. |
| PAR-0162, PAR-0163 | unchanged | V1 not run. |
| PAR-0084 | unchanged (re-verify after T5 when convenient) | lost-sector replay code path untouched; the T5 rules adoption did not change `replay_lost_sector`. |
