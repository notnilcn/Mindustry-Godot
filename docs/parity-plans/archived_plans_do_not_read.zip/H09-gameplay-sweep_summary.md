# H09 — uncovered-gameplay sweep: session-3 execution summary

Session: 3 (worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session3`,
branch `parity/session-3`, Godot bridge 6990, display :12). Started from
H00 (`4fbfcf54`). Written 2026-10-14.

Status: **T1, T2, T3, T4, T7, T8, T10 done** (in-engine verified);
**T5, T6, T9, T11 not reached** (context budget). Final merge of `main` hit
conflicts and was aborted per the execution rules (details below).

## Commits

```
326a02b4 Gameplay H09 T10: GameStats and planet CampaignStats follow the Logic event counters
fd21cd01 Gameplay H09 T8: TeamRule.fillItems refills AI cores every tick
92eaeb81 Gameplay H09 T7: Building.onDestroyed explosion terms and full Damage.dynamicExplosion
934277e0 Gameplay H09 T4: checkAllowUpdate disables derelict/env/outside-area buildings; turrets honour enabled
e307ee5e Gameplay H09 T3: radar discovery, turret/core fog radius and forceUpdate
ed984f45 Gameplay H09 T2: fog hides units/buildings from targeting; static fog blocks placement
6e4e34c6 Merge branch 'main' into parity/session-3   (chains.json ledger commit 22ea48c1)
018a1dde Gameplay H09 T1: live FogControl (world-load reset, per-tick update, dynamic flush every 3 ticks)
```

`git log --oneline main..HEAD` above (main on the branch's base =
`22ea48c1`). Nothing pushed, no ledger edits, `runs/` never added.

## Per-task status

| Task | Status | Commit | In-engine evidence |
|---|---|---|---|
| T1 live FogControl | done | `018a1dde` | `runs/20261014-s3-H09-T1/` |
| T2 fog gates + placement mask | done | `ed984f45` | `runs/20261014-s3-H09-T2/` |
| T3 radar/turret/core fog sources | done | `e307ee5e` | `runs/20261014-s3-H09-T3/` |
| T4 checkAllowUpdate | done | `934277e0` | `runs/20261014-s3-H09-T4/` |
| T5 fires | not reached | — | — |
| T6 puddles (PAR-0091) | not reached | — | — |
| T7 dynamic_expansion/explosion terms | done | `92eaeb81` | `runs/20261014-s3-H09-T7/` |
| T8 fillItems | done | `fd21cd01` | `runs/20261014-s3-H09-T8/` |
| T9 Erekir core incineration | not reached (H02 T1 is on main: keep the reorder half skipped; only the flag/`handle_stack` half remains) | — | — |
| T10 stats counters | done | `326a02b4` | `runs/20261014-s3-H09-T10/` |
| T11 fog persistence | not reached | — | — |

## Tests (final run on `parity/session-3` @ `326a02b4`)

From `WT/client/rust`, all under `flock /tmp/opencode/mg-build.lock`
with `CARGO_BUILD_JOBS=6`:

* `cargo test -p mind-core --lib --features msav-import` -> **2234 passed / 0 failed / 4 ignored**
  (baseline `main` @ `ffbe84dd` 2202; H00 raised it; this session added 3 T1,
  4 T2, 3 T3, 4 T4, 4 T7, 1 T8, 2 T10 tests).
* `cargo test -p mind-headless --lib` -> **132 passed / 0 failed**.
* `cargo test -p mind-gdext --lib` -> **34 passed / 0 failed**.
* `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` -> clean.
* `cargo fmt -p mind-core -p mind-gdext -- --check` -> clean.
* `cargo run -q -p mind-headless -- parity goldens` -> **97 PASS / 0 FAIL**
  (no golden regenerated; `fog_radius`/flags are not in `golden_content.json`).
* `cargo test -p mind-headless --test fx_golden` was **not** run (known
  pre-existing failure owned by H03 T1).

New tests: `game::fog::tests::fog_dynamic_interval_is_three_ticks`,
`sim::fog::tests::fog_view_seams_expose_static_bits_and_sources`,
`sim::combat_tests::{fog_unit_reveals_and_discovers,
fog_off_everything_visible, fog_update_creates_the_resource_when_missing,
turret_ignores_unit_in_fog, ai_team_sees_through_fog,
find_enemy_tile_skips_undiscovered, placement_rejected_in_static_fog,
radar_discovers_in_600_ticks, duo_reveals_its_range,
core_fog_radius_values, disabled_duo_does_not_fire,
blast_container_explosion_terms, linked_vault_explodes_weakly,
battery_lightning_count, explosion_waves_are_staggered}`,
`sim::production_tests::{derelict_drill_does_not_mine,
outside_map_area_disabled_and_reset, env_unsupported_block_disabled,
fill_items_fills_ai_core, game_stats_count_build_break_destroy,
game_stats_count_units_created}`.

## In-engine evidence (Ground Zero / Onset, session-3 bridge 6990)

**T1** (`runs/20261014-s3-H09-T1/`): Ground Zero + `debug_set_fog(true,true)`:
after a team-1 dagger at the core `fog_debug_json(1,129,60)` =
`{"fog":true,"staticFog":true,"visible":true,"discovered":true,"teams":[1]}`,
`(1,129,120)` = visible/discovered false, `(2,129,120)` = visible true (AI
team). Onset (`erekir` 10) same with a spawned dagger at (276,107) true /
(300,107) false / team 3 true. `t1-ground-zero-fog.png`,
`t1-erekir-onset.png`. 0 panics.

**T2** (`runs/20261014-s3-H09-T2/`): after `debug_set_fog(true,true)` and no
fog source, `place` ops at (129,60) and (112,35) both `false`; after a team-1
dagger discovers the core area (129,60) `true` and (112,35) `false`
(`t2-place-*.json`). 0 panics. The turret-targeting half is covered headlessly
(see deviations).

**T3** (`runs/20261014-s3-H09-T3/`): `fog_debug_json(1,129,100)` visible/
discovered true, `(129,103)` false (core-shard radius 46); radar +
power-source at (140,60)/(141,60) -> `building_debug(140,60).radarProgress`
0.61 at ~370 ticks, 1.0 at ~610; (170,60) visible true, (178,60) false.
`t3-ground-zero-radar.png`. 0 panics.

**T4** (`runs/20261014-s3-H09-T4/`): drill (130,48) + container (132,48),
team 1 -> `building_items_json(132,48)` `{"copper":2}` after 400 ticks;
`debug_set_building_team(130,48,0)` -> `building_enabled` false and the
container stays `{"copper":2}` after 1700 more ticks. 0 panics.

**T7** (`runs/20261014-s3-H09-T7/`): charged battery (bars power 4000)
destroyed -> `get_group_count("bullet")` 7 after 6 steps (lightning); a
300-coal container destroyed -> 30 bullets after 20 steps (fireballs) and the
copper-wall at (143,66) is destroyed by the staggered waves
(`t7-*.json`, `t7-ground-zero-explosion.png`). 0 panics.

**T8** (`runs/20261014-s3-H09-T8/`): Onset, malis (team 3) core-bastion at
(287,196), `building_items_json` after a few ticks =
`{"graphite":1073741823,"sand":1073741823,"thorium":1073741823,
"silicon":1073741823,"phase-fabric":1073741823,"surge-alloy":1073741823,
"beryllium":1073741823,"tungsten":1073741823,"oxide":1073741823,
"carbide":1073741823}` (i32::MAX/2 = `getMaximumAccepted` with
`coreIncinerates`). 0 panics.

**T10** (`runs/20261014-s3-H09-T10/`): Ground Zero, two queued `player:0`
copper walls -> `game_stats_json` `built` 0 -> 2; `break_block(136,60)` ->
`deconstructed` 1; `debug_kill_building(138,60)` -> `destroyed` 1
(`t10-stats-*.json`, `t10-ground-zero.png`). 0 panics.

All runs: `grep -c panic` on the newest log = 0.

## Deviations from Java (each with the Java site)

1. **First fog flush tick (T1).** `FogData::last_dynamic_tick` starts at
   `u64::MAX` ("never flushed") so the first `update()` after a load flushes
   immediately like Java's `lastDynamicMs = 0` vs. uptime
   (`FogControl.java:274`); later flushes wait `DYNAMIC_UPDATE_INTERVAL_TICKS`
   = 3 (`FogControl.java:23`). Required by the plan's own flush test.
2. **Alpha/evoke have `fogRadius = 0f`** (`UnitTypes.java:2508,4384`), so the
   plan's T1/T2 in-engine recipes (player alpha reveals; Onset evoke reveals)
   cannot work; the checks spawn a dagger instead. The cores reveal only after
   T3.
3. **Fog + static fog with no player-team `FogData` rejects placement
   everywhere** (Java `isDiscovered` returns false without data,
   `BuildingComp.java:315-333`). The static-fog mask is all-zero in that state
   (`BuildRules.static_fog_mask`), so T2/T3/T7 fixtures are placed before
   `reset_fog()`/on discovered tiles.
4. **T2 turret in-engine half: enemy units spawned by
   `apply_sim_command_json` vanish within a tick in the live session even with
   fog off** (also `run_wave()` produced nothing in that state). Not
   reproducible through the core sim on the exact profile save (the sim_io
   load of `sector-serpulo-170.msav` keeps the spawned unit alive), so it is a
   live-host issue outside H09; **for H01**, whose report already tracks a
   live-only vanishing-unit case. Target gating is covered headlessly.
5. **`update_fog` creates the fog resource when missing**
   (`FogControl.update`: `fog == null -> new FogData[256]`): the sector start
   applies world rules before the campaign runtime exists.
6. **T2 test fixture**: `turret_ignores_unit_in_fog` zeroes the duo's
   `fog_radius_multiplier` because T3 makes every turret reveal its own range
   (otherwise the hidden-target premise is unreachable).
7. **Turret fog radius ignores ammo `rangeChange`** (`Turret.java:426-428`)
   because `BulletDef` has no `range_change` (H02).
8. **T7 conduit scales**: Java writes
   `explosivenessScale = flammabilityScale = 10f/20f` (`Blocks.java:2327-2458`)
   which assigns **both** `10f/20f = 0.5` (upstream commit 65146f9a11 "Reduced
   liquid transport explosiveness") — the plan's "10/20" reading is wrong; the
   port matches Java.
9. **T7 delayed actions** count down in ticks in `DelayedExplosionActions`
   (not `current_tick + ceil(delay)`; `CombatCtx` has no tick) and drain in
   `update_fires_and_puddles`; wave 0 runs inline, later waves land 2/4 ticks
   after the explosion (`Time.run(i * 2f)`). FX (smoke, shockwaves, shake)
   stays host-side.
10. **T4**: fixture turrets without a `Building` component (harness) still
    update; `ground_zero_drill_feeds_the_materialized_core` now places team 1
    (a session-less `Command::Place` is derelict and derelict buildings no
    longer update).
11. **T8/T10**: the fill block needs a live `UnitRuntime` (content registry);
    `PlaySession` starts in `Menu`, so tests set `Playing`. API placements emit
    `BlockPlacedEvent` and therefore count as built (Java fires
    `BlockBuildEndEvent` only from construct finish / instant `Build.java:116`);
    map materialization emits no event.
12. **T10**: `CampaignHookQueues.core_incinerates` + `CampaignCoreHooks`
    answer the incineration flag (needed by the fill amounts). H02 T1 on main
    ("campaign cores incinerate overflow; core hooks read rules") touches the
    same area — expect a merge conflict in `core/game/runtime.rs` (see below).

## Blockers / coordination notes

* **Final `git merge --no-edit main` conflicted and was aborted.** Conflicting
  paths: `client/rust/mind-core/src/game/runtime.rs`,
  `client/rust/mind-core/src/sim/combat_tests.rs`,
  `client/rust/mind-core/src/sim/production_tests.rs`,
  `client/rust/mind-core/src/world/limits.rs`. Main had advanced to
  `351dc7ca` (H04 wave 1: T1,T2,T3,T4,T6,T7,T9) and includes H02 T1
  (`dbb2ca2b`) and H02 T2 (`sync_build_rules`). The coordinator should keep
  both sides' additions — notably my T8/T10 `game/runtime.rs` hunks vs H04's,
  my T2/T4/T7/T10 test hunks vs H04's production/combat tests, and
  `world/limits.rs` (`static_fog_mask` + H02's `sync_build_rules` fields).
* The three timed-out gmcp evals I caused (`$H` unexpanded under single quotes,
  and calls to non-existent `SimHost` methods) wedge the game with
  break-on-error; recovered with `tools/session-play.sh 3 --play`. No panics
  were ever recorded (`grep -c panic` = 0 after every step).
* H02 T1 landed on main while this session ran: T9's coordinator rule means
  the T9 re-run should keep the `handle_item` **reorder half skipped** and only
  add `incinerate_non_buildable` + the `handle_stack` half.
* H01 T3 (`debug_kill_unit`) and H03 T6 (`res://shaders`) were not on main at
  abort time; nothing in this session depends on them.

## Ledger changes to apply (executor never edits `chains.json`)

| Plan item | Change | Evidence |
|---|---|---|
| PAR-0091 (T6) | **not touched** this session; stays `fixing` | — |
| new: "Erekir fog of war is never simulated…" (T1+T3) | `seeded` -> `verified` | `Gameplay H09 T1/T3` commits + `runs/20261014-s3-H09-T1/T3/` |
| new: "Turrets and units target enemies hidden in fog; players build into undiscovered fog" (T2) | `seeded` -> `verified` (headless) + in-engine placement half | `Gameplay H09 T2` + `runs/20261014-s3-H09-T2/` |
| new: "Derelict/captured and outside-map-area buildings keep running; disabled turrets still fire" (T4) | `seeded` -> `verified` | `Gameplay H09 T4` + `runs/20261014-s3-H09-T4/` |
| new: "Fires never throw fireballs, burn units or read building contents" (T5) | `seeded` (not reached) | — |
| new: "Destroyed buildings explode too weakly; explosions have no lightning/fireballs" (T7) | `seeded` -> `verified` | `Gameplay H09 T7` + `runs/20261014-s3-H09-T7/` |
| new: "Enemy cores are never filled (fillItems)" (T8) | `seeded` -> `verified` | `Gameplay H09 T8` + `runs/20261014-s3-H09-T8/` |
| new: "Erekir cores store non-buildable items" (T9) | `seeded` (not reached) | — |
| new: "Game-over/planet stats never count builds, breaks, losses or produced units" (T10) | `seeded` -> `verified` | `Gameplay H09 T10` + `runs/20261014-s3-H09-T10/` |
| new: "Explored fog is lost on save/resume" (T11) | `seeded` (not reached) | — |

New ledger item needed for the live-only enemy-unit vanishing observed in T2
(suggested: "enemy units spawned in a live Ground Zero session vanish within a
tick while the core sim keeps them alive") — owner H01; evidence:
`runs/20261014-s3-H09-T2/t2-spawn-*.json`, `t2-units-after-*.json`.

## Wave-3 re-run list (for this session)

1. T5 (fires) — fires.rs rework + fireball spawn through `Sim::with_combat_ctx`
   (already provided by T7) + `debug_create_fire`.
2. T6 (puddles, PAR-0091) — reuse T7's `PendingFireballs`-style sink; fix
   `update_time`, `accepting`, air-only spread, `CellLiquid`, deconstruct drop.
3. T9 — H02 T1 is on main: add the `incinerate_non_buildable` flag and the
   `handle_stack` half only; do **not** re-add the `handle_item` reorder.
4. T11 — `static-fog-data` chunk via `CustomChunk`; note `DecodedSave.static_fog`
   is the H04-facing seam.

---

# Pass 2 (session 3) — 2026-10-14/15

Session 3 again (worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session3`,
branch `parity/session-3`, bridge 6990, display :12), starting from `main`
@ `550bd1d8` (H03 wave-2 merge; the branch already carried the pass-1 H09
commits). All pass-1 content above is kept.

## Per-task status

| Task | Status | Commit | In-engine evidence |
|---|---|---|---|
| Regression: PAR-0249 fillItems player core + MAX/2 save panic | done (first commit, coordinator request) | `513eed69` | `runs/20261014-s3-H09-regression/` |
| T5 fires | done | `b069023d` | `runs/20261014-s3-H09-T5/` |
| T6 puddles (PAR-0091) | done | `9ab724ea` | `runs/20261014-s3-H09-T6/` |
| T9 Erekir core incineration | done | `15b1e1a2` | `runs/20261014-s3-H09-T9/` |
| T11 fog persistence | done | `532c3464` | `runs/20261014-s3-H09-T11/` |

Nothing skipped, nothing not reached. No Java client was launched (in-engine
halves are Godot-only as allowed); H03's reported issue (`input/command_emit.rs`
f32 unit ids) was left untouched as instructed.

```
532c3464 Gameplay H09 T11: static-fog-data save chunk and building visibility flags
15b1e1a2 Gameplay H09 T9: Erekir cores incinerate non-buildable items on intake
9ab724ea Fixes PAR-0091: puddles follow PuddleComp.update/Puddles.deposit; CellLiquid spread; deconstruct liquid drop
b069023d Gameplay H09 T5: fires follow FireComp.update (lifetime terms, fireballs, unit burning, building flammability)
513eed69 Fixes PAR-0249: fillItems no longer fills the player core; oversized item stacks survive save/load
```

## Regression fix (found by the H03 session)

Root cause: `game/runtime.rs::team_ai_system` ported `Logic.java:552-561` but
dropped the per-team `rule.fill_items` guard (`Logic.java:554`), so EVERY
active team's core (the player core included) was refilled to
`getMaximumAccepted` (`i32::MAX / 2` under `coreIncinerates`,
`CoreBlock.java:749-751`). Campaign rules were correct (wave team only,
`play.rs::apply_world_load_campaign_rules`). The exit save then panicked on
resume at `world/building_io.rs:402` once the stacks summed past `i32::MAX`.

Fix `513eed69`: the `fill_items` guard; `apply_base` and
`ItemModule::set/add/remove` wrap like Java's `int` (`ItemModule.java:319-334,
245-270`); `CoreBuild.onProximityUpdate` clamps only when the world is not
generating (`CoreBlock.java:773-778`) via the new `WorldGenerating` ECS flag,
and `Sim::materialize_buildings` runs the `endMapLoad` proximity pass while
`generating` is set (`World.java:220-236`).

Regression tests (both proven to fail without their fix):
`sim::production_tests::fill_items_does_not_fill_player_core` (player core 0,
wave-team core still `i32::MAX/2`) and `io::sim_io::tests::
live_sim_save_then_load_keeps_oversized_item_stacks` (reproduced the exact
`building_io.rs:402: attempt to add with overflow` panic without the wrap fix;
4 x `i32::MAX/2` stacks round-trip).

In-engine (`runs/20261014-s3-H09-regression/`): the H03 corrupt save
(`runs/20261014-s3-H03-T2/corrupt-sector-serpulo-170.msav`) resumes without a
panic; `load_sector` immediately after the load reports all 16 stacks at
`1073741823`; the later campaign `start_sector` clamps them to 4000, which is
Java's own `SectorInfo.write()` clamp (`J/game/SectorInfo.java:189-195`). 0
panics.

## Tests (final run on `parity/session-3` @ `532c3464`)

From `WT/client/rust`, under `flock /tmp/opencode/mg-build.lock` with
`CARGO_BUILD_JOBS=6`:

* `cargo test -p mind-core --lib --features msav-import` -> **2345 passed /
  0 failed / 4 ignored** (pass-1 final was 2234 at `326a02b4`; wave-2 merges
  account for most of the delta; this pass added 14 tests).
* `cargo test -p mind-headless --lib` -> **133 passed / 0 failed**.
* `cargo test -p mind-gdext --lib` -> **40 passed / 0 failed**.
* `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` ->
  clean; `cargo fmt -p mind-core -p mind-gdext` before each commit.
* `cargo run -q -p mind-headless -- parity goldens` -> **97 PASS / 0 FAIL** (no
  golden regenerated; the new block-def fields are not in the dump).

New tests: `combat::fires::tests::{fire_on_bare_ground_dies_fast,
fire_on_coal_container_lives_longer_and_throws_fireballs}`,
`sim::combat_tests::{fire_burns_ground_units,
fire_damage_respects_block_health_multiplier}`,
`combat::puddles::tests::{same_liquid_deposit_uses_max_accepting,
spread_skips_static_walls, neoplasm_spreads_into_water_building,
status_interval_is_40_ticks}`,
`sim::production_tests::deconstructing_tank_drops_non_incinerable_puddles`,
`world::blocks::storage::core_block::tests::{erekir_core_incinerates_sand,
full_core_still_counts_items}`, `io::sim_io::tests::live_save_keeps_static_fog`,
`sim::production_tests::fill_items_does_not_fill_player_core`,
`io::sim_io::tests::live_sim_save_then_load_keeps_oversized_item_stacks`.

## In-engine evidence (Godot only, session-3 bridge 6990)

**T5** (`runs/20261014-s3-H09-T5/`): Ground Zero, container (140,60) + 300 coal
+ `debug_create_fire` -> `get_group_count("bullet")` 1..3 across the poll and
the container health bar 1.0 -> 0.5336 after 600 steps. Fires are not drawn
yet (H03 T7). 0 panics.

**T6** (`runs/20261014-s3-H09-T6/`): Ground Zero, liquid-tank (134,58) + 1500
neoplasm + player-queued break -> `get_group_count("puddle")` 21 -> 9 and
`construct_progress` walks the deconstruct (0.383 -> 0.05 -> done). 0 panics.

**T9** (`runs/20261014-s3-H09-T9/`): Onset, item-source (280,107) + conveyor
(279,107, rot 2). With the source set to copper the core accumulates
(`{"copper":12}` -> `{"copper":15}`), proving the path; with sand the core
never stores it (pre-fix the plan's recipe stored `{"sand":23}`). 0 panics.

**T11** (`runs/20261014-s3-H09-T11/`): Onset, radar + power-source at
(245,105) reveal the corner (224,80) beyond the core's 54-tile radius; the
radar is broken, `run_exit_save` writes the chunk (decoded offline: 2176
bytes, 512x512, team 1, 2170 RLE runs, 9844 discovered bits) and the resume
reports `{"visible":false,"discovered":true}` for the corner. The pre-fix
resume showed `discovered:false` (the chunk was applied before the campaign
runtime existed; now applied after `install_campaign_runtime` with a
controller rebuild in `apply_static_fog`). 0 panics.

All runs: `grep -c panic` on the newest log = 0 after every step.

## Deviations from Java / the plan (each with the Java site)

1. **T5 animation rate left unchanged** (`+1.0`/tick vs Java's
   `delta / (90/40) = 0.444`/tick, `FireComp.java:41`): view-only field, H03
   owns fire rendering; not touched.
2. **T5 fireball spawn plumbing**: `update_fires` returns the origins and
   `Sim::update_fires_and_puddles` spawns them through a `CombatCtx` (the
   plan's `Vec<(f32,f32)>` recipe); puddle-reaction fireballs use the
   `PendingFireballs` resource per the plan.
3. **T6 deconstruct drop**: the plan's "1500 slag drops per-cell puddles"
   example contradicts the Java condition — slag is `incinerable` (Java
   `Liquid.incinerable` default true, only neoplasm sets false), so Java drops
   nothing (`BuildingComp.java:1480-1487`). The test covers neoplasm (drop,
   9 x 70) and slag (no drop).
4. **T6 `CellLiquid` spread-around deposit** (`CellLiquid.java:59-64`):
   Java passes a neighbour tile as `source`; the port's `deposit` is
   single-tile, so the four deposits land on the puddle's own tile (the
   `accepting = max` fold makes the effective amount identical).
5. **T6 `Trigger.neoplasmReact`** (`CellLiquid.java:88-90`) is not emitted: no
   live consumer; the hint driver (H06/G05) owns triggers.
6. **T9 `incinerateEffect` stays the FX stub** (view output, H03); the
   `handle_stack` `real == 0 && wasVisible` branch emits `Fx.coreBurn`
   unconditionally through the unit runtime's FX sink (no rng draw, so the sim
   stream is untouched).
7. **T9 `item.buildable` lookup**: behaviors have no content registry, so
   `ContentIndex` gains `item_buildable` (dense id -> bool), filled by the
   runtime install; unknown items default to buildable.
8. **T9 in-engine sand differential**: the plan's recipe gave `{"sand":23}`
   pre-fix; the fixed run proves the conveyor path with copper (12 -> 15) and
   shows no sand while set to sand.
9. **T11 resume apply point**: Java reads `static-fog-data` inside
   `SaveVersion.readCustomChunks`; the port's campaign resume applies it after
   `install_campaign_runtime` (the port's `apply_world_rules` runs before the
   runtime exists, so `reset_fog` cannot build the controller there).
   `apply_static_fog` rebuilds the controller when absent.
10. **T11 Ground Zero**: a Serpulo resume resets `fog/staticFog` to the
    campaign default false (Java `CampaignRules.java:19` via
    `Planet.applyRules`), so Onset (Erekir) is the fixture, as the plan said.
11. **PAR-0249 evidence fixture**: the H03 corrupt save is a real artifact;
    the in-engine immediate-post-load probe needed `load_sector` (not the UI)
    to observe the stacks before the campaign `start_sector` clamp.

## Blockers / notes

* The live-session unit vanishing recorded in pass 1 (T2 works around it) also
  blocked the T11 planned "spawn a dagger and walk it" reveal: a team-1 dagger
  spawned through `apply_sim_command_json` still vanishes. The T11 fixture uses
  a radar + broken-radar bit instead. Still owner H01.
* The session's re-imported profile now carries the T6 Ground Zero save
  (puddles) and the T11 Onset save (fog chunk); neither affects the committed
  code.
* Session-2/4/5 merges were picked up via `git merge --ff-only main` at start;
  no merge conflicts this pass.

## Ledger changes to apply (executor never edits `chains.json`)

| Plan item | Change | Evidence |
|---|---|---|
| PAR-0091 (T5+T6) | `fixing` -> `verified` (pass-1 T7 + this pass's T5/T6 in-engine) | `Gameplay H09 T5` + `Fixes PAR-0091` commits; `runs/20261014-s3-H09-T5/`, `runs/20261014-s3-H09-T6/` |
| new "Fires never throw fireballs, burn units or read building contents" (T5) | `seeded` -> `verified` | `b069023d` + `runs/20261014-s3-H09-T5/` |
| new "Erekir cores store non-buildable items" (T9) | `seeded` -> `verified` | `15b1e1a2` + `runs/20261014-s3-H09-T9/` |
| new "Explored fog is lost on save/resume" (T11) | `seeded` -> `verified` | `532c3464` + `runs/20261014-s3-H09-T11/` |
| new (proposed id **PAR-0249**): "fillItems refills every active team's core (player included) and the exit save panics on resume (building_io.rs:402 overflow)" | `seeded` -> `verified`; folds H03's two proposed entries (fillItems corrupts saves + MAX/2 resume panic) | `513eed69` + `runs/20261014-s3-H09-regression/` |
| pass-1 T7/T8/T10 entries | still awaiting the coordinator (unchanged from pass 1) | — |
