<!-- SPDX-License-Identifier: GPL-3.0-only -->
# Round-I twin verification (2026-10-16)

Verifier: Claude Opus 5.5. Main @ `395cf6d0` (rebuilt). Both clients ran at the same time on display `:10`:
the Java reference (`../Mindustry/desktop/build/libs/Mindustry.jar`, `parity-java-home`, 1152x648 at +45+69) and
Godot session 1 (bridge 6970). Frames: `runs/20261016-twin-verify/{java,godot,diff}/` (`diff/*-stack.png` /
`*-side.png` = Java first/left, Godot second/right). Skipped per operator: multiplayer (I08) and features that
need in-depth gameplay. Pixel-gate metrics are not meaningful for these surfaces (random menu backgrounds,
different profile histories), so verdicts are visual + structured state.

Four read-only code audits (I01+I02, I03, I04+I07, I05+I06) ran alongside; their confirmed findings are folded
in below and marked "(audit)". The two Java-semantics findings from the audit were re-checked in code by the
verifier.

Side effects: Java `settings.bin` was backed up, `backgroundpause` set false for the run (Java otherwise freezes
on `:10` during the core-landing cutscene), and the backup restored afterwards (byte-identical). Godot locale was
switched to `de` and back to `en`. The Godot session-1 profile's Ground Zero was entered (autosave).

## 1. Verdicts per surface

| Surface (plan task) | Verdict | Notes |
|---|---|---|
| Play submenu | MATCH | |
| Custom Game list + previews (I06 T5, PAR-0114) | PARTIAL | 3 maps have no preview (Attack_Secret_Island_Outpost, Capital Ship Crash, anthill v5 — the 3 maps that fail MSAV import); previews cropped instead of fitted; one generic mode icon on every card (Java shows per-mode icons); "Custom" label + order + Back button differ; scrap ore missing from previews/minimap (see bug 6) |
| Map Play dialog (I06 T2) | PARTIAL | modes/help/customize/preview/Play all present and working; boxed scrolling panel vs Java floating layout; preview clipped; small buttons |
| Custom Rules dialog (I06 T3) | PARTIAL | rows, order and values identical to Java; full-width button-styled rows vs Java's centred column |
| Play custom map — sandbox (I06 T1, PAR-0133) | MATCH | map loads, rules applied (`infiniteResources` true), core + player; HUD core-items counter is bottom-centre (Java top-centre) |
| Pause-menu rules book + live apply (I06 T4, PAR-0132) | MATCH | book present; toggling Waves applied live (`waves` true -> false) |
| Logic palette in sandbox | MISMATCH | 4 editor-only world-logic blocks (world processor/cell/message/switch) listed; Java hides them. No selected-category highlight |
| Placing a processor | PARTIAL | placement works; no processor range circle while placing; requirement tooltip shows `100/90`, red `0/50` under infinite resources (Java `*/90`) |
| Processor config panel (I03 T6, PAR-0220) | PARTIAL | pencil reaches the editor; but a large titled panel with X covers the palette (Java: one 40x40 pencil under the block); range circle purple (Java accent orange); no block info/health panel |
| Logic editor shell (I03 T7) | PARTIAL | opens/saves; raw `logic` title shown (Java none); small mid-screen buttons; "Vars" instead of "Built-in Variables" |
| Logic Add dialog (I03 T9) | MISMATCH | buttons labelled with the `lst.*` DESCRIPTION instead of the statement name (Java `instruction.<key>`, `LStatement.java:371`); `Unknown / lst.noop` listed (Java skips `InvalidStatement`); raw `[accent]` markup; overlapping layout, no Back, no title |
| Logic statement element (I03 T8) | MISMATCH | header shows "Set a variable." (description) instead of "Set"; header not category-tinted; no `+` add button; full width |
| Editor maps dialog (I06 T9, PAR-0110) | PARTIAL | New Map/Import present; button order differs; same preview gaps; no mode icons |
| Editor Map Info (I06) | PARTIAL | works; shows "Description: unknown" (Java omits); vertical buttons |
| Editor rendering (I06 T7, PAR-0109) | MISMATCH | map renders but **vertically flipped** vs Java (the Map Info preview is correct); several chunks render as flat dark rectangles; text-button tools/teams/block list instead of Java icon grids |
| Editor HUD isolation | MISMATCH | in-game HUD (wave panel, minimap, palette, "Paused", stale block_config panel) drawn over the editor: `HudGroup.visible == true`, `block_config.visible == true` |
| Editor menu (I06 T8) | MISMATCH (input) | same buttons/order as Java, but no button can be clicked: `/root/Spine/Ui/EditorDialog/MapView` is the hovered control over every dialog shown on top of the editor (menu, exit confirm). Only reachable by calling handlers |
| Editor exit confirm (I06 T10, PAR-0111) | PARTIAL | text identical to Java; unclickable (above); after exit the confirm stays on screen; Godot exits to the maps dialog, Java to the main menu |
| Database submenu | MATCH | |
| Schematics (I04 T7, PAR-0143) | PARTIAL | cards/action rows/badges match; Tags row empty (Java lists the schematics' tags); no power-laser lines in previews |
| Core Database (I04 T11, PAR-0144) | PARTIAL | icon tabs present; category order starts with Crafting (Java Distribution); wider layout; no selected-tab border |
| Content info: duo (I04 T6) | PARTIAL | every value matches (health, size, build time/cost, liquids, range, ammo rows incl. graphite +2 tiles / −20%); small scrolling panel vs Java full dialog; narrow ammo boxes; coolant Booster rows missing (disclosed) |
| Settings | MISMATCH (layout) | Java opens a category menu; Godot a tab sidebar with Game pre-opened |
| Language (I05 T2, PAR-0135) | MATCH (function) | same list/order; choosing Deutsch persists `locale=de` and the menu is German after restart. Missing `@language.restart` info on select; current locale not marked like Java |
| Mods dialog (I07) | MISMATCH (layout) | 5 flat top buttons + search vs Java's Import Mod / Mod Browser top and Back / Modding Guide / Open Folder bottom |
| Planet page (I04 T8/T13-T15, PAR-0142) | PARTIAL | hex globe, panel, labels present; Java globe is strongly sun-lit with a dark side, Godot evenly lit; Godot auto-selects Ground Zero on open |
| Sector panel + Stats dialog (I04 T10) | MATCH (content) | same rows; boxed panel; missing warning icon on the lockdown line |
| Ground Zero objective text (I01 T1) | MATCH | "Move into Core: 0/5" uses delivered count |
| Status markers (I02 T3) | MATCH | unconnected full drills show orange (noOutput) |
| Main menu | PARTIAL | Discord button missing its logo |

## 2. Bugs to fix next (ranked)

1. **Editor dialogs are unclickable** — `MapView` (`client/scenes/editor/map_view.gd`, node `/root/Spine/Ui/EditorDialog/MapView`)
   captures the mouse over `editor_menu` and the MindUi confirm. Fix the layering (EditorDialog must sit below
   `DialogLayer`/prompt layers, or MapView must ignore input while a dialog is open). Re-verify by REAL clicks.
2. **Editor shows the in-game HUD** — hide `HudGroup` (and close block_config/inventory) while the editor is open; restore on exit.
3. **Editor view is vertically flipped** and some chunks render as dark rectangles (`gdext/editor/editor_renderer.rs`; compare the y convention of `MindEditorRenderer` with the world renderer's negative-y camera).
4. **Logic editor labels** — `client/ui/dialogs/logic_dialog.gd` `_add_entries` (`label = _t("lst." + bundle)`) and the
   statement header must use `instruction.<key>` (Java `LStatement.localizedName`, `J/logic/LStatement.java:371`), keep
   `lst.<key>` as the tooltip only; filter `noop`/InvalidStatement; rebuild the Add dialog per `LogicDialog.showAddDialog`
   (title `@add`, 130x50 buttons, 3 per row, category headers with icon + line, Back).
5. **Sandbox palette lists editor-only world-logic blocks** — apply `buildVisibility` (editorOnly/worldProcessorOnly) in the
   sandbox catalog (likely regressed by the I07 live-registry catalog change).
6. **Scrap ore missing from map previews and the minimap** — the colour function skips `ore-scrap` (or overlay ores);
   Java's minimap shows the sandbox scrap circle gray.
7. **I02 T4 wall flash decays 60x too slowly** (verified in code): `gdext/render/blocks.rs` `hit -= dt / 600` with `dt` in
   ticks; Java `Wall.java:158` is `hit -= Time.delta / 10` -> `dt / 10`.
8. **I02 T5 beam-node pulse uses wall-clock seconds** (verified in code): `gdext/render/links.rs:171`
   `get_ticks_msec()/1000.0`; Arc `Mathf.absin` uses `Time.time` in ticks -> use `ms * 0.06` like the power-node branch
   (`links.rs:99`). The I02 summary's follow-up claiming the power-node branch is wrong is itself wrong — do not "fix" it.
9. **Infinite-resources requirement display** — block info shows `100/90` and red `0/50` in sandbox; Java shows `*/90`.
10. **Processor config panel** — a single 40x40 pencil under the block (no panel/title/X); range circles in `Pal.accent`;
    show the processor range circle while placing.
11. **Map list fidelity** — fitted previews, per-mode icons, Java order, no "Custom" label in Custom Game, Java button
    sizes/order; the three unimportable maps (also I01's 7 broken preset imports).
12. Dialog layout family (boxed `MindDialog` panels where Java dialogs float/fill): Map Play, Map Info, content info,
    language, mods, settings category menu, sector stats. Plus: HUD core-items position (top-centre), Discord logo,
    `@language.restart` info, selected-category/tab highlights, schematic tags row, Core Database category order,
    planet globe sun lighting.
13. From the code audits (not observable in this walk):
    - (audit) I03 T3 building `@config`, `@payloadCount`, `@payloadType`, `@controlled` are hardcoded stubs while PAR-0218 is "verified" (`core/logic/access.rs`).
    - (audit) I03 T1 `bind_next` skips `logicControllable`; `ucontrol within` uses `<=` (Java `<`) (`core/logic/executor/unit_control.rs`).
    - (audit) I03 T12 display `poly`/`linePoly` lack the `min(sides, 25)` cap; `poly_hexagon_area_within_2pct` asserts 4%.
    - (audit) I03 T7 `@clear` has no confirm; `@logic.restart` does not hide; T9 jump arrows are polylines.
    - (audit) I06 playtest return path unwired (`resume_after_playtest`/`playtesting_map` have no caller); edit-in-game/playtest go through disk.
    - (audit) I07 `editor/preview.rs:134` still builds a base-only registry (mod blocks absent from previews); `MindInput.load_catalog` base-only.
    - (audit) I01 T5 liquid-turret `peek_ammo` uses the most-filled liquid, Java `liquids.current()`; I01 T4 `costLegs`/`costNaval` not done (undisclosed).
    - (audit) I04 T17 enemy-base test silently passes without `assets/baseparts`; verified only with forced extras.
    - (audit) I05 T4: 19 settings rows still inert (list in `docs/I05-settings-language-input_summary.md`).

## 3. Ledger notes (coordinator)

Items marked verified by round I that this walk contradicts: PAR-0109/PAR-0110/PAR-0111 (editor unclickable, flipped,
HUD bleed) -> `fixing`; PAR-0103 (logic editor labels/Add dialog) -> `fixing`; PAR-0114 (3 missing previews, scrap ore)
-> `fixing`; PAR-0218 (audit stubs) -> `fixing`; PAR-0142 (lighting) -> `fixing`. Confirmed: PAR-0133, PAR-0132, PAR-0135,
PAR-0144 (function), PAR-0143 (cards), I01 T1, I02 T3.
