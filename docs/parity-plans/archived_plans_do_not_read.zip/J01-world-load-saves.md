<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J01 — World load fidelity, map import, saves

**Goal.** A custom map or save loaded in Godot holds the same world as in Java: generation
filters applied, every shipped and user map importable, and save slots presented like Java's
(previews, order, autosave labelling).

**Evidence.** `docs/J-round-twin-verification.md` F1, F9, F12; frames
`runs/20261016-J-twin/diff/{42-survival,46-conv-sel,09-custom,39-load,26-quitconf}-side.png`.

**Depends on.** Nothing. T1 should land first: J02 T3 previews and J10 re-walks assume ores exist.

## T1 — Apply map generation filters on load (`World.FilterContext`) — HIGH

- Java: `World.loadMap(Map, Rules)` → `SaveIO.load(map.file, new FilterContext(map))`
  (`core/World.java:341-357`). `FilterContext.end()` → `applyFilters()` runs every
  `map.filters()` entry: `filter.randomize()`, then `input.begin(width, height, tiles::getn)`, then
  `filter.apply(tiles, input)` (`World.java:661-695`). `Map.filters()` returns the `genfilters` tag,
  an empty list for `build < 83` maps without the tag, and otherwise `Maps.defaultFilters`
  (`maps/Map.java`, `maps/Maps.java`).
- Port: `mind_core::world::FilterContext` (`mind-core/src/world/context.rs:167-250`, `end()` calls
  `maps::filters::apply_stack`) and `Map::filters` (`mind-core/src/maps/map.rs:188-200`) exist, but
  nothing constructs a `FilterContext`. `MindSimHost::load_map_world`
  (`mind-gdext/src/sim_host.rs:3035`) → `load_grid_file` (`:9066`) →
  `mind_core::io::sim_io::decode_save_bytes` loads raw tiles.
- Change:
  1. Route map loads (custom game, editor playtest, `start_map_mode`, and the editor's
     "edit in game") through a `FilterContext` built from the `Map`'s tags.
  2. Seed it the way Java does. `filter.randomize()` uses `Mathf.rand`, so maps re-roll every
     load. Keep the seed in the sim RNG stream so the headless checksum stays deterministic per
     seed, and record the seed in the state JSON.
  3. Sector (campaign) loads keep their current path. Java's `loadSector` uses the planet
     generator, not `FilterContext`.
  4. Saves (`.msav` from Load Game) must NOT re-run filters. Java's `SaveIO.load(file)` uses the
     plain world context.
- Tests:
  - `mind-core`: a map with a `genfilters` ore filter gains overlay ore tiles after load.
  - A `build < 83` map without the tag is untouched.
  - A save load is untouched.
  - The headless `start_map_mode` scenario on `caldera.msav` has non-zero ore and boulder counts.
- In-engine: Play → Custom Game → Ancient Caldera → Survival → Play. `tile_debug` shows ore and
  boulder tiles. Twice-loaded maps differ in ore placement, like Java frames 42 and 46.
- Ledger: new item "Custom maps load without generation filters (no ores/boulders)", surface
  world, evidence `runs/20261016-J-twin/diff/42-survival-side.png`.

## T2 — Import the maps Java loads (3 user maps + 7 Serpulo presets) — HIGH

- Failures:
  - User maps `anthill_v5.msav.msav`, `CrashSite.msav.msav` ("Capital Ship Crash") and
    `Attack_Secret_Island_Outpost_1.msav.msav` fail with `JSON error: invalid type: map, expected a
    set` / `Error reading region "map"` (I06 summary, Pass 1 deviation 7).
  - Serpulo presets `hidden/176, 247, 254, 263, 92`, `infestedCanyons` and `navalFortress` fail
    with strict-JSON errors (I01 Pass 1 finding 1; ledger PAR-0338).
- Java: `SaveIO`/`SaveVersion.readMeta`/`readRules` use Arc's lenient `JsonReader` + `Json`
  (`io/SaveVersion.java`, `io/JsonIO.java`). A field that is a set in the port's serde model can be
  an object/array in older saves. Arc reads `null` for missing strings and accepts `NaN`/`Infinity`
  numbers.
- Change: reproduce each failure with
  `cargo test -p mind-core --lib --features msav-import serpulo_preset_markers_regions_are_empty -- --nocapture`
  (it prints the list) plus a new test over the three user maps (copy them into
  `mind-core/src/fixtures/maps/` if their licence allows; otherwise test against the user dir
  behind an `#[ignore]`). Then make `JsonIo`'s rules/tags decoding accept the Arc forms, field by
  field. Do not blanket-ignore errors.
- Accept: all 78 Serpulo presets and the 3 maps import. The Custom Game list shows previews and
  mode icons for the 3 maps (`diff/09-custom-side.png`).
- Ledger: PAR-0338 → fix. PAR-0114 note: the 3 previews.

## T3 — Map list order = `MapPriority` — MEDIUM

- Java: `MapListDialog` sorts `mapList` by `settings.priority.comparator`. The default
  `MapPriority.recent` sorts by file `lastModified` desc, then name; the alternatives are
  `name`/`custom`/`builtin`. The choice persists in the `editormapviewsettings` JSON setting
  (`MapViewSettings`), and the filter dialog lets the user pick it
  (`ui/dialogs/MapListDialog.java:42-67,159,259-260`).
- Port: `client/ui/dialogs/map_list_dialog.gd` keeps registry order.
- Change: expose `lastModified` per map row from `MindPreview.maps_list`. Sort with the persisted
  `MapViewSettings.priority`, stored in the same `editormapviewsettings` JSON key. Add the
  priority rows to the filter popup.
- Accept: the Custom Game and editor map order matches Java frame `java/09-custom.png`.

## T4 — Save previews (`Saves.SaveSlot.savePreview`) — MEDIUM

- Java: on save, `previewFile().writePng(renderer.minimap.getPixmap())` writes
  `mapPreviewDirectory/save_slot_<index>.png`. `previewTexture()` loads it lazily
  (`game/Saves.java:307-378`).
- Port: `load_dialog.gd:226-246` reads `<previews>/save_slot_<stem>.png` but nothing writes it, so
  every card shows the map glyph.
- Change:
  1. Write the preview from the minimap provider (`World/MinimapProvider`) whenever a slot is
     saved (manual, autosave, Save & Quit).
  2. When importing a save (`Saves.importSave`) or listing a slot with no preview, generate one
     from the save's tiles via `MapIo::generate_preview`. Java ships previews with its data
     export; also check that the Godot Game Data import copies `previews/`.
- Accept: the Load Game cards show previews like `java/39-load.png`. New autosaves get previews.

## T5 — Load list order + Save & Quit label — MEDIUM

- Java:
  - `LoadDialog` sorts `-Long.compare(slot.getTimestamp(), other.getTimestamp())`
    (`ui/dialogs/LoadDialog.java:93`).
  - The pause menu's last button is `@save.quit` when `control.saves.getCurrent().isAutosave()`,
    else `@quit` (`ui/dialogs/PausedDialog.java:116,154-155`).
  - Custom games start on a new save named `<map> MMM dd h:mm` when `savecreate` is on
    (`core/Control.java:412-414`, `control.saves.addSave`). `SaveSlot.isAutosave()` reads
    `save-<index>-autosave`, default **true** (`game/Saves.java:265-269,445-451`), so every such
    slot autosaves on the `saveinterval` cadence (`:217-221`).
- Port:
  - `load_dialog.gd` lists oldest-first (the session's new `sandboxOct16*` slots were at the
    bottom).
  - `paused_dialog.gd` shows `@quit` in a custom game that did write an autosave.
- Change: sort by timestamp desc. Expose `is_autosave` for the current slot from the saves facade
  and bind the label.
- Accept: in a custom game the button reads "Save & Quit" (`java/26-quitconf.png`). The newest
  save is first.

## T6 — Slot naming parity — LOW

- Java slots are numeric files (`saves/<index>.msav`) with the display name in the save meta
  (`Saves.java`). The port writes name-based stems (`sandboxOct16655.msav`).
- Change: if the round-I design chose name stems on purpose, record it as a deviation. Otherwise
  switch to numeric indices so the Java data export/import round-trips one to one.

## Done criteria

T1–T5 landed with tests. The Ancient Caldera, sandbox and Load Game frames of the twin run
re-captured in Godot match Java under the §3 rule of `J-environment.md`. A summary is in
`docs/J01-world-load-saves_summary.md`.
