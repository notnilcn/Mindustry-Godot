<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H08 — In-game input and controls, desktop — session 4 summary (2026-10-14)

Session 4 (`/home/clintonnguyen/g/code_examples/Mindustry-Godot-session4`,
branch `parity/session-4`, bridge 7000, display :13). Stopped on budget after
T1-T4 + T6a; T6b onwards not reached. `main` was merged twice during the run
(H02 wave 1 + H01/H09 wave 1); the final `git merge --no-edit main` was a
no-op ("Already up to date") at commit `9046b998`.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T1 line rotation (`relativeTo`, angle base, rotation carry, wheel snap, latch reset) | done | `29ebd1b3` |
| T2 line flags from content; `HostWorld` validPlace/rotation/chains | done | `55225316` |
| T3 junction/bridge/node placement (PAR-0098 remainder) | done | `ecbb92cd` |
| T4 `tileTapped` gates, empty-tap panel hide, deselect stops mining, build autopause | done | `42c91529` |
| T6a RTS keys by name, select-all gating/filters, `set_unit_command` seams | done | `9046b998` |
| T6b RTS orders (attack buildings, middle-click queue, setUnitCommand no-move) | not reached | — |
| T7 command-mode canBoost guard + PAR-0137 | not reached | — |
| T5 block hotkeys (PAR-0214) | not reached | — |
| T9 mouse bindings + F5/F11 (PAR-0213) | not reached | — |
| T10 camera | not reached | — |
| T8 possession routing + PAR-0138 | not reached (H01 `control_block_unit_id` still absent on main) | — |
| T12 onlyDepositCore | not reached | — |
| T11 derelict repair | not reached (H02 T3 derelict branch IS on main; dependency satisfied) | — |
| T13 GUI click diagnosis | not reached (session 3 verified clicks DO reach Controls; recipe below) | — |
| V1 re-verification | not reached | — |
| T14 config panel layering | not reached | — |

Skipped halves recorded:
- T4: H02 T6 tap-to-link call (`world::config_tap::config_tap` /
  `on_configure_build_tapped`) is still NOT on main after both merges —
  the dependent half is "skipped: waiting for H02 T6"; the team-gate /
  panel-hide halves landed.
- T8: `grep -rn "fn control_block_unit_id" client/rust/mind-gdext/src` is
  still empty after the H01 wave-1 merge -> turret-possession half stays
  "skipped: waiting for H01".

## `git log --oneline main..HEAD`

```
9046b998 Gameplay H08 T6a: RTS stance/command keys by name, select-all gating and filters, set_unit_command
0768aa0a Merge branch 'main' into parity/session-4
42c91529 Gameplay H08 T4: tileTapped team/consume gates, empty tap hides panels, deselect stops mining, build autopause
ecbb92cd Fixes PAR-0098: line placement inserts junctions, bridges and spaced nodes
55225316 Gameplay H08 T2: line placement flags from content; HostWorld validPlace, rotation and chains
29ebd1b3 Gameplay H08 T1: line placement uses Java relativeTo, angle base rotation and wheel snap order
```

## Test commands and results

All run from `client/rust` with `CARGO_BUILD_JOBS=6` under
`flock /tmp/opencode/mg-build.lock`.

| After | Command | Result |
|---|---|---|
| T1 | `cargo test -p mind-core --lib input` | 125 passed / 0 failed |
| T1 | `cargo test -p mind-gdext --lib` | 36 passed / 0 failed |
| T2 | `cargo test -p mind-core --lib input::line` | 15 passed / 0 failed |
| T2 | `cargo test -p mind-core --lib can_place_player` | 1 passed / 0 failed |
| T3 | `cargo test -p mind-core --lib line_rules` | 6 passed / 0 failed |
| T3 | `cargo test -p mind-core --lib input` | 132 passed / 0 failed |
| T3 | `cargo test -p mind-gdext --lib` | 36 passed / 0 failed |
| T4 | `cargo test -p mind-core --lib input::desktop` | 4 passed / 0 failed |
| T4 | `cargo test -p mind-gdext --lib` | 36 passed / 0 failed |
| T6a | `cargo test -p mind-core --lib selectable_rows_carry` | 1 passed / 0 failed |
| T6a | `cargo test -p mind-core --lib input` | 133 passed / 0 failed |
| all | `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean (re-run after T6a: no output) |
| all | `cargo fmt -p mind-core -p mind-gdext` | run; only task files changed |

At stop the post-T6a full-suite re-runs finished green:
`cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` clean;
`cargo test -p mind-core --lib input` 133 passed / 0 failed;
`cargo test -p mind-gdext --lib` 36 passed / 0 failed;
`cargo test -p mind-headless --lib` 132 passed / 0 failed (matches the
pre-H08 132-pass baseline). `mind-headless` also compiles
(`cargo check -p mind-headless` clean) after the `SelectableUnit` field
additions in `input_scenarios.rs`.

## In-engine evidence (Ground Zero, real player, session profile)

| Task | Evidence dir `REPO/runs/20261014-s4-H08-<task>/` | Key outputs |
|---|---|---|
| T1 | `20261014-s4-H08-T1/` (eval-output.txt, vertical-drag-built.png, wheel-latched.png) | drag (140,60)->(140,64): built conveyors all rotation 1; wheel during (145,60)->(145,64): preview + queued plans all rotation 2 (snap 1 + step 1); third drag (145,66)->(145,70): all rotation 1 (latch reset); 0 panics |
| T2 | `20261014-s4-H08-T2/` (eval-output.txt, chain-follow.png) | Ctrl-drag titanium-conveyor (132,72)->(134,74) over the L-chain -> preview `[(132,72)r0,(133,72)r0,(134,72)r1,(134,73)r1,(134,74)r1]` (was a zig-zag pathfind); 0 panics |
| T3 | `20261014-s4-H08-T3/` (eval-output.txt, junction-bridge-nodes.png) | junction: preview + built `[conveyor, conveyor, junction, conveyor, conveyor]` at (134..138,64); bridge over wall (146,62): built 145/147 = bridge-conveyor, wall untouched, `building_config_json(145,62) = {"type":"point","x":2,"y":0}`; power nodes built at x `[120,126,132,138,140]` y=66; 0 panics |
| T4 | `20261014-s4-H08-T4/` (eval-output.txt, tap-gates.png) | enemy (team 2) sorter click -> `block_config.visible` false; own sorter click -> true; empty-ground click -> false; ore click -> mine `[130,48]`, right click -> `[]`; 0 panics |
| T6a | `20261014-s4-H08-T6a/` (eval-output.txt) | `g` alone -> `command_mode()` false + `[]`; shift+g -> `[1000000001,1000000003,1000000006]` (daggers + mega, no mono); `set_unit_stance_named("holdfire", true)` -> true; `set_unit_command("mine")` -> true; 0 panics |

## Deviations from Java (all noted in the commit bodies)

- T1: Java keeps the previous `line.rotation` when `Tile.relativeTo` returns
  -1 (`InputHandler.java:2486-2500`); the port keeps the per-point
  `base_rotation` initializer instead (differs only for non-4-adjacent paths
  with a latched override).
- T2: `Sim::can_place_player` from the plan was already provided by H02 T3 as
  `Sim::valid_place_player` (`core/sim/mod.rs:453`), used as the single seam;
  `HostWorld::build_rotation` uses the pre-existing `u8 building_rotation`
  seam (`sim_host.rs:4587`) plus a building-presence gate instead of a new
  `Option<u8>` method.
- T3: `line_rules_for` does not gate `getReplacement`/`unlockedNow`
  (`Placement.java:198`, `Conveyor.java:114`); the build-time gate
  (`placement_allowed` -> `queue_player_place_config`) still rejects locked
  placements, so only the preview may show a locked junction/bridge.
  `calculate_bridges` keeps Java's `plan.placeable()` term alongside the new
  `world.valid_place` (`(placeable && valid_place) || same block`); the plan's
  literal two-term form broke the `bridge_dp_costs` fixture. Per-block ranges
  are name-keyed with kind defaults (content has no range fields): matches
  `Blocks.java` / `world/blocks/distribution/item_bridge.rs:118/128`,
  `world/blocks/power/behavior.rs:1360-1366`.
- T4: Java's `buildWasAutoPaused` resume fires on tapping a construct
  (`ConstructBlock.java:206-208`); the port resumes as soon as a plan exists
  again (the construct-tap `addBuild` path is not ported). The
  `ui.minimapfrag.shown()` term of `DesktopInput.java:608` is not modelled.
- T6a: stance `enabled` is passed through (`true`); Java toggles
  `!activeStances.get(id)`. `unit_debug_json` has no stance field, so the
  stance application is verified only via the named-helper path.

## Blockers / waiting-on (re-check list for wave 3)

- H02 T6 `world::config_tap::config_tap` / `on_configure_build_tapped` —
  T4's tap-routing half (H08 re-run: T4 remainder).
- H01 `MindSimHost::control_block_unit_id` + `BuildingControlSelect` sim half
  (core respawn) — T8's turret half.
- H03 T3 `set_unit_command`/`set_unit_stance_named`: **defined by H08 T6a**
  (`MindInput.set_unit_command(GString)->bool`,
  `set_unit_stance_named(GString,bool)->bool`, `select_only_type(i64)`,
  `deselect_type(i64)`) per H-INDEX §3.2 — H03 must not redefine them.
- The `MindSimHost` seam list provided this session for consumers:
  `can_place_player`, `player_plan_count`, `commandable_buildings`
  (all pub non-`#[func]`); selectable rows now carry `payload`/`select_global`.
- Session-4 note: after a scene restart a stray `restart` dialog can be open
  (`dialog_stack() == ["restart"]`) and silently gates all keys/scroll through
  `MindInput`'s dialog path — close it with `close_top_dialog()` before
  key-driven recipes.

## T13 recipe (verified by session 3; carried for H-environment §4)

Synthetic `godot_input` mouse clicks DO reach Controls on `ffbe84dd`+:
`mouse_button` press + release at the centre of `control.get_global_rect()`
with `"coords":"viewport"` (a preceding `mouse_motion` is harmless but not
required); confirm the target with
`get_viewport().gui_get_hovered_control()` after a motion. Window == viewport
when the embedded game window is 1152x648.

## Ledger changes to apply (plan §4; coordinator edits chains.json)

| Item | Change |
|---|---|
| PAR-0098 | -> verified after T3 (in-engine junction + bridge + node spacing; commits `29ebd1b3`,`55225316`,`ecbb92cd`); remaining: plan drawing (H03) |
| PAR-0140 | add note: T6a fixed stance/command names, `cancel_orders` = stance stop, select-all gating + `controlSelectGlobal`/payload/factory filters, `set_unit_command`/`set_unit_stance_named`/`select_only_type`/`deselect_type` seams (`9046b998`). T6b residuals (attack buildings, middle-click queue, set-command no-move) still open |
| new | "Line drags point the wrong way vertically (Tile.relativeTo y flipped) and wheel snap drops the step; latch never resets" -> T1 (`29ebd1b3`) |
| new | "Line placement ignores block line flags; HostWorld validPlace/chains stubbed (no chain upgrade, no junction/bridge)" -> T2 (`55225316`) + T3 (`ecbb92cd`) |
| new | "Tapping enemy buildings opens config/inventory; empty tap keeps panels; right-click does not stop mining; buildautopause missing" -> T4 (`42c91529`) |
| PAR-0213 / PAR-0214 / PAR-0137 / PAR-0138 / PAR-0215 / PAR-0189 / PAR-0209 | untouched (T9/T5/T7/T8/V1 not reached) |

---

# Pass 2 (session 4, 2026-10-15)

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session4`, branch
`parity/session-4`, bridge 7000, display :13. Continuation of the pass-1 session
above; started from `main` @ `88ddc499` (ff-only) and merged `main` again mid-run
(`7d2ed484`, clean: H02 pass-2 T5/T6 incl. `world::config_tap`, H01 pass-2
velocity model, H07 wave 3) and once more at the end (`1fcb4193`, clean: H02
pass 3 T7/T9/T10/T11; post-merge `mind-core` 2471 passed / 0 failed / 4
ignored, `mind-gdext` 42, clippy clean). The unit-command encoding bug (H03
blocker #2) was fixed first as its own commit. Stopped on budget after T14; T5,
T13, V1 not reached.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| Encoding fix (H03 blocker #2: `CommandTarget::Unit` f32 wire ids) | done (in-engine verified) | `2b6d7cd1` |
| T6b RTS orders (attack buildings, command buildings, middle queue, setUnitCommand no-move) | done (in-engine verified) | `6acabeaa` |
| T7 command-mode canBoost guard + PAR-0137 | done (in-engine verified) | `0879348e` |
| T9 mouse bindings + F5/F11 (PAR-0213) | done (in-engine verified; F11 window mode limited by Xvfb) | `104fa3c4` |
| T10 camera (pan key/latch, paused WASD, smoothcamera, mobile-only edge pan) | done (in-engine verified) | `af4c5890` |
| T12 onlyDepositCore | done headless-only | `5500ac96` |
| T11 derelict repair | done (in-engine verified) | `2f9a3fe9` |
| T8 possession routing + PAR-0138 | done (in-engine PAR-0138; turret half skipped: H01 `control_block_unit_id` absent) | `3cee15d3` |
| T14 config/inventory panel layering | done (node-path re-verified in-engine) | `aec06cc3` |
| T4 tap-routing half (H02 `config_tap`) | fulfilled by H02 T6's `tile_tapped` link branch (merged); seam re-checked (`preview_config_tap(136,64,137,64)` = 2), full click re-run inconclusive (see blockers) | — |
| T5 block hotkeys (PAR-0214) | not reached | — |
| T13 GUI click diagnosis | not reached (pass 1/round-3 already SKIP: clicks DO reach Controls; recipe below) | — |
| V1 re-verification | not reached | — |

## `git log --oneline main..HEAD`

```
1fcb4193 Merge branch 'main' into parity/session-4            <- end-of-session merge (H02 pass 3)
aec06cc3 Gameplay H08 T14: block config/inventory panels live under dialogs (HUD group) like Java
3cee15d3 Gameplay H08 T8: possession targets follow ControlBlock/canControlSelect (+Router)
7d2ed484 Merge branch 'main' into parity/session-4
2f9a3fe9 Gameplay H08 T11: derelict repair on click and in rebuild select
5500ac96 Gameplay H08 T12: onlyDepositCore gates player deposits (alwaysAllowDeposit cores)
af4c5890 Gameplay H08 T10: camera pans like DesktopInput (pan key, paused WASD, smoothcamera, no desktop edge pan)
104fa3c4 Fixes PAR-0213: mouse buttons as bindings; power-laser and fullscreen toggles
0879348e Gameplay H08 T7: command mode honours the canBoost guard and the in-game gate
6acabeaa Gameplay H08 T6b: command taps attack buildings, command factories, queue on middle click; setUnitCommand never moves
2b6d7cd1 PAR-0157: unit-command wire target is lossless (id split; building tiles packed)
```

## Encoding fix (H03 blocker #2) — the wire format change

`command_emit.rs` encoded `CommandTarget::Unit(id)` as `x = id as f32`
(`EntitySeq` >= 1e9 rounds to multiples of 64 -> wrong entity); the decoder
mirrored it, and `CommandTarget::Building` was encoded as tile coords but
decoded as a world position. Now `sim::command::pack_wire_target` /
`resolve_wire_target` split a unit id into two exact 16-bit halves
(`x = id & 0xFFFF`, `y = 1_000_000 + (id >> 16)`), pack building tiles above
`2_000_000` and keep raw world pixels for positions (valid world pixels are
bounded by `32768 * 8`, so no collision; every half is an exact f32). The
`apply_sim_command_json` `unit_command` op gained an optional
`"target_unit": <id>` key. `SimCommand`'s binary log layout is unchanged;
pre-fix wire values are no longer decoded as unit targets (documented).

Regression tests: `unit_target_wire_is_lossless_for_large_ids`
(`1_000_000_001`, `2^24+1`, `i32::MAX` round-trip; `1_000_000_000` vs
`1_000_000_002` distinct — the old collision is asserted explicitly),
`building_target_wire_keeps_the_tile`,
`wire_target_round_trips_large_unit_ids`/`_building_tiles`.

In-engine: own daggers `1000000002/1000000003` box-selected, right-click on
enemy dagger `1000000004` -> `command_targets_json()` attack rows at the
enemy's live position (pre-fix this decoded to the mega `1000000000`).

## Test commands and results

All from `client/rust` with `CARGO_BUILD_JOBS=6` under
`flock /tmp/opencode/mg-build.lock`.

| After | Command | Result |
|---|---|---|
| encoding | `cargo test -p mind-core --lib --features msav-import` | 2398 passed / 0 failed / 4 ignored |
| encoding | `cargo test -p mind-gdext --lib` | 40 passed |
| T6b/T7/T9/T10 | `cargo test -p mind-core --lib --features msav-import` | 2402 passed / 0 failed |
| T6b/T7/T9/T10 | `cargo test -p mind-gdext --lib` | 42 passed |
| T12 | `cargo test -p mind-core --lib -- only_deposit_core_blocks` | 1 passed |
| T11 | `cargo test -p mind-core --lib -- derelict rebuild_rect_repairs` | 10 passed |
| all | `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| all | `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| T9/T14 | `bash tools/godot.sh --headless --editor --quit --path client` grep SCRIPT ERROR/Parse Error | nothing |
| post-merge (mid) | `cargo test -p mind-core --lib --features msav-import` | 2459 passed / 0 failed / 4 ignored |
| post-merge (final) | `cargo test -p mind-gdext --lib` | 42 passed |
| post-merge (final) | `cargo test -p mind-headless --lib` | 133 passed |
| T14 | `cargo test -p mind-core --lib -- ui::manifest` | 6 passed |

## In-engine evidence (Ground Zero, real player, session profile)

Evidence dirs `REPO/runs/20261014-s4-H08-pass2-<task>/`; 0 `panic` lines after
every step.

| Task | Evidence dir | Key outputs |
|---|---|---|
| encoding | `...-encfix/` (notes.md, attack-reticle.png) | selection `[1000000002,1000000003]`; right-click enemy `1000000004` -> `command_targets_json` `attack:true` at (1139.04,479.11) — the enemy, not the mega |
| T6b | `...-T6b/` (eval-output.txt, command-building.png) | right-click enemy wall (140,62) -> `attack:true` at (1120,496); middle-click empty ground -> move rows at (1080,464); `set_unit_command("move")` -> true, targets cleared, daggers unchanged over 2 s |
| T7 | `...-T7/` (notes.md) | possessed `pulsar`, Shift -> `command_mode()` **false**, elevation **1.0** (boosting), release -> 0.72 descending; V -> alpha; Shift -> command_mode **true** |
| T9 | `...-T9/` (notes.md) | mouseBack held -> alpha x 1032 -> 1274; `f5` -> `lasersopacity` 100 -> 0 -> 100; `f11` flips `fullscreen` true<->false (Xvfb keeps the window WINDOWED; one press stalled the frame loop, recovered with `--play`); `select` rebound to `k`, press over an own sorter opens `block_config` |
| T10 | `...-T10/` (notes.md) | paused + `d` 1.2 s -> camera x 1033 -> 1760, unpause -> back on the player; mouseForward with a live player -> x 1032 -> 1690 and the release keeps it (latch); a `d` tap clears it |
| T8 | `...-T8/` (notes.md) | possessed mega, `[` on a dagger 16 px away -> dagger gone from `unit_debug_positions`; `]` 3 tiles away -> dagger back at the carrier (1100,470) |
| T11 | `...-T11/` (notes.md) | derelict copper wall at (140,60) (inside the limit area) clicked -> plan `{x:140,y:60,block:"copper-wall"}`; B-drag (139,59)-(143,61) -> plans at (141,60)/(142,60) |
| T14 | `...-T14/` (notes.md) | `find_child("block_config").get_path()` -> `/root/Spine/Ui/UiRoot/HudGroup/block_config` |

## New node paths (T14; H-environment §4.2 updates for the coordinator)

`/root/Spine/Ui/UiRoot/HudGroup/block_config`, `.../HudGroup/block_inventory`,
`.../HudGroup/plan_config` (were under `OverlayLayer`). `fade_in` stays in
`OverlayLayer`.

## T13 recipe (carried from pass 1 / round 3; still valid)

Synthetic `godot_input` mouse clicks DO reach Controls:
`mouse_button` press + release at the centre of `control.get_global_rect()`
with `"coords":"viewport"` (a preceding `mouse_motion` is harmless); confirm
with `get_viewport().gui_get_hovered_control()` after a motion. Window ==
viewport when the embedded game window is 1152x648.

## Deviations from Java (all noted in the commit bodies)

- T7: the boost guard is evaluated from the live player unit
  (`player_unit_can_boost`, alive + `canBoost`); the host `process` early-returns
  while paused, so the control upload (and thus boost) needs ticks.
- T9: `mouseMove` movement is the inline `moveAt` of H01's `player.rs`
  (the merge made the player write `Vel` only; `velocity::vel_update`
  integrates it). F11's `window_set_mode` is issued but Xvfb has no WM, so
  `window_state().mode` stays WINDOWED; one F11 press stalled the frame loop
  (recovered with `--play`).
- T10: the pan reads `MindInput`'s tracked cursor (`Core.input.mouseX/Y`
  equivalent) instead of `Viewport.get_mouse_position()`, so synthetic bridge
  events pan; `smoothcamera` is re-read at bootstrap/world load (per the plan).
- T8: `selected_control_build` keeps `CoreBlock` + `PayloadConveyor`/
  `PayloadRouter` with the standing-on-tile approximation; the other
  `PayloadBlock` kinds are not included (their `acceptUnitPayload` gates are
  not modelled) and the `ControlBlock` turret branch is skipped.
- T11: `block.unlockedNowHost()` is a no-op (full vanilla content live); the
  import's `limitMapArea` makes the plan's (169,167) scrap walls unreachable
  for `Build.validPlace` — staged inside the limit area instead.
- T6b: the wire still drops `queue`, so a middle-click order applies like a
  direct one in the live sim.

## Blockers / findings / waiting-on

- **Mining click path (new finding, H01 T10a / PAR-0045 area):** a left click
  (default or `select` rebound) on copper ore latches `player_mine_tile()`
  while the sim is PAUSED, but the running sim clears it within a tick — even
  with the alpha at 16 px from the ore (`debug_spawn_player("alpha",1,1040,400)`,
  tile corner distance 16 < the 40 px `valid_mine` floor). `player_can_mine` is
  not a `#[func]`, so it could not be probed directly. This blocked the mining
  half of T9's recipe.
- **H01 `control_block_unit_id` + `BuildingControlSelect` sim half** still not
  on main after the merge -> T8's turret half skipped (recorded).
- **Session wedges:** an eval that calls a non-`#[func]` method (`$I.config_selected()`)
  or that `return`s a void method (`return $C.set_process(false)`) raises a
  script error / times out, break-on-error freezes the frame loop and every
  later call times out; recover with `tools/session-play.sh 4 --play`. The T4
  tap-routing re-run was interrupted this way (state lost on recover); H02 T6
  already verified the click chain in-engine on main.
- T5 (block hotkeys, PAR-0214), T13 (documented SKIP), V1 (evidence) not
  reached on budget.

## Ledger changes to apply (plan §4; coordinator edits chains.json)

| Item | Change |
|---|---|
| PAR-0157 | unblocked: the f32 wire-id blocker is fixed by `2b6d7cd1` (lossless pack; tests + in-engine attack target); the reticle visual is H03's to re-capture |
| PAR-0213 | -> verified after T9 (`104fa3c4`): mouseBack/Forward as bindings, pan/mouse_move fire, F5 power lines, F11 fullscreen setting flip (window mode limited by Xvfb), `select` rebound to `k` clicks the world |
| PAR-0137 | in-engine evidence from T7 (`0879348e`): possessed pulsar, Shift -> command_mode false + elevation 1.0 |
| PAR-0138 | in-engine evidence from T8 (`3cee15d3`): mega picks up a dagger and drops it at the carrier |
| PAR-0140 | add note: T6b fixed attack-building targets, command-building orders, middle-click queue, `setUnitCommand` no-move |
| PAR-0098/T4 | note: T4's tap-routing half is delivered by H02 T6's `tile_tapped` link branch (merged `7d2ed484`) |
| new | "Unit-command wire encodes EntitySeq as f32; attack orders resolve the wrong entity" -> fixed `2b6d7cd1` (the H03 summary's New item) |
| new | "Mining click order clears within a tick while the sim runs (16 px from the ore)" -> finding for H01/PAR-0045 |
| new | "T14 node paths moved to HudGroup" (documentation) |

## V1 attempt (session 4, pass 2) — not completed

Attempted after the last build, Ground Zero with the real player:

- V1.4 (command-mode objective): not run this session.
- V1.1 (queued plan readback): selected `mechanical-drill`
  (`$I.select_block_by_name`; input state `block = mechanical-drill`), clicked
  and dragged over the copper ore (130,48)/(131,48) via `push_event` ->
  `player_build_plans_json()` stayed `[]` and `construct_progress(130,48)` `{}`
  (a click on non-ore (140,60) is also `[]`). Not diagnosed (could be the
  placement gate in this save or a regression); no code changed for V1.
- V1.2/V1.3/V1.5 not attempted.

The round-3 V1 evidence in the pass-1 section above (queued plan/paste/rebuild/
objective/deposit, session 3 with the real player) stays the reference until a
later session re-runs V1.
