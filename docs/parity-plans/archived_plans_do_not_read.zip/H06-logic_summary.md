<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H06 — Logic: session-2 summary (2026-10-14)

Session 2 (worktree `Mindustry-Godot-session2`, branch `parity/session-2`,
bridge 6980, display `:11`), round-H wave 2. Plan:
`docs/parity-plans/H06-logic.md`.

## Per-task status

| Task | Status | Notes |
|---|---|---|
| T1 live processor seams | **done** | commit `0248a281`; in-engine verified (vars grow) |
| T20 map/save-loaded processors resolve constants | **done** | commit `32621e87`; in-engine verified (duoAmmo set) |
| T2 `spawnwave` runs live waves | **done** | commit `7ef440cb`; in-engine verified (wave 1→2, spawnwave event) |
| T3 logic cutscenes | **done** | commit `b73cc911`; in-engine verified (pan/zoom/lock/stop) |
| T5 `setrule` change tracking + checkMapArea | **done** | commit `9a2b77dd`; in-engine verified (conveyor re-enable) |
| T4 messages + `localeprint` | **done** | commit `47917b7c`; in-engine verified (hello + bundle sentence) |
| T6 `setprop` fixes | **done headless-only** | commit `c6af4808`; plan allows headless (no campaign map reachable) |
| T7 conformance suite + GZ walk | not reached | budget; T20/T2/T3/T4/T5 halves are individually verified |
| T8 world side effects | not reached | budget |
| T9 ubind/ucontrol/LogicAI | not reached | budget |
| T11 sensor/fetch/print remainder | not reached | budget |
| T14 text editor | not reached | budget |
| T15 tap-to-link | not reached | H02 T6 (`config_tap`) is **absent on main** (checked); sim half not reached either |
| T10 completionLogicCode | not reached | budget |
| T12 turret control | not reached | budget |
| T13 radar | not reached | budget |
| T18 displays | not reached | budget |
| T19 canvas | not reached | budget |
| T16 overlays | not reached | H03 (T1-T6, T12) landed on main during the session, so the dependency now exists; not attempted for budget |
| T17 editor fidelity | not reached | budget |

`git log --oneline main..HEAD`:

```
c6af4808 PAR-0218: setprop content/unit properties match Java (set, not add; speed, flag, kill, status)
47917b7c PAR-0104: world-processor messages and localeprint reach the HUD (bundle/map locales, formatIcons)
9a2b77dd PAR-0104: setrule tracks changes, re-syncs world rules and runs World.checkMapArea
b73cc911 PAR-0104: logic cutscenes drive the camera, input lock and HUD (Ground Zero pan)
7ef440cb PAR-0104: world-processor spawnwave runs live waves (Ground Zero spawnWave)
32621e87 PAR-0104: map/save-loaded processors resolve logic constants (globals installed before buildings load)
0248a281 Gameplay H06 T1: live processor seams (logic_get_code/set_code/get_state, event log)
```

## Tests (exact commands, from `client/rust` unless noted)

All under `CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock`:

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib -- encode_for_config_rejects_too_long logic_state_snapshot_lists_vars` | 2 passed |
| `cargo test -p mind-core --lib -- features msav-import -- processor_loaded_before_globals_resolves_constants ground_zero_processors_resolve_constants` (T20) | 2 passed |
| `cargo test -p mind-core --lib -- fill_items_gate_skips_other_teams fill_items_fills_ai_core` | 2 passed |
| `cargo test -p mind-core --lib -- spawnwave gz1_spawn wave` (T2) | 56 passed |
| `cargo test -p mind-core --lib -- cutscene_ pan_only` (T3) | 6 passed |
| `cargo test -p mind-core --lib -- setrule map_area_ per_team_rule` (T5) | 11 passed |
| `cargo test -p mind-core --lib -- flush_message locale_print message_announce` (T4) | 3 passed |
| `cargo test -p mind-core --lib -- setprop extraction_outpost` (T6) | 4 passed |
| `cargo test -p mind-core --lib -- logic` | 129 passed / 0 failed |
| `cargo test -p mind-core --lib -- production_tests` | 91 passed / 0 failed |
| `cargo test -p mind-core --lib -- combat` | 176 passed / 0 failed |
| `cargo test -p mind-core --lib --features msav-import` (full) | **2322 passed / 0 failed / 4 ignored** |
| `cargo test -p mind-headless --lib` | 132 passed / 0 failed |
| `cargo test -p mind-gdext --lib` | 34 passed / 0 failed |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext` | applied (no unrelated files left dirty) |
| `cargo run -q -p mind-headless -- parity goldens` | 97 lines, all PASS |
| GDScript parse gate (`bash tools/godot.sh --headless --editor --quit --path client` + grep) | clean |

Known pre-existing (not run / not owned): `mind-headless --test fx_golden`
(`fx_program_explosion` 1 ULP, H03 T1).

## In-engine evidence (0 panics after every step)

All under `REPO/runs/` (shared symlink; never `git add`ed).

* **T1** `20261014-s2-H06-T1/`: GZ resume; `place_block(120,50,"micro-processor")` true;
  `logic_set_code(120,50,"set t @tick")` true; `logic_get_code` = `"set t @tick\n"`;
  `logic_get_state(120,50).vars` t = 2351 → 2495 → 4482 over `step(60)`s. World processor
  (118,50): `accessible:false, privileged:true` and the seam still writes (w grows).
  Too-long code → `logic_last_error()` = `"toolong:26524"`. `state-evals.txt`,
  `t1-micro-processor.png`. Also verified `Executor.var_ids` filtering (no `@`-names).
* **T20** `20261014-s2-H06-T20/`: GZ resumed with the old-save programs (96,43):
  before = `d` null; after the fix `logic_get_state(96,43).vars` = `d` building "duo",
  `amount` 2, and `logic_rules_probe().flags == ["duoAmmo"]` after drill (130,48) +
  duo (132,48) + `step(1800)`. Fresh frozenForest (64) processor (0,0):
  `fetch buildCount gens @sharded 0 @combustion-generator` executed, no `@`-names in
  vars. `state-evals.txt`, `ff64-state.json`, `t20-duo-ammo.png`, plus
  `corrupt-save-sector-serpulo-170.msav` (pre-fix save that panicked on load).
* **T2** `20261014-s2-H06-T2/`: `logic_set_flag("spawnWave", true)` → wave 1 → 2,
  flags without `spawnWave`, unit count 1 → 2, `unit_debug_positions()` shows team-2
  daggers/flare walking from the spawn overlay (world ~(1144,1590)). Event-log tail
  (paused capture): `["flag","spawnwave","fetch","fetch","fetch"]`
  (`event-log-spawnwave.json`, `state-evals.txt`, `t2-wave-spawn.png` — fog-dark:
  unexplored area; the position JSON carries the proof).
* **T3** `20261014-s2-H06-T3/`: flags mineOver+spawnOver → `logic_cutscene_json` =
  `{"active":true,"x":1080,"y":1840,"speed":0.03,"zoom":-1}`; camera panned to
  (1079.99,1839.99), camerascale 4.0 → 1.5 (`min_scale`); input state
  `locks:["logic_cutscene"]`; after `wait 11` + stop → `active:false`, camerascale 4.0,
  camera back on the player core (1032,440). `t3-run-1.png` (panned/zoomed-out view),
  `t3-clean-*.png`.
* **T5** `20261014-s2-H06-T5/`: conveyor (140,60) enabled;
  `setrule mapArea 10 0 0 130 130` → `building_enabled(140,60)` **false**
  (limitWidth 130); `setrule mapArea 10 0 0 200 200` → **true** (limitWidth 200).
  `state-evals.txt`.
* **T4** `20261014-s2-H06-T4/`: paused-capture world processor:
  `print "hello"` + `message announce 3 @wait` → centred "hello"
  (`t4-announce-hello.png`); `localeprint "atolls.noairunit"` + `message announce 4
  @wait` → "This base is too well-fortified to destroy with air units."
  (`t4-localeprint-bundle.png`). `state-evals.txt`.
* **T6**: headless only (plan: "no campaign map with these programs is reachable in the
  imported profile without long play; say so"). `extraction_outpost_block2` runs the
  verbatim map program with a relative `nucleus1` link against a real team-2
  core-nucleus.

## Deviations from the plan / Java

* **T2** (plan-documented): the wave spawns one tick later than Java — the processor
  runs inside `update_buildings`; `drain_logic_events` queues `pending_wave` after the
  schedule, so `run_wave_system` spawns next tick. No gameplay effect.
* **T5**: no `CampaignRuntime.pending_map_area_checks` field was added. The coordinator
  override said to call H09 T4's checkMapArea entry with the previous area "if it is on
  main"; main's `Sim::apply_rules_to_world` already derives `prev = grid.limit_area` and
  runs `reset_map_area(prev)` + `check_all_allow_update` (`Sim.java`-equivalent of
  `World.checkMapArea`, `J/core/World.java:469-481`), so a second queue would duplicate
  the re-enable. `run_set_rule` marks `rules_world_dirty` on any `changed` rule instead
  of only `mapArea` (and not when unchanged).
* **T3**: the HUD hide is a 10-frame GDScript poll of
  `logic_cutscene_json().hideHud` (`HudFragment.java:1239`) instead of a per-frame
  binding; `_finish_uiscale` keeps `_process` enabled so the poller survives a uiscale
  change. During an overlapping landing cutscene, the logic state is only adopted once
  `Renderer.isCutscene()` clears (Java forces `logicCutsceneZoom = -1` while it runs,
  `InputHandler.java:946-950`).
* **T4**: `message toast` uses `MindUi.show_info_toast` when it exists, else the
  announce box (fallback listed; H03 owns the visual). `notify` maps to
  `MindUi.toast(text, "info")`. The map-locale source is the save/map `locales` meta
  tag; desktop localization files are not shipped.
* **T6**: `DynamicStatus` multipliers and `UnitFlag` are not saved (plan-sanctioned
  out-of-scope). The `Team` setters keep `TeamComp` only — no `changeTeam` side-effect
  path exists on main.
* **T20**: `install_sector_world` gets the order fix; `reassemble_all_processors` is a
  core helper used by tests (a post-decode engine reassemble would drop saved `wait`
  timers, so it is intentionally not called on the load path).
* Drive-by fixes in `32621e87` (both on main before the session, both H09-owned):
  the `fillItems` core refill was missing Java's `rules.fillItems` gate
  (`J/core/Logic.java:553-554`) and filled the player core with `i32::MAX/2` per item
  every tick (write side), and `apply_base` summed item counts with a panicking `+`
  where Java wraps (`J/world/modules/ItemModule.java:319-331`) (read side). Together
  they made the session's GZ save unloadable.

## Blockers / incidents

* **GZ save corruption** (pre-fix): the exit-save written by the T1 session carried
  `i32::MAX/2` of all 16 items in the player core; reloading panicked in
  `building_io.rs:402`. Root cause fixed in `32621e87`; the corrupted save is kept as
  evidence (`runs/20261014-s2-H06-T20/corrupt-save-sector-serpulo-170.msav`) and the
  session save was restored from the worktree's `parity-java-home` copy.
* **Sector lost once** during T2/T3 testing (the spawned wave daggers reached the core
  while T3 was being set up); recovered via the planet dialog Go path after restoring
  the save. Not a port bug.
* **`git merge --no-edit main` (final, 2026-10-14) conflicted** in
  `client/rust/mind-gdext/src/sim_host.rs` (H03 wave-2 edits overlap the logic seams).
  `git merge --abort` was run per the environment rules; the branch is clean at
  `c6af4808` and does **not** contain H03. Main is at `550bd1d8` (H03 T1-T6,T12).
  The coordinator should merge `parity/session-2` before/with H03 and resolve
  `sim_host.rs` by keeping both sides' additions (my logic seams are additive).
* `H02 T6` (`on_configure_build_tapped`/`config_tap`) is **not on main** — T15's UI half
  is blocked even if T15 is picked up later.

## Ledger changes to apply (coordinator; §4 expanded)

* **PAR-0104** — keep open/`fixing`. Progress landed: T2 (`7ef440cb`), T3
  (`b73cc911`), T4 (`47917b7c`), T5 (`9a2b77dd`), T20 (`32621e87`). Still missing for
  `fixed`: T8 and the T7 in-engine GZ walk. Record the evidence runs above.
* **PAR-0106** — recommend `verified`: T1 gives the in-engine `@tick` readback
  (`logic_get_state` vars grow; runs/20261014-s2-H06-T1).
* **PAR-0218** — keep open/partial: T6 landed (`c6af4808`, headless); T11
  (sensor/fetch/print remainder) not reached.
* **New item A (H09 T8 follow-up)** — "`team_ai_system` core fill missing
  `rules.fillItems` gate: the player core was filled with `i32::MAX/2` of every item
  every tick, writing unloadable sector saves" — **fixed** in `32621e87` (World side,
  severity S1). Suggest a `PAR-` id or a note on PAR-0153.
* **New item B** — "`apply_base` item-total overflow panics on reload of saves with
  large stacks (Java wraps)" — **fixed** in `32621e87` (World, S3).
* T7/T8/T9/T10/T11/T12/T13/T14/T15/T16/T17/T18/T19: not reached; no ledger movement.

## Files changed (7 commits, 24 files)

`core/logic/{world.rs, rules.rs, access.rs, blocks/logic_block.rs}`,
`core/sim/{mod.rs, runtime.rs, unit_runtime.rs, production_tests.rs}`,
`core/game/runtime.rs`, `core/input/camera_state.rs`,
`core/entities/comp/unit/comp.rs`, `core/combat/damage/status.rs`,
`core/world/building_io.rs`, `core/assets/bundle.rs`,
`gdext/{sim_host.rs, camera.rs, input/mod.rs}`,
`ui/{ui_root.gd, fragments/hud_fragment.gd}`.

---

# Pass 2 (session 2, 2026-10-15)

Same worktree (`Mindustry-Godot-session2`, branch `parity/session-2`, bridge 6980,
display `:11`), continuation after the wave-2/3 merges. Start state: worktree was one
merge commit behind main; `git merge --ff-only main` -> `2018d7b8`. H02 T6
(`config_tap`/`on_configure_build_tapped`) and H03 T1-T6/T12/T5 are on main, so T15's
UI half and T16 are unblocked.

## Per-task status (pass 2)

| Task | Status | Notes |
|---|---|---|
| T7 conformance suite + GZ walk | **done** | commit `0d8a92c5`; 12 tests + clean-re-import GZ walk (all 5 steps) |
| T8 world side effects live | **done** | commit `3c4284c2`; 9 tests + in-engine spawn/effect/setblock; **Fixes PAR-0104** |
| T9 ubind/ucontrol/LogicAI | not reached | budget |
| T11 sensor/fetch/print remainder | not reached | budget |
| T14 text editor | not reached | budget |
| T15 tap-to-link (both halves unblocked) | not reached | H02 T6 now on main |
| T10 completionLogicCode | not reached | budget |
| T12 turret control | not reached | budget |
| T13 radar | not reached | budget |
| T18 displays | not reached | budget |
| T19 canvas | not reached | budget |
| T16 overlays (H03 landed) | not reached | budget |
| T17 editor fidelity | not reached | budget |

`git log --oneline main..HEAD` (pass 2):

```
3c4284c2 Fixes PAR-0104: world-processor spawn/status/explosion/effect/sound/setblock/getblock/weather apply live
0d8a92c5 PAR-0104: early-sector world-processor conformance suite (Ground Zero, Frozen Forest, Frontier, ...)
```

## Tests (pass 2, exact commands from `client/rust`)

All under `CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock`:

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib -- logic_campaign_tests` (T7) | 12 passed / 0 failed |
| `cargo test -p mind-core --lib -- logic_campaign_tests` (T8) | 21 passed / 0 failed |
| `cargo test -p mind-core --lib -- logic` (T8) | 151 passed / 0 failed |
| `cargo test -p mind-core --lib -- production_tests` | 102 passed / 0 failed |
| `cargo test -p mind-core --lib -- combat` | 209 passed / 0 failed |
| `cargo test -p mind-core --lib -- "turrets::"` | 24 passed / 0 failed |
| `cargo test -p mind-core --lib --features msav-import` (full) | **2482 passed / 0 failed / 4 ignored** |
| `cargo test -p mind-headless --lib` | 133 passed / 0 failed |
| `cargo test -p mind-gdext --lib` | 40 passed / 0 failed |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext` | applied (no unrelated files) |
| `cargo run -q -p mind-headless -- parity goldens` | all PASS |
| GDScript parse gate | not run (no `.gd`/`.tscn` edits in pass 2) |

## In-engine evidence (0 panics after every step)

* **T7** `runs/20261015-s2-H06-T7/` (`walk-summary.md` + per-step JSON/PNG). Clean
  re-import (`nodes 375 / unlocked 282`), GZ 170 via the Go path:
  1. `logic_set_flag("mineOver", true)`, `step(30)` -> `limitMapArea` true 90,20
     70x60 -> **false**; GZ-4 vars `mineOver 1`.
  2. `logic_set_flag("spawnOver", true)` -> `logic_cutscene_json
     {active:true,x:1080,y:1840,speed:0.03,zoom:-1}`, camera at (1079.98,1839.55)
     scale 1.5 (min); after `wait 11` `active:false`, camera back at (1032,440)
     scale 4.0.
  3. `logic_set_flag("spawnWave", true)`, `step(120)` -> wave 1 -> 2, wavetime
     7200, unit count 1 -> 2, crux dagger at (1125.66,1802.36).
  4. drill (130,48) + duo (132,48) + `step(1500)` -> duo `turret_total_ammo` 18,
     objective flags `["spawnOver","duoAmmo"]` (the imported save's OLD GZ-5).
  5. `logic_set_flag("allowWaves", true)`, `step(60)` -> `waveSending:true`,
     `waveTimer:true`.
* **T8** `runs/20261015-s2-H06-T8/` (`verify-summary.md` + JSON/PNG), GZ 170 paused,
  world processor (118,50) via `place_block` + `logic_set_code`:
  * `spawn @flare 130 60 0 @sharded u` + `effect warn 130 60 2 %ffaaff`, `step(10)`
    -> units 2 -> 3, vars `u` = unit "flare" at world (1039.99,480.01), event log
    `spawn`,`effect` (`t8-flare-spawn.png`).
  * `setblock block @air 169 167 @derelict 0` (+ `171 167`), `step(5)` -> both
    derelict `scrap-wall`s -> `air`, `has_build:false`, event log
    `setblock`,`setblock` (`t8-setblock-cleared.png`).

## Deviations from Java (pass 2)

* **T7 drive-by (item-turret ammo)**: `advanced.rs::base_config` left `max_ammo = 0`
  for every item turret except the four with an explicit value, so scatter, hail,
  swarmer, salvo, fuse, ripple, cyclone, spectre, breach, disperse and smite could
  not accept ammo at all. Java inherits `Turret.maxAmmo = 30`
  (`J/world/blocks/defense/turrets/Turret.java:47`) and only `foreshadow` (40),
  `diffuse` (30), `titan` (`ammoPerShot*3`), `scathe` (45) override it. Fixed in
  `0d8a92c5`: item-kind default 30, `scathe` 45. `gz3_scatter_ammo` exposed it.
* **T8 spawn**: the `Mathf.range(0.01f)` jitter is drawn from the `Sim` RNG stream
  (Java uses the global `Mathf.random`); the delayed `Fx.spawn` 30-tick follow-up
  in `WaveSpawner.spawnEffect` is skipped (the immediate `Fx.unitSpawn` plays).
* **T8 explosion**: the port's `damage_area`/`DamageOptions` has no `air`/`ground`
  filters (Java `Damage.damage(..., pierce, air, ground, ...)`); they are accepted
  and ignored.
* **T8 weather**: `Tmp.v1.setToRandomDirection()` draws from the `Fx` RNG stream
  (Java `Mathf.random` global); `LogicWorldState.weather_active` is no longer read
  (the live `WeatherRuntime` entities are the source of truth).
* **T8 sound**: ids outside the sound table are ignored (Java substitutes
  `Sounds.none`); `run_play_music` keeps the `headless` early-return.
* **T8 status**: `combat/damage/status.rs::unapply_status` was added (no H01
  `unapply` helper existed); it drops the entry and its `damage_times` slot, and the
  per-tick status update re-derives the multipliers.
* **T8 `getblock` rounding**: both paths now use Java `Mathf.round` =
  `floor(x + 0.5)` (the old fallback truncated with `numi()`).

## Notes for the next pass

* The atolls T8 test spawns the two naval `@minke`s on `deep-water` floors: a naval
  unit standing on a solid/land tile is killed by the `unit_can_pass` branch
  (`core/entities/comp/unit/environment.rs:418-431`, Java `UnitComp.canPassOn`), so
  the synthetic test has to provide water like the real map does.
* The `status` statement's effect field must be `@status-<name>` (Java picker
  writes that); the shipped cruxscape text `status false fast ...` binds a plain
  null variable in both clients (map-authoring quirk, not a port bug).
* `logic_campaign_tests.rs` now carries the T7 program suite and the T9-T8 sink
  tests; helpers in `production_tests.rs` are `pub(super)` for it.
* The live session ended on GZ 170 (paused, wave 2, drill/duo built, waves
  enabled) after the T8 walk; the profile/tech state is intact (375/282).

## Ledger changes to apply (coordinator; pass 2)

* **PAR-0104** -> **`fixed`**: T2/T3/T4/T5 (`7ef440cb`/`b73cc911`/`47917b7c`/
  `9a2b77dd`), T20 (`32621e87`) and now T8 (`3c4284c2`) + the T7 in-engine GZ walk
  (evidence `runs/20261015-s2-H06-T7/`).
* **PAR-0218** — keep open/partial: T6 (`c6af4808`, headless, pass 1); T11 not
  reached. The T7/T8 suites now cover the supporting behavior.
* **PAR-0106** — stays a `verified` candidate (T1 evidence, pass 1).
* **New item (pass 2)** — "item turrets other than duo/foreshadow/diffuse/titan had
  `max_ammo = 0` (scatter/hail/swarmer/salvo/fuse/ripple/cyclone/spectre/breach/
  disperse/smite could not accept ammo)" — **fixed** in `0d8a92c5` (World, S1).
  Suggest a `PAR-` id or a note on the scatter/GZ-3 item.
* T9/T10/T11/T12/T13/T14/T15/T16/T17/T18/T19: not reached; no ledger movement.
