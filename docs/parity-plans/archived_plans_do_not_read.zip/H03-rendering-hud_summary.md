<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H03 — In-sector world rendering + HUD: session-3 execution summary (2026-10-14)

Session 3 (worktree `Mindustry-Godot-session3`, branch `parity/session-3`, bridge
6990, display :12). Read `H-environment.md`, `H-INDEX.md` §3, `H03-rendering-hud.md`
in that order. Started from `main` @ `d3888ea0` (H00 + H09 wave 1 + H04 wave 1 +
H02 wave 1). `git merge --no-edit main` at the end was ABORTED (conflict, see
Blockers); the branch is the 7 commits below on `d3888ea0`.

## Commits (`git log --oneline main..HEAD`)

```
46bf91ae Gameplay H03 T12: Erekir fog of war rendering (static + dynamic)
d62d763a Fixes PAR-0246: light composite visible (res://shaders wins over the stale packed copy), drawlight setting wired
2646b0c6 Gameplay H03 T5: overlay top (indicators, configure outline, core radius, drop zone, hover range) + ConfigOverlay/SelectOverlay hooks
7c3eaf2d Fixes PAR-0096: minimap attack indicators fed from BuildDamageEvent with Java tick timing
b38e9f68 Fixes PAR-0095: command-mode panel with unit types, commands and stances; PAR-0157 attack reticle
3f7ef26e Gameplay H03 T2: HUD toggle (C) hides and restores the HUD tables
fd225fd0 Gameplay H03 T1: FX goldens compare with a 1e-4 float tolerance
```

## Per-task status

| Task | Status | Commit / notes |
|---|---|---|
| T1 fx_golden tolerance | done (headless only: test harness) | `fd225fd0`; `cargo test -p mind-headless --test fx_golden` -> 2 passed |
| T2 player-unit-gated visuals | done (row c fixed; evidence table `runs/20261014-s3-H03-T2/notes.md`) | `3f7ef26e` |
| T3 PAR-0095 command panel + PAR-0157 reticle | done (panel fully verified; reticle visual blocked by a wire-id bug, code + tests in place) | `b38e9f68` |
| T4 PAR-0096 minimap indicators | done (feed + tick timing + pause freeze + black-crop fix) | `7c3eaf2d` |
| T5 overlay top + placement range | done (core radius/drop-zone headless only) | `2646b0c6` |
| T6 PAR-0246 light composite | done (root cause: stale packed shader) | `d62d763a` |
| T12 fog (steps 1-3) | done; step 0b subsumed (placeholder deleted, not just hidden) | `46bf91ae` |
| T18 static block cache | not reached | |
| T7 fires/puddles | not reached | |
| T8 crafter DrawBlock | not reached | |
| T9 unit factories | not reached | |
| T10 status particles | not reached | |
| T11 shields/build beams | not reached | |
| T15 shield bubble | not reached | |
| T16 FX light prims | not reached | |
| T17 markup in toasts | not reached | |
| T13 pods | not reached | |
| T14 mesh-null noise | not reached | |

## Tests (exact commands + results; run from `client/rust` with the build lock)

```
cargo test -p mind-headless --lib compute_variant             # T1 helper
cargo test -p mind-headless --lib json_close                  # 1 passed (T1)
cargo test -p mind-headless --test fx_golden                  # 2 passed (T1)
cargo test -p mind-gdext --lib                                # 38 passed (incl. T3 command_panel/target_spikes, T6 shaders)
cargo test -p mind-core --lib render::minimap                 # 6 passed (T4)
cargo test -p mind-core --lib render::rules render::overlay   # 4 + 6 passed (T5)
cargo test -p mind-core --lib render::fog                     # 5 passed (T12)
```

Full suite at stop (client/rust, build lock, 2026-10-14):
* `cargo test -p mind-core --lib --features msav-import` -> **2285 passed / 0
  failed / 4 ignored**
* `cargo test -p mind-headless --lib` -> **133 passed / 0 failed**
* `cargo test -p mind-headless --test fx_golden` -> **2 passed**
* `cargo test -p mind-gdext --lib` -> **38 passed / 0 failed**
* `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` -> clean
* `cargo fmt -p mind-core -p mind-gdext -- --check` -> clean
* `cargo run -q -p mind-headless -- parity goldens` -> every line PASS, 0 FAIL
GDScript parse gate clean after every `.gd`/`.tscn` edit; newest session log
`grep -c panic` = 0 after the last in-engine step.

In-engine gates: GDScript parse gate (`tools/godot.sh --headless --editor --quit
--path client | grep -E "SCRIPT ERROR|Parse Error"` -> empty) run after every
`.gd`/`.tscn` edit (T2, T3, T4); `grep -c panic` on the newest session log = 0
after every in-engine step; shaders_check not needed (no shader source edits).

## In-engine evidence per task (under `REPO/runs/`)

| Task | Evidence |
|---|---|
| T2 | `20261014-s3-H03-T2/`: `T2c-before/hidden/restored.png` (C hides/restores the HUD), `T2a-status-icons.png`, `T2d-build-beam-duo.png`, `T2h-bridge-links.png`, `T2f-team2-border.png`; `notes.md` (full row table) |
| T3 | `20261014-s3-H03-T3/panel.png` (Command Mode panel: dagger x2, 2 commands, 5 stances), `command_panel_json` probes, `reticle.png` (game over — see blocker), `notes.md` |
| T4 | `20261014-s3-H03-T4/`: `minimap-baseline.png` (terrain, was black), `indicator.png` (pulsing square), `indicators_json` `[[129,55,521.14,0]]` frozen while paused, `[]` after 900 ticks |
| T5 | `20261014-s3-H03-T5/`: `hover-range.png` (duo dashed range arc), `config.png` (power-node pulsing + laser rings while its config is open), `indicator-crop2.png` (red off-screen enemy line); `place_range_json` probes (duo 160 turret / mender 40 / power-node 48 / conveyor null) |
| T6 | `20261014-s3-H03-T6/`: `ambient-forced.png` (dark + core glow), `ambient-red.png` (red), `after-clear.png`, `drawlight-off.png`; boot log `packed copy of 'light' is stale; using res://shaders` |
| T12 | `20261014-s3-H03-T12/fog.png` (revealed disc + dimmed ring + black undiscovered), `fog2.png`; `fog_debug_json(1,20,20)` |

## Deviations

1. **T3 seam duplication with H08 T6a**: H08 defined `set_unit_command` /
   `set_unit_stance_named` (with `command_units_named` / `set_stance_named`) on
   `main` while this branch's T3 defined them too (H-INDEX allowed H08 to
   define them only if H03 T3 was absent; both landed). The end-of-session
   `git merge --no-edit main` conflicts in `gdext/input/mod.rs`; aborted per
   H-environment §1.0. Coordinator resolution: keep H08's two methods, keep
   H03's `config_selected`/`config_tile` and `select_only_type`/`deselect_type`
   + `DesktopBridge::retain_selection_types` (re-check whether H08 T6a also
   added filters under different names).
2. **T3 reticle**: `parity` command panel + selection verified via the real
   drag; the attack reticle was driven through the same `SetUnitCommand` path
   with a `Unit` wire target, but the visual capture on an enemy is blocked by
   the f32 wire-id bug (Blockers #2). `attack:true` rows were observed with an
   f32-exact target.
3. **T5 duo range radius 160** from `turrets::config_for` (the port's turret
   range model) vs the plan's quoted Java 110 — not changed here (bullet-range
   data question, H01/H02 area).
4. **T5 configure click**: synthetic `godot_input` clicks did not open the
   config in-engine; `MindInput.push_event({"t":"MouseButton",...})` did, and
   the overlay drew (config.png). Not a code deviation; recording the probe
   recipe.
5. **T12 static map row order / quad offset**: implemented as world y = texel
   y (shadow-pass convention) with the static quad shifted -4 px to mirror
   Java's `tilesize/2` sampling offset; no Java frame exists for a pixel diff
   (the recorded `java/step-204-erekir-sector.png` is a planet page).
6. **T2 toggle_menus announce**: `ui-hidden` is not a settings row in the port,
   so the once-announce is per-run (`_ui_hidden_warned`) instead of persisted
   (`Settings.getBoolOnce`, Arc) — nearest-compatible behavior.

## Blockers found (out of H03 scope; recorded, not fixed)

1. **H09 T8 fillItems fills the PLAYER core too** — `game/runtime.rs::team_ai_system`
   ports `Logic.java:552-561` but never checks `rule.fill_items`
   (`Logic.java:554`), so every active team's first core gets
   `getMaximumAccepted` = `i32::MAX/2` (campaign `coreIncinerates`,
   `CoreBlock.java:749-751`). Exit saves then panic on resume
   (`building_io.rs:402` `items.total += *amount`, non-wrapping). Repro +
   evidence: `runs/20261014-s3-H03-T2/fillitems-bug-evidence.txt`,
   `corrupt-sector-serpulo-170.msav`, `crash-report-10_14_2026_17_21_23.txt`.
   All session in-engine work used the workaround (delete `sector-serpulo-170*.msav`
   before `--play`).
2. **Unit-command wire ids lose precision** — `input/command_emit.rs:126`
   encodes `CommandTarget::Unit(id)` as `x = id as f32`; live ids are
   `EntitySeq` >= 1e9, which f32 rounds to multiples of 64, so right-click
   attack orders on units resolve to the wrong entity (or none; only ids that
   are multiples of 64 like the alpha's 1000000000 work). Repro in
   `runs/20261014-s3-H03-T3/notes.md`. Blocks PAR-0157's visual acceptance.
3. **`git merge --no-edit main` conflicts** (see Deviations #1).

## Ledger changes to apply (coordinator; chains.json is shared)

| Item | Proposed | Evidence |
|---|---|---|
| PAR-0095 | verified (T3) | `20261014-s3-H03-T3/panel.png` + `set_unit_command` active-flag probes |
| PAR-0157 | partially verified / keep fixing: blocked by the f32 wire-id bug | `command_targets_json` attack rows; reticle visual not captured |
| PAR-0096 | verified (T4) | `20261014-s3-H03-T4/indicator.png` + `indicators_json` |
| PAR-0246 | verified (T6) | `ambient-forced.png`, `ambient-red.png`, `drawlight-off.png`, boot warning |
| PAR-0055 / PAR-0188 / PAR-0244 | unchanged (T2 rows: i not decisive, e/g -> T18, h passed) | `20261014-s3-H03-T2/notes.md` |
| New | "Minimap attack indicators lived 15 min not 15 s; aged while paused" -> fixed T4 | unit test `indicator_expires_after_900_ticks` |
| New | "Minimap all-black on sector entry (rebuild_all row order)" -> fixed T4 | `minimap-baseline.png` |
| New | "Packed shader copies shadow client/shaders edits (light stays blend_add)" -> fixed T6 | `candidates_prefer_res_shaders` + boot warning |
| New | "Erekir fog placeholder paints the screen opaque black" -> real fog T12 | `fog.png` |
| New | "Overlay top missing (hover range, configure outline, indicators, drop zone, core radius)" -> T5 | `hover-range.png`, `config.png`, `indicator-crop2.png` |
| New | "No range circle while placing a turret" -> T5 (drawn; radius = port turret config) | `hover-range.png` |
| New (H09) | "fillItems refills every active team's core; corrupts saves (i32 overflow on load panic)" | `fillitems-bug-evidence.txt` |
| New (H08/H01) | "Unit-command wire encodes EntitySeq as f32; attack orders resolve the wrong entity" | `20261014-s3-H03-T3/notes.md` |
| New | "Sector resume panics on saves whose core holds MAX/2 item stacks" (`building_io.rs:402`) | crash report + corrupt msav |

## Session mechanics learned (for wave-3 re-runs)

* The session-3 game's frame loop freezes after any SCRIPT ERROR from an eval
  (a Rust-only `pub fn` without `#[func]` called from GDScript wedges it; the
  tick stops and screenshots go stale). Recover with
  `tools/session-play.sh 3 --play`. Two occurrences: `block_place_range`,
  `overlay_view`.
* `godot_input` mouse clicks did not reach the world in some steps; the same
  coordinates through `MindInput.push_event('{"t":"MouseButton",...}')` worked
  (T5 config probe).
* Campaign exit saves are corrupt until the H09 T8 bug is fixed; delete
  `sector-serpulo-170*.msav` before every `--play` restart.

---

# H03 — Pass 2 (session 5, 2026-10-15)

Worktree `Mindustry-Godot-session5`, branch `parity/session-5`, bridge 7010,
display :14. Started from pass-1 + `main` @ `f4333ff5`; `main` merged again
mid-session (H08 pass 2 encoding fix `2b6d7cd1`, H04 pass 2, H02/H05/H06 wave
merges) before the T3 reticle re-check; both merges clean, no conflicts.

## Commits (`git log --oneline main..HEAD`)

```
8a1eb257 Gameplay H03 T8: live DrawBlock descriptors for crafters and generators
589e41aa Gameplay H03 T7: draw fires and puddles; Java fire animation rate
9f042f98 Gameplay H03 T18: static block cache redraws state sprites on config, cracks for cached blocks
```

## Per-task status (remaining order: T18 -> T7 -> T8 -> T9 -> T10 -> T11 -> T15 -> T16 -> T17 -> T13 -> T14)

| Task | Status | Commit / evidence |
|---|---|---|
| T18 static cache state sprites + cached-block cracks | done | `9f042f98`; `runs/20261015-s5-H03-T18/` (`state-sprites*.png`, `cracks*.png`) |
| T7 fires and puddles + fire animation rate | done | `589e41aa`; `runs/20261015-s5-H03-T7/` (`fire-40/49`, `smelter-pulse` style triptych `fire-light`, `puddle`) |
| T8 live DrawBlock chains | done (cultivator headless-only) | `8a1eb257`; `runs/20261015-s5-H03-T8/` (`crafters-a/b`, `smelter-pulse`, `crafters-diff`) |
| T3 reticle visual (PAR-0157) | done (evidence only; pass-1 code) | `runs/20261015-s5-H03-T3/reticle-s5.png` + `notes.md` |
| T9 unit factories / reconstructors | not reached | |
| T10 status particles / ripples / landing dust | not reached | |
| T11 animated shields/build beams | not reached (its `force_*` fields are now present in `building_debug`) | |
| T15 permanent unit shield bubble | not reached (bug visible in `reticle-s5-crop.png`: the enemy dagger carries the pink disc) | |
| T16 FX light prims draw debug discs | not reached | |
| T17 markup in toasts / localized sector name | not reached | |
| T13 launch/landing pods | not reached (seams present: `launch_payloads_json`, `LandingPadState`) | |
| T14 mesh-null noise | not reached | |

## Tests (exact commands + results; run from `client/rust` with the build lock, after the mid-session main merge)

```
cargo test -p mind-core --lib --features msav-import   -> 2486 passed / 0 failed / 4 ignored
cargo test -p mind-headless --lib                      -> 133 passed / 0 failed
cargo test -p mind-headless --test fx_golden           -> 2 passed
cargo test -p mind-gdext --lib                         -> 44 passed / 0 failed
cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings  -> clean
cargo fmt -p mind-core -p mind-gdext -- --check        -> clean
cargo run -q -p mind-headless -- parity goldens        -> 97 PASS / 0 FAIL
```

No `.gd`/`.tscn`/shader edits -> GDScript parse and `shaders_check` gates not
needed. Newest session log `grep -c panic` = 0 after every in-engine step.

## In-engine evidence per task (under `REPO/runs/`)

| Task | Evidence |
|---|---|
| T18 | `20261015-s5-H03-T18/`: `state-sprites.png` + crop (closed door, `door-open`, sorter copper square, `switch-on` at natural 3 px, unconfigured sorter cross, unloader+container), `state-sprites-door-closed*.png` (re-configured within one frame), `cracks.png` / `cracks-hidden.png` / `cracks-diff.png` (pixel-diff triptych on a fire-damaged wall), probe `{"rows":1,"visible_rows":1,"region_misses":0}` |
| T7 | `20261015-s5-H03-T7/`: `fire-warmup.png` (alpha 0.05 fade-in), `fire-40.png`/`fire-49.png` (different frames), `fire-light.png` (glow with lighting on), `puddle.png` (water + oil discs); the 20261010 Java `step-250-fire*` frames are duo shots, not fires |
| T8 | `20261015-s5-H03-T8/`: `crafters-a/b.png` + crops (smelter flame + top, pulverizer top + rotator, generator warmup glow), `crafters-diff.png` (rotator moved in 18 ticks), `smelter-t1/t2` + `smelter-pulse.png` (flame pulses over wall time), `extras-off.png` (hiding the pass removes the flame), `power-band.png` (out-of-scope link-overlay observation) |
| T3 | `20261015-s5-H03-T3/reticle-s5.png` + crop: red rotating square + 4 spikes on the enemy dagger; `command_targets_json()` reports the enemy's live position |

## Deviations

1. **T18 base chain**: door/switch/sorter/item-source/unloader bake the plain
   `Block.region` (Java `super.draw()`), not the composed `-full` icon — the
   icon fills the sorter's transparent centre. Overlay sprites
   (`switch-on`, `unloader-center`) draw at natural region size.
2. **T18 crack overlay** iterates `!draw_dynamic` (not only `draw_cached`)
   buildings, matching Java's `tileExtraCachedView`; no fog gating (same as the
   rest of the block passes).
3. **T7 puddle z**: `Layer.debris` band (Java draws at `debris - 1`; no band
   slot). Puddle satellites use a per-draw LCG seeded by the entity index, not
   Arc `Rand(id)`; fire jitter uses a splitmix `random_seed_range`.
4. **T8 ordering**: the extras nodes carry `z_index = 1` inside the
   `Layer.block` band (the block mesh pool is created lazily after them);
   descriptors emitted before `Default` (`-bottom`, `LiquidTile`) therefore
   draw above the base, not below.
5. **T8 `ANIMATED_CHAIN_BASE`**: 7 blocks (phase-weaver, cryofluid-mixer,
   melter, separator, disassembler, spore-press, cultivator) draw the plain
   region; decided by diffing each chain block's `-full` icon against its
   region (pulverizer/steam-generator icons are identical; 5 blocks have no
   `-full`).

## Blockers / observations (out of H03 scope unless noted)

1. **Power-link overlay draws large pale rings + lines** around power
   buildings (`20261015-s5-H03-T8/power-band.png`); independent of the new
   H03 passes (persists with them hidden). The `Band_power_0` layer holds the
   G03 T7 link overlay + F6 status pass; owner H02/H09 (power graph) or G03 T7.
2. **Power graph loses links on re-placement**: replacing a sandbox
   `power-source` (or breaking/replacing a multiblock near one) can leave the
   consumer on a separate graph with `satisfaction 0`. Staging order that works:
   machine -> `power-node` -> `power-source`, each with a few ticks. (Sim side;
   H02/H09.)
3. **T15 bubble bug confirmed live** in `runs/20261015-s5-H03-T3/reticle-s5-crop.png`
   (enemy dagger carries the permanent translucent disc).
4. The pass-1 note about corrupt exit saves did not reproduce this session:
   after deleting the pass-1 game-over `sector-serpulo-170.msav` once, every
   `load_sector` + `start_sector` entry was clean (all in-engine work ran with
   the sim paused and the world restarted between builds).

## Ledger changes to apply (coordinator; chains.json is shared)

| Item | Proposed | Evidence |
|---|---|---|
| PAR-0157 | **verified** (reticle visual captured on the merged H08 fix) | `20261015-s5-H03-T3/reticle-s5.png`, `command_targets_json` row |
| New | "Static block cache never redrew door/sorter/switch/unloader state sprites; no cracks on `!drawDynamic` blocks" -> fixed by T18 | `state-sprites*.png`, `cracks*.png` |
| New | "Fires and puddles invisible; fire animation 2.25x fast" -> fixed by T7 | `fire-40/49`, `puddle.png` |
| New | "Crafter/generator `DrawBlock` chains never drawn (static icons)" -> fixed by T8 | `crafters-a/b.png` |
| New | "Power-link overlay draws large rings/lines around power buildings" (owner TBD) | `20261015-s5-H03-T8/power-band.png` |
| New | "Power graph loses links when a sandbox source is replaced / a multiblock is re-placed" (H02/H09) | staging notes in T8 `notes.md` |

## Session mechanics learned (for wave-3 re-runs)

* One-line GDScript `for c in ...: body; return out` returns after the first
  iteration — keep loops on their own lines.
* `configure_building` commands queue on the sim; with `set_paused(true)` call
  `$H.step(1)` before reading a config back.
* `$C.set_camera_scale(N)` only changes the target; set the node zoom directly
  (`$C.set_zoom(Vector2(4,-4))`) with `set_process(false)` for stable captures.
* A shell variable holding the eval prefix (`H='get_node(...)'`) is NOT
  expanded inside another variable's value — write `"$H.foo()"` inline or the
  eval gets GDScript `$H` node-shorthand errors (which trip break-on-error).

