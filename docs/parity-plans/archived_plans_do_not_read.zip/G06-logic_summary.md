<!-- SPDX-License-Identifier: GPL-3.0-only -->
# G06 summary — logic (session 4 = `parity/session-4`)

Executor: DeepSeek V4.1 Flash (opencode), worktree `Mindustry-Godot-session4`,
branch `parity/session-4`, bridge 7000, display :13.
Plan: `docs/parity-plans/G06-logic.md`. Started 2026-10-13.
**Final state for this session**: T1, T2, T3, T4, T7 landed; T4 verified
in-engine; tasks not reached are listed per-row with the reason (budget or a
missing dependency).

Start state: `git merge --ff-only main` from `257aace` to `ef54dfa` (G00 +
wave-1 merges). Baseline (`main` @ ef54dfa): `cargo test -p mind-core --lib
--features msav-import` → 2081 passed / 0 failed / 4 ignored;
`cargo test -p mind-headless --lib` → 132 passed; `parity goldens` all PASS.

## Status table

| Task | Status | Commit | Notes |
|---|---|---|---|
| T1 PAR-0106 globals | done (headless) | `54ef19f` | sim wiring + @thisx/@thisy fix; in-engine readback needs T13a's `logic_get_state` |
| T2 executor batch | done | `255a4f8` | wait 0, strictEqual, format, print names, round, setrate, message read, sensor null |
| T3 PAR-0107 lookup | done | `2a245aaf` | `logicids.dat` shipped + embedded; lookup/`@<type>Count`/logic ids |
| T4 PAR-0104 rules/flags/markers | done | `d4c033e` + `ea00a827` | live session rules/flags/markers/wave + drain + SimHost probe seams; **in-engine PASSED**; G02 T8 `sync_build_rules` half absent (noted); follow-up keeps `LogicRulesRes` ahead of the standalone copy in `rules_ref` (headless regression) |
| T5 PAR-0104 spawn/setblock/effects | not started | | budget; drain handling for SpawnWave/SetBlock + spawn/status/explosion/effect/sound/weather |
| T6 PAR-0104 messages/cutscene/objective scripts | not started | | budget; T4 already added the `MessageState` timers and announce/notify/toast drain match |
| T7 sensors/control | done (headless) | `da995e7` | turret ammo (duoAmmo), unit tiles, controlled constants, link gate, setprop fixes; remaining rows below |
| T8 turret logic control | not started | | budget; T7 hooks are in place (`logic_control` + turret `logic_sense`) |
| T9 ubind/ucontrol/LogicAI | not started | | budget |
| T10 radar | not started | | budget |
| T11 tap-to-link | **skipped** | | waiting for G02 T10 `config_tap` (absent on `main`; verified by grep) |
| T12 overlays | **skipped** | | waiting for G03 T14 `ConfigOverlay`/`config_selected` (absent on `main`) |
| T13a-d logic editor | not started | | budget; T11 (pencil) also absent |
| T14a/T14b displays | not started | | budget |
| T15 canvas blocks | not started | | budget |

## Commits (`git log --oneline main..HEAD`)

```
ea00a827 Gameplay G06 T4: keep the host rules seam ahead of the standalone copy in rules_ref
2a245aaf Fixes PAR-0107: lookup and @<type>Count from logicids.dat
da995e76 Gameplay G06 T7: logic sensor/control tables match Java (turret ammo, unit tiles, link gate)
d4c033e7 PAR-0104: world processors read/write live rules, flags, markers and wave state
255a4f8b Gameplay G06 T2: mlog executor fixes (wait 0, strictEqual, format, print names, round, setrate, message read, sensor null)
54ef19fd Fixes PAR-0106: logic globals (@tick/@time/@waveNumber...) update every tick
```

## Test commands + results (final tree, from `client/rust`, flocked)

* `cargo test -p mind-core --lib --features msav-import` → **2102 passed /
  0 failed / 4 ignored** (baseline 2081; +21 new tests).
* `cargo test -p mind-headless --lib` → **132 passed / 0 failed** (baseline
  132; the T4 `rules_ref` regression found here was fixed in `ea00a827`).
* `cargo run -q -p mind-headless -- parity goldens` → **all PASS**.
* `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` → clean;
  `cargo fmt -p mind-core -p mind-gdext -- --check` → clean.
* Per-task gates: T1 2083/0, T2 2091/0, T4 2097/0, T7 2101/0, T3 2102/0 — all
  with clippy clean.

New tests by task:
* T1: `live_tick_global_advances`, `thisx_matches_java_conv`,
  `content_constants_register` (legacy/internal skip), `update_math_matches_upstream`.
* T2: `wait_zero_yields_once`, `strict_equal_and_round_match_java`,
  `format_uses_lowest_placeholder`, `print_resolves_content_building_team_names`,
  `setrate_clamps_to_block_limits`, `read_message_returns_char_and_ignores_team`,
  `io::tests::message_read_ignores_team_gate`, `sensor_null_dead_and_string_size`.
* T3: `lookup_maps_logic_ids`, `lookup_resolves_content_from_logic_ids`.
* T4: `setrule_writes_live_rules`, `flags_roundtrip_live`,
  `map_area_rule_toggles_live_limit`, `wave_rule_sets_wave_and_wavetime`,
  `logic_events_drain_each_tick`, `message_wait_blocks_until_announcement_expires`,
  `rules::state_gated_rules_apply_to_live_halves`.
* T7: `duo_ammo_sensed`, `building_xy_tiles`, `unit_xy_tiles_and_controlled`,
  `access::control_requires_link_or_privilege`.

## In-engine evidence (`runs/20261013-s4-G06-T4/`)

Ground Zero (serpulo sector 170) after the env §4.3 clean re-import (375 nodes /
282 unlocked). `MindSimHost.logic_set_flag("allowWaves", true)` + `step(90)`:

* before: `{"waveSending":false,"waveTimer":false,...,"flags":[]}`
* after: `{"waveSending":true,"waveTimer":true,...,"flags":[]}` — the map's own
  saved world processor (code block 2: `getflag allowWaves` → `setflag false` →
  `setrule waveSending/waveTimer true`) ran against the live `CampaignRuntime`
  session.
* Files: `result.json`, `probe-before.json`, `probe-after.json`,
  `gz-flags.png`, `gz-flags-live.png`; panic count in the session log: **0**.
* Note: the wave-1 session's re-saved `sector-serpulo-170.msav` carried empty
  processor code (it predates G04 T1's restore); the clean re-import fixed the
  fixture (the imported save has all five GZ programs: spawnWave/allowWaves/
  scatterAmmo/mineOver/duoAmmo).

T1/T3/T7 are headless-only where the plan's in-engine half needs
`logic_set_code`/`logic_get_state` (T13a), which did not land this session.

## Deviations recorded

* T1: `@clientLocale`/`@clientName` use `"en"`/`"player"` literals (no core
  player-name/locale setting); `@wave` removed (not a Java constant).
* T2: `printchar` of content appends nothing (no Java emoji-char table);
  `print`/`format` names need the `LogicContentInfo` resource
  (`GlobalVars::install_world` installs it).
* T4: `run_set_rule` sets `CampaignRuntime.rules_world_dirty` only for `mapArea`
  (G02 T8 `sync_build_rules` is absent on `main`); per-team rule writes are not
  re-synced into `BuildRules` until T8 lands.
* T4: `LogicWorldState.tick/map_width/map_height` are refreshed in
  `Sim::update_logic_globals` even without `GlobalVars` (message timers).
* T7 (remaining rows, not implemented): unit base type armor (only the status
  override is read) and unit `@range`; `mineX/Y`-adjacent builder plan `buildX/Y`;
  building payload counts/`config` object sense for factories; `flag` setProp;
  `speed` setProp (status multiplier semantics); non-turret family overrides
  (driller/crafter/separator/duct/producer `progress`/`heat`, ForceProjector
  `shield`, doors `enabled`, PayloadRouter `config`, LightBlock `color`);
  `sense_content` beyond item counts (unit stacks are handled, block
  requirements are not).
* T7: `setprop totalPower` on non-buffered consumers is accepted and ignored
  (Java parity) but reports `true` as "handled".

## Blockers / dependencies (per plan §3, checked on `main`)

* G02 T10 `config_tap` → T11 skipped (verified absent with `grep`).
* G03 T14 `ConfigOverlay`/`MindInput::config_selected` → T12 skipped (verified).
* G02 T8 `sync_build_rules` → T4's G02 half skipped and noted.
* G03 T9 announce visuals → not on `main`; T6 was not started, so no decision
  needed this session (T4's `logic_ui_events` carries the Message events for
  the host).

## Ledger changes to apply (do not edit `chains.json` in the session)

| Item | Change | Basis |
|---|---|---|
| PAR-0106 | `fixed` (headless half; in-engine readback via T13a still pending) | T1 `54ef19f`, tests + sim wiring |
| PAR-0107 | `fixed` (headless, as the plan states) | T3 `2a245aaf`, `logicids.dat` shipped in `mind-core/assets/` |
| PAR-0104 | `partial` (T4 landed, in-engine PASSED; T5/T6 not started) | T4 `d4c033e` + `runs/20261013-s4-G06-T4/` |
| §4 new item 1 (wait 0 hangs) | fixed in-session | T2 test `wait_zero_yields_once` |
| §4 new item 2 (strictEqual/format/print ids) | fixed in-session | T2 tests |
| §4 new item 4 (@thisx/@thisy 8x) | fixed in-session | T1 test `thisx_matches_java_conv` |
| §4 new item 3 (sensor 0 instead of Java values/null) | partial: turret `@ammo` + unit/building `@x/@y` + null defaults landed; remaining accessors listed above | T2+T7 |
| §4 new items 5-10 | open (T11/radar/control shoot/objective scripts/canvas not started) | — |
