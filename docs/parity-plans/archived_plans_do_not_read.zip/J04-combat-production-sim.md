<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J04 — Combat targeting and production/power simulation residuals

**Goal.** Close the behaviour gaps the round-J audit found in `Turret`, consumers, crafters and
generators, plus the simulation residuals recorded by round I (I01/I02) that are still open.
Every task changes `mind-core` and needs a headless test. Visible ones also need an in-engine
check.

**Evidence.** Twin report F7, F8; `docs/parity-plans/J-field-audit.tsv` rows `Turret.java`,
`BulletType.java`, `ConsumeGenerator.java`, `PowerGenerator.java`, `GenericCrafter.java`,
`Block.java`; I01/I02 summaries (deviations).

**Depends on.** Nothing. T1 interacts with I03's logic turret control (`turrets/mod.rs:1752`):
keep `logicControlled`/`isControlled` precedence.

## T1 — Turret target selection = `Turret.findTarget` — HIGH

- Java (`world/blocks/defense/turrets/Turret.java`):
  - `unitSort = UnitSorts.closest` (`:113`). Turret-level overrides: ripple `grouped`
    (`Blocks.java:4107`), foreshadow `strongest` (`:4261`), lustre `strongest` (`:5239`), scathe
    `strongest` (`:5667`), malign `strongest` (`:6278`). Ammo-level overrides
    (`BulletType.unitSort`): one ripple shell `closest` (`:4019`); titan shells `grouped` /
    `strongest` / `grouped` (`:4702,4741,4820`). The formulas are in
    `entities/UnitSorts.java:9-40` (`strongest = -maxHealth + dst2/6400`,
    `grouped(0.003) = -team.data().getClustered(x, y) + dst * w`).
  - `ammo.unitSort` overrides when it is not `closest` (`:643`).
  - `unitFilter`/`buildingFilter` (`:115-117`): `buildingFilter` defaults to
    `targetUnderBlocks || !b.block.underBullets`.
  - Missiles (`TimedKillc`) are excluded unless `missiles` is set (`:649`).
  - `targetHealing` (`:101,638`).
  - `findTarget` (`:654-…`) uses `trackingRange()` (`trackingRange = max(range, trackingRange)`,
    `:78,223,355-356`; smite and malign set `range * 1.4`, `Blocks.java:5947,6290`).
  - `minRange` + `peekAmmo().minRangeChange` (`:80,340-344`; ripple `minRange = 50`,
    `Blocks.java:4100`). Targets inside `minRange` are not fired at, and bullet lifetime is
    clamped by `minRange()/range` for `scaleLife` (`:797`).
  - `newTargetInterval` (`:44,216,571`: the retarget timer while holding a target; sublimate 30,
    titan/afflict/scathe 40, `Blocks.java:4622,4835,5159,5666`).
  - The `minRange` ring in `drawPlace`/`drawSelect` (`:259,491`).
- Port: `find_target` (`mind-core/src/world/blocks/defense/turrets/mod.rs:2071-2100`) calls
  `targets.closest_target(…, target_under_blocks = true)`. Only `target_interval` exists, and
  `min_range_change`/`unit_sort`/`tracking_range`/`new_target_interval` are absent.
- Change:
  1. Add the fields to the turret config and the bullet def.
  2. Implement `Units.bestEnemy`/`bestTarget` with a `Sortf` enum (`closest`, `farthest`,
     `strongest`, `weakest`, `grouped(dstWeight)`). It must use the exact
     `UnitSorts` formulas and the Java tie-break (first match in `Groups.unit` order).
  3. Wire `minRange` into target acceptance and lifetime scaling, and draw the dashed ring.
- Tests: headless scenarios with two enemies at different health and distances. A strongest-sort
  turret (foreshadow) picks the high-health one; a closest-sort turret (duo) picks the near one;
  ripple (`grouped`) picks the cluster and ignores a target at 40 world units; smite keeps
  tracking out to `range * 1.4`.
- Ledger: new item "Turrets always target the closest unit (no UnitSorts/minRange/trackingRange)".

## T2 — `ConsumeItemExplode` + `itemDurationMultipliers` — HIGH

- Java:
  - `ConsumeItemExplode` (`world/consumers/ConsumeItemExplode.java`): for an item with
    `explosiveness >= threshold` (0.5), when `state.rules.reactorExplosions`, the building takes
    `damage = 4` with chance `delta * baseChance(0.06) * clamp(explosiveness - threshold)` and
    emits `Fx.generatespark` at a random in-bounds point, then fires `Trigger.blastGenerator`.
    Used by combustion and steam generators (`Blocks.java:2537,2571`).
  - `ConsumeItemEfficiency.itemDurationMultipliers`: pyratite ×3 in combustion/steam
    (`:2538,2572`), phase fabric ×(210/14) in the RTG (`:2614`). `ConsumeGenerator` applies it to
    `itemDuration`.
- Port: `Trigger::BlastGenerator` is never fired (`mind-core/src/sim/events.rs`). There is no
  explode consumer and no duration multipliers (`world/blocks/power/behavior.rs`).
- Change: add both to the consumer model, keyed off the item def's `explosiveness`. Add the
  multiplier map to `ConsumeGenerator` and the content stats (`StatValues` shows the
  multiplier rows).
- Tests: a combustion generator fed blast compound loses health over N ticks with
  `reactorExplosions` on and none with it off; pyratite burns 3× longer than coal.

## T3 — `GenericCrafter.liquidOutputDirections` — MEDIUM

- Java: `GenericCrafter.dumpOutputs` dumps `outputLiquids[i]` only toward
  `liquidOutputDirections[i]` (relative to rotation) when the array is set. Electrolyzer:
  `{1, 3}` (ozone left, hydrogen right; `Blocks.java:1397`). `DrawLiquidOutputs` draws the
  per-side regions.
- Port: `block_kind_data.rs:847-855` sets both outputs with no directions, so they dump to every
  side.
- Change: add `liquid_output_directions: Vec<i8>` to the crafter def and honour it in the liquid
  dump. Add `DrawLiquidOutputs` regions if they are missing.
- Test: a rotated electrolyzer with conduits on all four sides; ozone appears only on the left
  conduit, hydrogen only on the right.

## T4 — Generator explosions = `PowerGenerator.createExplosion` — MEDIUM

- Java `PowerGenerator` (`world/blocks/power/PowerGenerator.java`) has the fields `explodeEffect`,
  `explodeSound`, `explosionRadius/Damage`, `explosionPuddles/Range/Amount/Liquid`,
  `explosionShake(+Duration)`, `explosionBreaksProps`, `explosionScorchSize`, `explosionFireballs`,
  `explosionScaleIgnitionChance` and `explosionSpeed` (the audit lists 11 missing).
  `createExplosion` spawns puddles, scorch, fireballs, shake and the prop-breaking pass. Thorium
  reactor and the combustion/steam generators set these (`Blocks.java:2532-2534` etc.).
- Port: `world/blocks/power/explosion.rs` fires one `ReactorExplosion` (damage + radius).
- Change: port the full side effects through the FX sink (shake, scorch decal) and the sim
  (puddles via the PAR-0091 puddle system, fireballs as `Fires.create`, props).
- Test: a thorium reactor meltdown leaves the Java puddle/scorch footprint. Pin it with a
  headless checksum.

## T5 — Per-block player deposit cooldown (`Block.depositCooldown`) — LOW

- Java `InputHandler.java:2312-2313`: when `build.block.depositCooldown >= 0` the per-block
  cooldown replaces `rules.itemDepositCooldown`. 11 Serpulo turrets set it (duo 2.0, scatter 0.5,
  scorch 1.0, … `Blocks.java:3346-4337`).
- Port: only the global `rules.item_deposit_cooldown` (`input/desktop.rs:330` test).
- Change: add the block field and use it in the deposit gate. Extend the existing test.

## T6 — Round-I simulation residuals still open — MEDIUM

Each needs a failing test first.

1. **Door close guard** (PAR-0349): `Door.java:49-51` refuses to close while
   `Units.anyEntities(tile)`. The raw config path closes regardless (I01 T2 deviation).
2. **Power-turret `rangeChange`**: `TurretAmmo::Power` keeps only the bullet id, so
   `peekAmmo().rangeChange` reads 0 (I01 T9; `Turret.java:348-353`). Store the bullet def.
3. **Unit assembler**:
   - the `checkSolid`/`wasOccupied` gate and the payload hand-off to `targetBuild`
     (`UnitAssembler.java:466-472,516-532`);
   - `commandPos` passed to the produced unit (`:560-562`; I01 T11).
4. **`router` ControlBlock** (size-1 controllable block) is not ported (I01 T12 deviation 1).
5. **`AIController.faceTarget` lead**: `Predict.intercept` is not applied when units face a
   target (`mind-core/src/sim/unit_runtime.rs:6075-6090`; Java `AIController.java:121-128`).
   Reuse `combat/targeting.rs::intercept`.
6. **Sublimate activation window** (PAR-0089, still `fixing` in `chains.json`):
   `ContinuousLiquidTurret` `liquidConsumed`/activation (`parity/ledgers/combat.md`).
7. **Bullet suppression** (`BulletType.java:562-580`, `combat/bullet/mod.rs:789`) and the
   `findPierceLength`/`findLaserLength` pre-pass (`combat/bullet/kinds/laser.rs:40`).
8. **`UnitTetherComp.spawnerUnitId`** and `EmptyDataAbility` (I/O placeholders,
   `entities/comp/UnitTetherComp.java`, `TypeIO.java`). Check save round-trip of tethered units
   (`UnitSpawnAbility` children).

## Done criteria

T1–T4 landed with headless tests and the checksum goldens regenerated with reasons. T5/T6 items
are each landed or recorded as deviations with Java file:line. A summary is in
`docs/J04-combat-production-sim_summary.md`.
