<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J08 — Map editor and logic residuals

**Goal.** Close what the round-J walk still sees in the editor, and the recorded round-I
deviations of I03 (logic) and I06 (editor) that have a Java behaviour to port.

**Evidence.** Twin report rows 29-34; frames `diff/31-editor-open-side.png`,
`diff/32-edmenu-side.png`; deviation lists in `docs/I03-logic_summary.md` (passes 1-5) and
`docs/I06-custom-games-editor_summary.md` (passes 1-8).

**Depends on.**
- J02 T1 (floor edges) for the editor view.
- J06 T1/T2 for the editor menu and Map Info shells (do not duplicate here).
- T5 needs the plan-20 mod-data client half from J09 T4.

## Editor

### T1 — Building icons in the editor view — MEDIUM

- Symptom: the sandbox core draws as a grey square in the editor (`godot/31-editor-open.png`).
  Java draws the core sprite on its zone.
- Java: `EditorRenderer` draws walls/buildings with `block.fullIcon` (team-tinted where
  applicable), rotated by `build.rotdeg()` when `block.rotate && block.rotateDrawEditor`
  (`editor/EditorRenderer.java:223-232`, `world/Block.java` `rotateDraw`/`rotateDrawEditor`/
  `visualRotationOffset`; these three are missing from the port per `J-field-audit.tsv`).
- Port: I06 T7 deviation 2 says building icons draw `block.region` unrotated, with the base
  region standing in for `fullIcon` (`mind-gdext/src/editor/editor_renderer.rs`).
- Change: draw `fullIcon` (the packed `<name>-full` / generated icon), add the
  `rotateDraw*`/`visualRotationOffset` fields, and rotate per Java.

### T2 — Editor block palette content and order — MEDIUM

- Symptom: Godot's palette has a red `S` entry in row 2 (the `spawn` overlay drawn with a
  fallback glyph), which shifts the order of every later entry (`diff/31-editor-open-side.png`).
- Java `MapEditorDialog.addBlockSelection` (`editor/MapEditorDialog.java:844-870`):
  - Sort: cores first, then non-`synthetic()` before synthetic, then non-`OverlayFloor` before
    overlays (`spawn` is an overlay, so it lands among the ores), then by `id`.
  - Skip blocks whose `uiIcon` is missing, `!inEditor`, `BuildVisibility.debugOnly`, or not
    matching the search.
  - Buttons are `clearNoneTogglei` image buttons, `resizeImage(32)`.
- Change: port the filter and sort exactly, and give `spawn` its real region. Fix the
  selected-entry highlight (J06 T9.6).

### T3 — Editor input residuals — LOW

1. WASD uses physical keys, not the rebindable `Binding.moveX/Y` (I06 Pass 3 deviation 4,
   `editor/MapView.java`).
2. `resetSaved` fires on non-edit tools too (same).
3. `ecs::TeamId::SHARDED` is a stale `TeamId(0)` while `game::team::SHARDED` is 1 (I06 Pass 3
   note 5). Unify on the Java id (`Team.sharded.id = 1`) and audit callers.

### T4 — Sub-dialog residue (T12.x) — LOW

1. Objectives: `Vertices` (QuadMarker) row editing, connector/parent drag curves, per-tile
   pencil/trash popups (`MapObjectivesDialog.java`, `MapObjectivesCanvas.java`; I06 Pass 8).
2. Map generate: the generator structure passes (enemy base/ruins/launch loadout) do not run in
   the editor, and there is no `ui.loadAnd` loading screen (I06 Pass 6, T12.8).
3. Resize: Java disables OK while a size is out of range (T12.7).
4. Banned content: search matches raw names; no portrait branch (T12.3).
5. Processors: no `Icon.eye` config-open; `IconSelectDialog` has no `Icon.none` (T12.6).

### T5 — Map assets dialog (`MapAssetsDialog` + 5 views) — MEDIUM (blocked → J09 T4)

- Java: `editor/data/MapAssetsDialog.java` (274 lines) and `AssetView`, `MapBundlesView`,
  `MapContentView`, `MapImagesView` and `MapPatchesView` (~1,300 lines). These are the 5 classes
  the audit found named nowhere in the port.
- Port: `client/scenes/editor/data/map_assets_dialog.gd` is a 66-line stub.
  `MindEditor.assets()` is a stub (`mind-gdext/src/editor/mod.rs:1595-1602`), and the editor
  writes `patches: None` (`mind-core/src/maps/mod.rs:463`).
- Unblocked by J09 T4 (a `ModDataManager` host + decorator). Then port the dialog and the views
  and save `patches`/embedded assets per `WriteContext`.

## Logic

### T6 — Logic font rasterizer + `printchar` glyphs + world-processor icon tags — MEDIUM

- Java:
  - `LogicDisplay` `drawflush` text uses `Fonts.logic`; `printchar` draws glyphs
    (`world/blocks/logic/LogicDisplay.java`).
  - World processors show an icon tag through `Fonts.unicodeToName`.
- Port:
  - `mind-gdext/src/display_context.rs:130` says "Deferred: the logic font rasterizer is not
    ported yet"; `AtlasIcons::glyph` always misses (I03 Pass 1 T13).
  - The icon tag is deferred (`mind-gdext/src/sim_host.rs:8008`).
- Change: rasterise the logic font (`assets/fonts/`) into the CPU display raster, and port
  `unicodeToName` for the tag.

### T7 — Display/canvas residuals — LOW

1. The off-screen image-source pre-pass (`LogicDisplay.java:163-178`): a display used as an
   `image` source must be current even when off-screen.
2. Canvas edge sprites (`side1/side2/corner1/corner2`).
3. Canvas `@import`/`@export` PNG buttons and the 2 s auto-save timer.
4. The canvas paint surface is 300 px; Java uses 480 (`CanvasBlock.java`, I03 Pass 4).

### T8 — Logic editor pickers and polish — LOW

1. Content/effect/sound/layer pickers are text fields or plain selects. Java uses icon grids:
   - the `ui.effects.show` `EffectsDialog`, named nowhere in the port;
   - `PlaySoundStatement.showSoundSelect`;
   - the `UnitBindStatement` unit grid;
   - the `SetMarkerStatement` `Layer` list;
   - the `SetProp`/`ApplyStatus`/`Weather*` content pickers
   (`LStatements.java`; I03 Pass 5).
2. Enum popups always use 4 columns (Java passes 2/3/4 per call site). The
   `LCanvas.tooltip(Enum)` tooltips are not ported.
3. `status` shows `seconds` even for permanent statuses (`LStatements.java:1483-1485`).
4. The dragged statement does not follow the pointer. `setJumpHeights` is greedy, not Java's
   two-pass recursion. A press-release without motion opens the picker (Java clears the
   target; I03 Pass 5).
5. Sensors: building `@name`/`@id` are null; unit `@id` is the entity index (Java `UnitComp.sense`
   has no `id` case → NaN). The boss radar target matches nothing (there is no boss flag on
   `UnitTypeDef`) (I03 Pass 1 T3).

## Done criteria

T1, T2 and T6 landed with in-engine checks. T5 landed once J09 T4 is in. The rest are landed or
recorded. A summary is in `docs/J08-editor-logic-residuals_summary.md`.
