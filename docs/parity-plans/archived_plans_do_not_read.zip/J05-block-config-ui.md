<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J05 — Block configuration panels and hovered-block info

**Goal.** Tapping a configurable block opens the panel that block's Java `buildConfiguration`
builds. The hovered-block box shows the same name and bars as `Building.display`.

**Evidence.** Twin report F5; frames `diff/22-srccfg-side.png` (item source: Java icon grid vs
the Godot titled text grid), `diff/23-fed-side.png` (Java closes on select, Godot stays open),
`diff/49-hovercore-side.png` (core hover: Godot is missing the Capacity bar and shows an
oversized inventory background).

**Port today.** `client/ui/fragments/block_config_fragment.gd` routes by `config_spec` flags:
`link`, `color`, `logic`, `canvas`, `text`, else `_build_options()`. That last branch builds a
4-column `GridContainer` of text `Button`s plus `Clear`/`X` inside the 300x220 titled panel
(`PANEL_SIZE`). The spec comes from `MindInput.config_spec`
(`mind-gdext/src/input/desktop.rs:3164-…`), which already resolves the right option set per
block kind (constructor size limits, reconstructor commands, link targets). The semantics are
there; the presentation is not.

## T1 — `ItemSelection.buildTable` widget — HIGH

- Java (`world/blocks/ItemSelection.java:50-130`):
  - No title. The table background is `Styles.black6`.
  - Buttons are 40x40 `Styles.clearNoneTogglei` image buttons with the content `uiIcon` at
    `clamp(selectionSize, 0, 40)`, `tooltip(localizedName)` and a `ButtonGroup` with min-check 0,
    so a second click unchecks and sends `null`.
  - `columns` per row (`Block.selectionColumns = 4`, `selectionRows = 5`, `Block.java:273`).
  - It skips content that is `!unlockedNow()`, not on the current planet, or hidden.
  - A search field (`@players.search`, `Icon.zoom`) appears when `rowCount > rows * 1.5`.
  - The `ScrollPane` is capped at `40 * rows` and remembers `block.selectScroll`.
  - `closeSelect` hides the config after a pick (`control.input.config.hideConfig()`).
- Change: add a `MindItemSelection` widget (GDScript, under `client/ui/widgets/`) with exactly
  this behaviour. `config_spec` must carry each option's `ui_icon` region, the unlocked/planet
  filter result, the current value and the block's `selection_rows/columns`. Use it for every
  block that Java routes through `ItemSelection`:
  - `Sorter` / `InvertedSorter`
  - `ItemSource`, `LiquidSource`
  - `Unloader`, `DirectionalUnloader`, `DuctRouter`
  - `LandingPad`
  - `PayloadRouter`, `PayloadSource`
  - `Constructor` / `LargeConstructor`
  - `UnitCargoUnloadPoint`
  - `UnitFactory` (unit plans)
- Remove the titled panel and the `X` for these (Java closes on outside tap / re-tap).
- Accept: item source, sorter and unloader frames match `java/22-srccfg.png` (grid, icons,
  no title). Picking copper closes the panel (`java/23-fed.png`). Re-tapping the selected icon
  clears the config.
- Ledger: PAR-0092 → reopen with this evidence.

## T2 — `UnitFactory` and `Reconstructor` command rows — HIGH

- Java `UnitFactory.buildConfiguration` (`world/blocks/units/UnitFactory.java:285-…`):
  `ItemSelection` of plans `unlockedNow() && !isBanned()`, then a `commands` table rebuilt from
  `unit().commands` (one `Styles.clearNoneTogglei` icon button per `UnitCommand.getIcon()`), and
  the stance toggles where present.
- Java `Reconstructor.buildConfiguration` (`Reconstructor.java:215-…`): when `showAllCommands`
  or the reconstructor has an output unit, a 5-column row of 44 px `clearNoneTogglei` command
  buttons over `Styles.black6`.
- Change: build both with T1's widget plus an icon command row. The command list comes from the
  produced unit type (the port has `unit_command_by_name`, `ai/unit_command_runtime.rs:128`).
- Accept: ground factory (dagger/crawler/nova plans + commands) and an additive reconstructor
  match fresh Java captures.

## T3 — Remaining bespoke panels — MEDIUM

| Block | Java | Panel |
|---|---|---|
| `CoreBlock` | `CoreBlock.java:289-…`, only when `rules.coreBuildAndConfig` | 32 px team-colour toggle buttons for `Team.baseTeams` |
| `TargetDummy` | `TargetDummy.java:240-…` | enemy-team check, flying check, armor / reset time / hit size fields |
| `LaunchPad` | `LaunchPad.java:185-…` (campaign, not client) | `Icon.upOpen` button → `ui.planet.showSelect` destination |
| `Accelerator` | `world/blocks/campaign/Accelerator.java` | launch button (with J07 T4) |
| `MessageBlock` | text area (exists; check `maxTextLength`/newlines vs Java) | — |
| `LightBlock` | colour picker (exists; check `ColorPicker` layout vs `ui/dialogs/ColorPicker.java`) | — |

## T4 — Hovered-block info (`Building.display`) — MEDIUM

- Java: `PlacementFragment` shows `hovered()` (`ui/fragments/PlacementFragment.java`, the top
  table) through `Building.display(Table)`: name/icon, then each `block.bars` entry (health, and
  per block `addBar`: core `capacity`, power, liquids, heat, efficiency, …). The box hides while
  the mouse is over UI (`Core.scene.hasMouse()`).
- Port: `placement_fragment.gd:_update_top_table` → `SimHost.hover_info_world` /
  `building_bars_json`. On the core it shows Health but not **Capacity**
  (`diff/49-hovercore-side.png`).
- Change: make `building_bars_json` emit the Java `Block.setBars`/`addBar` list for every block
  family, in order. Audit `setBars` overrides with
  `grep -rn "addBar(\|removeBar(" ../Mindustry/core/src/mindustry/world`.
- Accept: hovering the core, a drill, a battery, a conduit and a heat block matches Java. Use
  the *real pointer* to drive hover (see `J-environment.md` §3).

## T5 — Block inventory popup and item-source centre — LOW

- `BlockInventoryFragment` (`ui/fragments/BlockInventoryFragment.java`) is a compact
  `Styles.black6` table placed next to the building. Godot draws an oversized translucent
  rectangle behind the item stack (`diff/49-hovercore-side.png`, right). Fix the panel sizing.
- `ItemSource.draw`: draw the configured item's colour in the centre (or the `cross` region
  when null). Check this against `java/23-fed.png` once T1 makes the config reachable by real
  clicks.

## Done criteria

T1 and T2 landed, and every T1 block is verified with a real tap in a sandbox against a Java
capture. T3/T4 landed or recorded. A summary is in `docs/J05-block-config-ui_summary.md`.
