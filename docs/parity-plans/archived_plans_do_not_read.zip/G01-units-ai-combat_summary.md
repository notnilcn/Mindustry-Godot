<!-- SPDX-License-Identifier: GPL-3.0-only -->
# G01 summary — units, AI and combat simulation (session 2, 2026-10-13)

Executor: DeepSeek V4.1 Flash (opencode), session 2, worktree
`/home/clintonnguyen/g/code_examples/Mindustry-Godot-session2`, branch `parity/session-2`,
bridge 6980, display :11. Plan read in full (00-environment, INDEX §3, G01 §1-§6).

Supersedes the wave-1 summary. Wave 1 landed T1-T5/T8/T9/T19 (first pass). This pass is the
dependency re-run: the branch was fast-forwarded to `b5408b9f` (wave-2 merge; `git merge --ff-only
main` clean, wave 1+2 both ancestors), rebuilt, and the session profile re-imported
(`{"nodes": 375.0, "unlocked": 282.0}`). G04 T5 (`grid.limit_area` via `Sim::apply_rules_to_world`)
landed, so T13 ran; the T10c derelict half was not needed (the plan's G02 T8 dependency is only for
`Build.validPlace` derelict repair, which no T10c step used).

## Per-task status

| Task | Status | Commit | Notes |
|---|---|---|---|
| T1 BaseBuilderAI tile scatter | done (wave 1) | `7fa485e` | units_base_build golden |
| T2 range/canAttack | done (wave 1) | `e2e2cd2` | JVM compare prints only `MISSING turret-unit-build-tower` |
| T3 line weapons | done (wave 1) | `da2da9a`, `95fdb73` | |
| T4 heal bullets | done (wave 1) | `b7d104a` | |
| T5 rule multipliers | done (wave 1) | `2e6bfb1` | |
| T6a GroundAI flowfield | **done** | `e3d7dfca` | enemy-core field walk + 40/90 retarget cadence + core override + in-range shoot gate; `get_target_tile` INF-recovery + diagonal corner trap; turret-fired missile keeps its launch angle; live Ground Zero probe (dagger walks 1136->1016, stops 73 px from the core, duo kills it) |
| T6b FlyingAI targetFlags | **done** | `4b585210` | `findMainTarget` (core-in-range, else targetFlags, else core) + spawner shuttle + `move_to_point`; live flare flies past the decoy wall to the core |
| T7 wave spawner | **done** | `5d231265` | N per spawn, flyer edge spawns, drop-zone shockwave, spawn statuses, difficulty multiplier; live probe: team-1 dagger at the spawn dies on `run_wave`, 2 daggers spawn 17.5 px apart |
| T8 player respawn | code done (wave 1); in-engine BLOCKED on the `rules.env = 31` divergence (see Blocker) | `78d2d1c` | |
| T9 possession/clear | done (wave 1) | `2433a69` | |
| T10a mining + MinerAI | **done** | `5b8aa93c` | generic `MinerComp.update` + faithful `MinerAI` + mine-command dispatch; live mono: core {} -> {"copper":28,"lead":43} |
| T10b RepairAI | **done** | `43e97ddc` | faithful `RepairAI.java:15-80` (no direct heal); heal bolts via T4's `hitTile` |
| T10c BuilderAI | **done** | `460c435d` | plan-queue rebuild/assist + `update_builders` for every builder + `BuilderPlans` on every `buildSpeed > 0` unit; live poly rebuilt a mace-destroyed wall; assist-follow/PrebuildAI deferred |
| T11 live stances | **done** | `9d02d0e6` | `UnitStancesComp`, `apply_live_unit_stance`, holdFire/boost/pursueTarget/holdPosition/mine stances, `unit_stance` JSON op; live holdFire froze shots at [10,9] |
| T12 unit cap | **done** | `1d500cb6` | `unit_cap`/`can_create_unit` + `team_unit_cap_modifier`, factory payload hold, spawn cap death |
| T13 environment | **done** | `a3bb4f28` | bounds/drowning/floor status/env death/drop-zone push/solid kill + floor fields; 5 tests |
| T14 explosions | **done** | `81dbd6dc` | unit death explosion, `explosion_absorbed` (ForceProjector polygon + base shield), `CombatEnv` fire sync |
| T15 BuildDamageEvent | **done** | `1bf6788b` | event team field + bounded log + `drain_build_damage_events` + gdext JSON |
| T16 attack tracking | **done** | `c3a5e48e` | `AttackTargetComp` + per-tick retargeting/stop-at-range + `command_targets_json` |
| T17 estimateStats/prebuild | **not reached** | | budget; needs `BlockDef.core_unit` consumers + turret DPS rows |
| T18a Defender/FlyingFollow/Hug AI | **not reached** | | budget |
| T18c Cargo/Assembler AI | **not reached** | | budget |
| T19 boss list | done (wave 1) | `245857b` | |

## git log --oneline main..HEAD

```
81dbd6dc Gameplay G01 T14: unit death explosions, ExplosionShield absorption, fire env rules
c3a5e48e Gameplay G01 T16: commanded units track attack targets; command target seam
1bf6788b Gameplay G01 T15: emit BuildDamageEvent and expose a drain seam
a3bb4f28 Gameplay G01 T13: unit environment update (drowning, floor status/drag, bounds, solid kill, drop-zone push)
1d500cb6 Gameplay G01 T12: unit cap (Units.canCreate/getCap) gates factories and spawns
9d02d0e6 Gameplay G01 T11: live unit stances (holdFire, boost, pursueTarget, holdPosition, mine items)
460c435d Gameplay G01 T10c: BuilderAI rebuild/assist and builder updates for every builder unit
43e97ddc Gameplay G01 T10b: faithful RepairAI for the repair command
5b8aa93c Gameplay G01 T10a: unit mining for all units and faithful MinerAI (mono mine command)
5d231265 Gameplay G01 T7: WaveSpawner per-spawn groups, flyer edge spawns, drop-zone shockwave, spawn statuses
4b585210 Gameplay G01 T6b: FlyingAI main target follows targetFlags
e3d7dfca Gameplay G01 T6a: GroundAI follows the enemy-core flowfield with Java targeting cadence
```

(The nine wave-1 commits are already in `main`.)

## Test evidence (all behind `flock /tmp/opencode/mg-build.lock`, `CARGO_BUILD_JOBS=6`)

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` | **2195 passed, 0 failed, 4 ignored** |
| `cargo test -p mind-headless --lib` | **132 passed, 0 failed** (incl. `units_scenarios::tests::committed_goldens_match`) |
| `cargo run -q -p mind-headless -- parity goldens` | **97 PASS, 0 FAIL** |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext` | clean |
| `tools/build.sh` | `Finished` + `sync_scenarios: synced 11 file(s)` |

## In-engine evidence (Ground Zero, panics 0 after every step)

* T6a `runs/20261013-s2-G01-t6a/`: wave dagger (1136,1532) -> (1016,514), stops 72.8 px from the
  core (`type.range*0.5`), never turns toward the decoy wall at (1204,484) (the wall was destroyed
  by the wave *flares* — the flying half, unchanged until T6b); defended run hasCore true.
  `wave-core-walk.png` (undefended run: the core dies, matching Java's msav test),
  `wave-probe-defended.png`.
* T6b `runs/20261013-s2-G01-t6b/`: team-2 flare from (1300,200) flies past the decoy wall
  (closest 24 px) to the core (1038,439); wall intact; `flare-to-core.png`.
* T7 `runs/20261013-s2-G01-t7/`: a team-1 dagger at the spawn (1152,1840) dies on `run_wave()`
  (drop-zone shockwave); two wave daggers spawn 17.5 px apart; `wave-spawn.png`.
* T10a `runs/20261013-s2-G01-t10a/`: team-1 mono at the core; 2400 ticks -> core
  `{} -> {"copper":28,"lead":43}` (MinerAI switches to the scarcer ore); `mono-delivers.png`.
* T10c `runs/20261013-s2-G01-t10c/`: mace destroys a wall at (145,35) by tick 1910; a team-1 poly
  rebuilds it by tick 2560 (the mace re-destroys; repeated rebuilds observed); `poly-rebuild.png`.
* T11 `runs/20261013-s2-G01-t11/`: team-1 dagger fired 10 shots in 300 ticks; after
  `{"op":"unit_stance","stance":holdfire}` a fresh 30 px target drew `[10,9] -> [10,9]` over
  300 ticks.
* T10b (in-engine half): a building-health readback seam is missing (`building_debug` has no
  health); acceptance stays headless (`mega_repairs_damaged_wall`: 100 -> 320 hp, mega at
  range*0.65). Noted as a deviation.
* T13/T12/T14/T15/T16: headless-only per the plan (T14's projector probe is blocked by the known
  G02 "projector uncharged with power sources" issue; the absorption geometry is covered by
  `explosion_absorbed_polygon`).

## Deviations (Java behaviour not reproduced 1:1)

* T6a: `GroundAI` stuck bookkeeping is tracked but the avoidance flag has no port consumer
  (`Flowfield.getNextTile` has no avoid parameter); `flowfield_path_type` derives via a new
  `unit_flowfield_cost` (`UnitType.initPathType`, UnitType.java:891-898) because the port never
  applied it.
* T6a drive-bys forced by the faithful movement: `BulletType.create` only stores a *unit* shooter
  on `MissileAI` (BulletType.java:943-949; the turret-fired scathe missile now keeps its launch
  angle); `get_target_tile` recovers from an INF start tile and applies the diagonal corner trap
  (Pathfinder.java:407-436); `Tile::leg_solid` implemented (`staticDarkness || floor.solid`).
* T6b: `targetFlagActive`'s "active" is `items.any()` (no live per-building block status);
  `block.targetable` is skipped (only the four world logic blocks set it false and none carry
  target flags); `randomWaveAI`/`unloadPayloads`/spawner shuffling unported.
* T7: `SpawnContext` is built in `run_wave_system` and shockwaves apply before `spawn_enemies`
  (same tick, Java does it inside); overlay spawn positions use the tile corner `x*8`.
* T10a: `find_closest_ore_for_item` is a full-map row-major scan (Java takes the first ore per
  indexer quadrant); boosting floor terms limited to `boostWhenMining || deep` (no duct/damage
  data until T13); `mineAuto`/item stances landed in T11.
* T10b: in-engine health readback unavailable (above); `holdPosition` arrived with T11.
* T10c: assist `following`/`assistFollowing`, the hold-position plan scan and PrebuildAI behaviour
  are deferred (T17 spawns prebuild defenders); a corner clip is pushed out instead of killed.
* T11: `patrol`/`ram` stances deferred (plan §2 Deferred); `stop` is input-side.
* T12: without a `CampaignRuntime` the cap is not enforced (harness worlds keep pre-T12
  behaviour); pre-existing fixtures that spawn default-team units without cores now set
  `unit_cap` (Java `Rules.unitCap` 0 + no core is a real cap of 0).
* T13: captured-sector AI death and the dead-flyer fall deferred; `floor.dragMultiplier` has no
  live consumer (the port never integrates `PhysicsComp.drag`); the bounds warp and drop-zone
  push also step `pos` (the port's AI helpers set positions directly, Java integrates `vel` in
  `VelComp.update`); the plan's `unit_out_of_bounds_dies` death expectation is wrong vs Java —
  the clamp runs before the `-250` kill check, so the test asserts the clamp; the live client's
  `rules.env = 31` divergence (T8 blocker) can make scorching-disabled units die in-engine.
* T14: lightning bolts and the fireball-bullet spread stay unported (dynamic_explosion keeps one
  `fires::create`); `Block.baseExplosiveness`/scale fields not added.
* T15: the RtsAI `damagedSet` keeps its "health below max" approximation instead of consuming
  the log (equivalent for the AI's use).
* T16: the wire `x` channel of `SimCommand::UnitCommand` is `f32` and live seqs are ~1e9 (not
  f32-representable) — tests seed `AttackTargetComp` directly; the relay id space is small and
  unaffected.
* T1 (wave 1): the plan's "queued_plans multiple of 2" note was wrong (the source tile is
  SandboxOnly); T3: `findLength` not ported; T5: leg splash has no live consumption site.

## Blockers

* T8 in-engine respawn (unchanged): the live session's `rules.env = 31` makes alpha/beta/gamma
  unsupported (`CoreBlock.requestSpawn` refuses); Java's Ground Zero runs with `env = 233`.
  Owner G04 (sector/save rules env). T13's env-death branch makes this visible in-engine too.

## Skipped / not reached (for the next executor)

T17 (estimateStats turret DPS, prebuildAi defenders, aiCoreSpawn, fillItems) and T18a/T18c
(DefenderAI/FlyingFollowAI/HugAI, CargoAI/AssemblerAI) were not started (budget). Their plan text
is unchanged. T10c's assist-follow and T14's lightning/fireballs are the known partial slices.

## Ledger changes to apply (coordinator; executors never edit `chains.json`)

| Item / new item | Status | Note |
|---|---|---|
| new: "Wave ground units walk to the nearest building instead of the enemy-core flowfield, retarget every tick" | fixed | `e3d7dfca` (headless + live Ground Zero probe) |
| new: "Flying wave units ignore `targetFlags`" | fixed | `4b585210` (headless + live flare probe) |
| new: "Wave spawner: groups split across spawns, flyers on ground spawns, no shockwave, no spawn statuses, difficulty multiplier ignored" | fixed | `5d231265` (5 headless tests + live probe) |
| new: "Mono/poly/mega idle: command controllers not run; AI units cannot mine" | fixed | `5b8aa93c`, `43e97ddc`, `460c435d` (headless + live mono/poly probes); assist-follow deferred |
| new: "Unit stances never reach live units" | fixed | `9d02d0e6` (headless + live holdFire probe) |
| new: "Unit cap is never enforced" | fixed | `1d500cb6` (3 headless tests) |
| new: "Units never drown, no floor status, survive off-map/solid tiles" | fixed | `a3bb4f28` (5 headless tests); bounds-kill is unreachable in Java (clamp first) |
| new: "Units carrying explosive items do not explode; force projectors never absorb explosions; fires ignore rules.fire/oxygen" | fixed | `81dbd6dc` (4 tests; lightning/fireballs deferred) |
| new: "BuildDamageEvent never emitted" | fixed | `1bf6788b` (drain seam + test) |
| new: "Commanded units do not follow moving attack targets" | fixed | `c3a5e48e` (2 tests) |
| PAR-0091 | (unchanged: fixing) | residuals fixed by `81dbd6dc`; lightning/fireballs remain |
| PAR-0156 | (unchanged: seeded) | T17 not reached |
| PAR-0115..PAR-0136, PAR-0139 etc. | no change | reference-soak group, not this pass |
