<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H01 — Units, AI and combat simulation — session 2 summary (written 2026-10-14, ~16:00)

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session2` (branch `parity/session-2`,
Godot bridge 6980, display :11). Start commit `4fbfcf54` (H00 on main); `git merge --no-edit main`
was run once mid-session to pick up H04's wave-1 merge (conflict resolution below). Nothing was
pushed and `main` was never merged into. `runs/` evidence is under
`REPO/runs/20261014-s2-H01-T{1,2,3,14,15}/`.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T14 in-engine probe (uncommitted baseline) | done (recorded, no commit) | — (evidence in `runs/20261014-s2-H01-T14/baseline.json`) |
| T1 building positions / bullet tile math | **done** (headless + in-engine) | `8e7b68b8` |
| T15 pathfinder tile data + per-cost weights | **done** (headless + in-engine) | `c6bcf17a` |
| T2 per-mount weapon targets | **done** (headless + in-engine probe) | `36e76496` |
| T3 player lifecycle (PAR-0174) | **done** (headless + in-engine) | `8a1c4a56` |
| T4 velocity model (PAR-0202) | not reached | — |
| T5 drag / captured-sector death | not reached | — |
| T6 flying wrecks | not reached | — |
| T7 `explosion_absorbed` semantics | not reached | — |
| T8 `targetFlagActive` status | not reached | — |
| T9 Defender/FlyingFollow/Hug/NoAI dispatch | not reached | — |
| T10 PAR-0156 residuals | not reached | — |
| T11 avoidance | not reached | — |
| T12 BuilderAI assist | not reached | — |
| T13 Cargo/Assembler dispatch | not reached | — |
| T14 commit (headless acceptance test) | not reached | — |

Order executed: T14 baseline probe -> T1 -> T15 -> T2 -> T3 (the plan's §3 order, T15 pulled
forward per the plan's own "T1 -> T15" pair). The plan's "after T1, T2, T4 and T14 rebuild +
`session-play.sh --import` + T14 probe" was run after T1, T15 and T2 (T4/T14 not reached).

## `git log --oneline main..HEAD`

```
8a1c4a56 Fixes PAR-0174: player respawn retries without a team, dock release, kill seam, unlock feed
80f2c110 Merge branch 'main' into parity/session-2
36e76496 Gameplay H01 T2: AI weapons pick per-mount targets like AIController.updateWeapons
c6bcf17a Gameplay H01 T15: Java Pathfinder tile data and per-cost weights (ground units avoid deep water)
8e7b68b8 Gameplay H01 T1: Java world convention for building positions and bullet tile lookups
```

71 files changed, +2725 / -3705 vs `main` (the bulk of the deletions is H04's merge landing
`main`'s side of the shared files in `80f2c110`).

### Merge conflict (`80f2c110`)

`git merge --no-edit main` conflicted only in `client/rust/mind-core/src/sim/combat_tests.rs`:
both sides appended tests at the end of the file (HEAD: the T1/T2 tests; main: H02 T16's
`turret_leads_moving_target`). Resolved by keeping **both** sides' tests (no production hunk was
touched) and re-running the full suite + clippy + goldens afterwards, all green. No other file
conflicted.

## Test commands and results (final, after T3)

Run from `WT/client/rust` with `L="flock /tmp/opencode/mg-build.lock"; export CARGO_BUILD_JOBS=6`.

| Command | Result |
|---|---|
| `$L cargo test -p mind-core --lib --features msav-import` | **2274 passed / 0 failed / 4 ignored** (main baseline 2211 + H04/H02 merges + 3 T1 + 6 T15 + 5 T2 + 3 T3 new tests) |
| `$L cargo test -p mind-headless --lib` | **132 passed / 0 failed** |
| `$L cargo test -p mind-gdext --lib` | **34 passed / 0 failed** |
| `$L cargo run -q -p mind-headless -- parity goldens` | **all PASS** (0 non-PASS lines) |
| `$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean (also `-p mind-headless` for the T15 change) |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| GDScript gate | not run (no `.gd`/`.tscn` touched) |

Known pre-existing issue left alone: `cargo fmt -p mind-headless -- --check` prints a diff at
`units_scenarios.rs:920` on `main` before my changes (I re-verified with the file stashed); it is
not mine and I did not touch it.

## In-engine evidence per task

All runs: `tools/session-play.sh 2 --import` -> `{"nodes": 375.0, "unlocked": 282.0}`;
`grep -c panic` on the newest `$U/logs/*` = **0** after every step.

### T14 baseline (before T1) — `runs/20261014-s2-H01-T14/baseline.json`
Ground Zero, drill at (130,48) + duo at (132,48), 1800 ticks of ammo, `run_wave()`:
wave 1 = **one dagger** (`getSpawned(0)`), spawned at (1064,1842); it walks south along x=1136
and **vanishes between tick 22859 and 23459 without reaching the core** — the pre-T15 drowning
symptom. `hasCore` true (no fight happened). `player_unit_pos()` = (1036,444) =
`best_core_position() + (4,4)` (the pre-T1 half-tile building centre). Screenshot
`baseline-dagger-gone.png`.

### T1 — `runs/20261014-s2-H01-T1/probe.json`
`has_player_unit` true; **`player_unit_pos()` = (1032.0, 440.0) == `best_core_position()`**
(before T1: (1036,444)). Pointer: the core-spawned alpha now sits exactly on `129*8, 55*8`.
Screenshot `duo.png` (camera on tile 132,48: the drill+duo pair). Post-T1 T14 probe re-run: the
wave-1 dagger still vanishes ~1200 ticks after `run_wave()` (T15 not yet applied).

### T15 — `runs/20261014-s2-H01-T15/probe.json`
`set_paused(true); run_wave()`; the dagger detours west
(1144,1749 -> 1138,1259 -> 1112,1142 -> 1096,1038 -> 1079,919 -> 1018,816 -> ...) and **stops at
(1008, 508.9)**, 73 px from the core (dagger `range*0.5` = 75). Every sampled tile's floor is
snow/ice/basalt; `tile_debug(136,137)` is `deep-water` (the pool the probe used to walk into).
HUD message "Core is under attack!" (the dagger reached and engaged the core). Headless
`msav_tests::ground_zero_wave_dagger_avoids_deep_water`: 3000 ticks, 100 samples, `wet` 6x (from
shallow water crossings), `max_drown = 0`. Screenshots `deep-pool.png` (renders black - outside
the sector's play area) and `dagger-at-core.png`.

### T2 — `runs/20261014-s2-H01-T2/probe.json`
Belts at (140..144,60); a horizon spawned at (1150,500) flies to the core (the sector's core is
always a valid FlyingAI main target, exactly the flakiness the plan's verification note warned
about). A horizon spawned **directly above the belt line at (1136,484)** produced
`drain_build_damage_json` entries for all five belts shortly after the spawn (autoDropBombs).
Screenshot `horizon.png` (camera did not move from the core; the damage log is the evidence).

### T3 — `runs/20261014-s2-H01-T3/probe.json` (closes PAR-0174)
`debug_kill_unit(1000000000)` -> true; `step(2)`/`step(20)` -> `has_player_unit()` false;
`step(40)` -> true, a **new alpha id 1000000001, kind "Player", at (1032,440)** (60-tick
`deathDelay`). Possession round trip: spawn a team-1 dagger id 1000000002 ->
`{"op":"unit_control","unit":1000000002}` -> the dagger row is `"kind":"Player"` and the alpha row
is gone -> `{"op":"unit_clear"}` -> a new alpha id 1000000003 `"kind":"Player"` and the dagger is
back to `"kind":"CommandAI"` (exactly one player entity). Screenshot `respawn.png`.

### Open item from H-INDEX round 2 (factory-built dagger vanished after a move order on Onset)
**Not reproduced** in a 300-tick Ground Zero check (spawned a team-1 dagger, `unit_command`
move to (1200,560): the dagger neither moved nor vanished). The Onset-specific fixture (and T9,
the other planned window) was not reached; nothing filed.

## Deviations from Java (each with file:line)

1. **T1** — `Damage.collideLine`'s own tile walk (`combat/damage/line.rs::to_tile`) still uses
   `floor`, not Java's `World.toTile` (`World.java:174`); the task's change list scoped T1's
   raycast change to `collide_bullet` only. Lasers/line damage therefore still round differently
   from Java at tile boundaries.
2. **T1** — H02's sites keep the half-tile convention (per the plan): `payload_block.rs:339-340`,
   `power/nodes.rs:70-101`, `power/explosion.rs:50-51`, and `BuildHarness::tile_center`
   (`world/harness.rs:614`, used as a generic "somewhere in this tile" point by
   `sim/runtime.rs::run_team_base_builder`).
3. **T1** — `AiCtx::pathfind` now judges arrival against the final destination and steers
   intermediate waypoints with a zero radius (`ai/ai_controller.rs:297-306`), matching the
   sibling `update_ground` (PAR-0140) and `CommandAI.java:403-405`; without this, Java tile
   centres (8 px apart) made every unit "arrive" on its first tick.
4. **T15** — packed building health uses the block def's max health (the packing layer has no ECS
   access to `Health`); Java reads `build.health` (`Pathfinder.java:270`). Identical for an
   undamaged building, divergent for a damaged one (cost `health*5`).
5. **T15** — `Tile.checkSolid()` has no port override, so that term of `Tile.solid()`
   (`Tile.java:462-464`) is absent (grep `fn check_solid`).
6. **T15** — Java's `searches` array is replaced by the `i32::MAX` unreached sentinel
   (`Pathfinder.java:497-521`), so a unit standing on an impassable tile descends to the cheapest
   passable neighbour (the pre-existing port behaviour; Java stays). Documented in
   `flowfield.rs::get_target_tile`.
7. **T15** — `ControlPathfinder.costGround` (`ControlPathfinder.java:33-42`) is now implemented
   in `ai/control_pathfinder.rs` (own cost, enemy solids at `wallImpassableCap`); only its
   passability is computed (the port's A* takes booleans, not cost weights).
8. **T2** — `AiWeaponCtx` gains a `should_shoot` field for `BuilderAI.shouldShoot`
   (`BuilderAI.java:262-264`); the plan's struct had four fields.
9. **T2** — the port's per-mount search radius equals Java's (`weapon.range() + |shootY|`,
   `Weapon.java:453-455`), so the plan's "dagger engages a core-shard at 161 px" is not
   observable (the search is tighter than the shoot gate); the test drives the shoot gate
   directly on a non-`singleTarget` unit (`spiroct`). The content dagger is `singleTarget`, so
   its mounts always take the main target (`AIController.java:218`).
10. **T2** — `RepairAI` uses `Unit.controlWeapons` (`RT::control_weapons_for`) instead of the AI
    targeting pass, because its own-team building target is rejected by
    `Units.invalidateTarget` (`RepairAI.java:19-32`); `update_ai_weapons_for` builds a one-off
    `TargetQueries` for the enemy-targeting branch.
11. **T3** — the unlock feed pushes into H04 T2's landed `CampaignHookQueues.unlocks`
    (`game/runtime.rs:93`, `CampaignCoreQueues` resource) rather than the coordinator's
    `CampaignRuntime.pending_unlocks` name, because H04 T2 landed with that shape
    (`UnlockRef::Unit` exists there and the doc comment already said "pushed by H01 T3").
12. **T3** — `clear_unit`'s dock branch uses the *core's* `unitType`→`DockedType` path as before;
    the Java `unit.set(player.unit())` position/rotation copy (`InputHandler.java:851-854`) is
    unchanged from the port's existing half.

## Blockers

* None for the four completed tasks. Context budget is the reason T4+ were not reached.
* T14's headless acceptance test (`ground_zero_wave_one_dies_to_drill_fed_duo`) is **not**
  written; the in-engine probe is recorded but the T14 acceptance (wave 1 killed by one
  drill-fed duo, `hasCore` true) was not re-run after T15 with the duo in place. The T15 in-engine
  run shows the dagger reaching the core and attacking it, so the duo fight is the remaining half.
* The plan's H02 consumers of T1 (`power/nodes.rs`, `power/explosion.rs`, `payload_block.rs`) are
  still half-tile (H02 owns them) — the renderer/targeting will be 4 px off for those call sites
  until H02 lands.

## Ledger changes to apply (expanded plan §4)

| Item | Now | Proposed | Note |
|---|---|---|---|
| PAR-0174 | fixing | **verified** | `8a1c4a56`; in-engine respawn (60 ticks) + possession round trip, `runs/20261014-s2-H01-T3/probe.json` |
| PAR-0202 | fixing | unchanged (fixing) | T4 not reached |
| PAR-0156 | seeded | unchanged | T10 not reached |
| PAR-0091 | fixing | unchanged | T7 not reached |
| PAR-0229 | verified | note: mount half of `FlyingAI.findTarget` was inverted, fixed by `36e76496`; per-mount `findTarget` and the target's `hitSize/2` now match `AIController.updateWeapons` | reopen-note only |
| PAR-0175 | verified | note: the dock branch left the possessed unit player-controlled; fixed by `8a1c4a56` (`release_unit_to_ai`) | |
| PAR-0140 | fixed | note: `AiCtx::pathfind` now judges arrival against the destination only (T1), same rule as `update_ground` | |
| (new) | — | file "Buildings sit half a tile off for odd sizes and bullets look up tiles with floor (units shoot past walls)" — **fixed by `8e7b68b8` (T1)** | `WorldGrid::to_tile` + `tile*8 + offset` |
| (new) | — | file "Ground Zero wave units walk into deep water and drown (flowfield has no floor data/costs)" — **fixed by `c6bcf17a` (T15)** | in-engine + `msav_tests::ground_zero_wave_dagger_avoids_deep_water` |
| (new) | — | file "AI weapons share one target, use the shooter's hitSize for range, never auto-drop bombs (horizon)" — **fixed by `36e76496` (T2)** | 5 new tests |
| (new) | — | file "Player lifeless without a first successful core spawn; `unitClear` dock branch left two player units; no kill seam; `playerSpawn` unlock dropped" — **fixed by `8a1c4a56` (T3)** | PAR-0174/0175 reopen notes |
| (new) | — | note for H03: `RT::AiWeaponsState` (bomber target / no-target timer / retarget / main target) is new per-unit state that H04's save path does not cover yet | §6 seam list |

---

## Pass 2 (session 5, from T4) — 2026-10-14/15

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session5` (branch `parity/session-5`,
Godot bridge 7010, display :14). Start commit `0b15475c` (main @ H05 wave-2 merge). `git merge --no-edit
main` ran after T4 (`84478e64`; picked up H06 wave 2 + H03 wave 2) and once more after T5
(`b4c51465`; H07 wave 3) — no conflicts; the full suites were re-run after each merge. Nothing pushed;
`main` never merged into. Evidence under `REPO/runs/20261014-s5-H01-T4/`.

### Per-task status

| Task | Status | Commit |
|---|---|---|
| T4 velocity model (PAR-0202) | **done** (headless + in-engine) | `8f803021` |
| T5 drag / captured-sector death / `hasSpawns` push | **done** (headless only, per plan) | `cb9cb9e2` |
| T6 flying wrecks | not reached | — |
| T7 `explosion_absorbed` semantics | not reached | — |
| T8 `targetFlagActive` status | not reached | — |
| T9 Defender/FlyingFollow/Hug/NoAI dispatch | not reached | — |
| T10 PAR-0156 residuals | not reached | — |
| T11 avoidance | not reached | — |
| T12 BuilderAI assist | not reached | — |
| T13 Cargo/Assembler dispatch | not reached | — |
| T14 commit (headless acceptance + final probe) | not reached | — |

### `git log --oneline main..HEAD`

```
b4c51465 Merge branch 'main' into parity/session-5
cb9cb9e2 Gameplay H01 T5: unit drag, captured-sector AI death and hasSpawns drop-zone push
84478e64 Merge branch 'main' into parity/session-5
8f803021 Fixes PAR-0202: units integrate velocity with drag and tile collisions (VelComp/EntityCollisions)
```

### Test commands and results (final, after T5 + both main merges)

Run from `WT/client/rust` with `L="flock /tmp/opencode/mg-build.lock"; export CARGO_BUILD_JOBS=6`.

| Command | Result |
|---|---|
| `$L cargo test -p mind-core --lib --features msav-import` | **2402 passed / 0 failed / 4 ignored** (H06/H07 merges included) |
| `$L cargo test -p mind-headless --lib` | **133 passed / 0 failed** |
| `$L cargo test -p mind-gdext --lib` | **40 passed / 0 failed** |
| `$L cargo run -q -p mind-headless -- parity goldens` | **all PASS** |
| `$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| GDScript gate | not run (no `.gd`/`.tscn` touched) |

Goldens regenerated (T4, reason "VelComp.update + EntityCollisions.move replace the kinematic mover",
manifest sha256 updated in the same commit): `units_legs_ik` (`6fd0ccdc…`), `units_spawn_path_arrive`
(`543a7b29…`).

### In-engine evidence (T4 + the pre-T14 probe), `runs/20261014-s5-H01-T4/`

`tools/session-play.sh 5 --import` -> `{"nodes": 375.0, "unlocked": 282.0}`; `grep -c panic` = **0** after
every step.

* **PAR-0202 sandstorm drift**: Ground Zero, `debug_create_weather("sandstorm", 1.0, 1200.0)` (wind
  `(0.6096, 0.7927)`), an idle team-1 flare spawned at (1100,420): `unit_debug_json()` vel at spawn
  `(0.0055, 0.0072)` = the Java steady state `0.1/(81π)/0.04 ≈ 0.00943`; after `set_paused(true)`
  + `step(600)` the flare is at `(1105.71, 427.43)` — drift 8.84 px at angle 52.44°, wind angle 52.43°
  (`probe.json`; screenshots `wind-before.png`, `wind-after.png`).
* **Pre-T14 wave-1 probe (after T1/T2/T4/T5)**: drill at (130,48) + duo at (132,48) (duo ammo 20 at
  wave time), `run_wave()` = wave 1, one dagger; sightings `(1144,1844) -> (1144,1574) -> (1144,1280)
  -> (1096,1013) -> (1016,742) -> (1008,508) -> gone` (~3000-3600 ticks after the wave); final
  `get_hud_state()` = `{"enemies":0,"enemyCores":0,"gameOver":false,"hasCore":true,"sectorName":
  "groundZero"}`, `has_player_unit()` true, duo alive with 30 ammo (`wave1-cleared.png`).
* T5 is headless-only per the plan (no in-engine half).

### Deviations from Java (Pass 2; each with file:line)

1. **T4** — `unit_physics_system` (separation push) still writes `Pos` directly; upstream `PhysicsProcess`
   also moves bodies directly, so this is by design (`sim/unit_runtime.rs`).
2. **T4** — the port's `CommandAI` move-target smoothing is a port approximation
   (`ai/types/command.rs`): with `EntityCollisions` it also requires the unit's `hitboxTile` box to be
   clear (`ControlPathfinder::segment_clear`) and `line_clear` carries the
   `Pathfinder.getTargetTile` diagonal-corner rule (`Pathfinder.java:426-429`). Without these a unit
   hugging a wall end aimed past the corner and jammed on it.
3. **T4** — `MissileAI`'s `buildOn()` enemy-building check now happens at the tick-start position
   (`vel_update` order, Java `Component.update` order) instead of the in-place integrated position; one
   tick of difference on the contact frame (`ai/types/missile.rs`).
4. **T4** — `hitSize` is capped at `min(hitSize*0.66, 7.8)` for collision (`HitboxComp.hitboxTile`); the
   port also uses that box for the pathing clearance check above (Java pathing has no box check).
5. **T5** — `players.size == 0` for `Team.isOnlyAI()` is approximated by `team != rules.defaultTeam`
   (single-local-player port; `UnitComp.java:750-753`).
6. **T5** — `hasSpawns`'s "wave-team cores" test uses the port's live core scan
   (`has_core_of_team`, `unit_runtime.rs`) rather than `TeamData.cores`, equivalent for the live world.
7. **T4/T5 test adjustments** — `commanded_dagger_chases_moving_target` gives the fleeing target the
   `holdFire` stance (with the real velocity model its return fire lands; the old kinematic mover masked
   it); `command_ai_ground_order_routes_around_walls` now targets a point north of the wall end (the
   corner-jam follow-up below); `team_ai_orders_idle_wave_units_at_an_enemy_core` ticks twice (the first
   tick only writes `vel`); `drop_zone_pushes_player_units` adds a spawn-group list for `hasSpawns`;
   `ground_zero_wave_destroys_undefended_core` runs `waves: true` + `session.spawn_count = 1` because a
   `waves: false` session is captured under Java rules and its wave-team daggers die (`Sector.java:181-184`).
8. **T4** — AI movement tests that drive a controller function directly now call `UnitHarness::vel_update`
   once per simulated tick to reproduce the `@MethodPriority(-1)` order.

### Blockers / open findings

* **Corner-jam follow-up (T4)** — a ground move order whose smoothed waypoint lies just past a wall end
  can still trap the unit at the wall corner when its rounded tile flips on the tile boundary (observed
  while testing; the `line_clear`+`segment_clear` fixes cover the tile-centre form of it). Proposed new
  ledger item: "Ground move orders can jam on a wall-end corner; the waypoint raycast ignores the
  unit's sub-tile offset". Repro: the original `command_ai_ground_order_routes_around_walls` geometry
  (destination east of the wall at the same row, start row aligned with the wall-end tile boundary).
* T14's acceptance test (`ground_zero_wave_one_dies_to_drill_fed_duo`) is still **not written**; the
  in-engine probe passes (above), so only the headless half remains.
* H02 residuals from pass 1 still stand: `power/nodes.rs`, `power/explosion.rs`,
  `payload_block.rs` keep the half-tile convention (H02 owns them).

### Ledger changes to apply (Pass 2)

| Item | Now | Proposed | Note |
|---|---|---|---|
| PAR-0202 | fixing | **verified** | `8f803021`; in-engine sandstorm drift (8.84 px/600 ticks at the Java steady state), `runs/20261014-s5-H01-T4/probe.json` |
| (new) | — | file "Units ignore external velocity: wind/knockback/warp discarded; no tile collision resolution; ice/status drag absent" — **fixed by `8f803021` (T4) + `cb9cb9e2` (T5)** | PAR-0202 is the same item; T4/T5 close it |
| (new) | — | file "Enemy AI units keep living on a captured campaign sector; drop-zone push runs on non-`hasSpawns` maps" — **fixed by `cb9cb9e2` (T5)** | `UnitComp.java:750-753,793`; `GameState.java:68-70` |
| (new) | — | file "Ground move orders can jam on a wall-end corner (waypoint smoothing ignores the unit's sub-tile offset)" — open, repro above | follow-up, not fixed by T4 |

---

## Pass 3 (session 5, from T6) — 2026-10-15

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session5` (branch
`parity/session-5`, Godot bridge 7010, display :14). Start commit `d8cea15a`
(main @ the H01 pass-2 merge); `git merge --no-edit main` ran once after T9
(`e763b76e`, H02 pass 2 + the H01-T1 residual, no conflicts) and main was still
at `a093a1b2` at the end (no further merge needed). Nothing pushed; `main` never
merged into. Evidence under `REPO/runs/20261015-s5-H01-{T6,T14}/`.

### Per-task status

| Task | Status | Commit |
|---|---|---|
| T6 flying wrecks | **done** (headless + in-engine) | `fcfa753e` |
| T7 `explosion_absorbed` semantics | **done** (headless only, per plan) | `ebe8c37d` |
| T8 `targetFlagActive` status | **done** (headless only; in-engine fixture impossible, see below) | `d8ab1c64` |
| T9 Defender/FlyingFollow/Hug/NoAI dispatch | **done** (headless only, per plan) | `8f3477e3` |
| T14 headless acceptance + final probe | **done** (headless + in-engine) | `0e1f9b60` |
| T10 PAR-0156 residuals | not reached | — |
| T11 avoidance | not reached | — |
| T12 BuilderAI assist | not reached | — |
| T13 Cargo/Assembler dispatch | not reached | — |

Order executed: T6 -> T7 -> T8 -> T9 -> T14 (the plan's §3 order with T10-T13
deferred by budget). No task was skipped for a missing dependency.

### `git log --oneline main..HEAD`

```
0e1f9b60 Gameplay H01 T14: Ground Zero wave-1 fight acceptance test
e763b76e Merge branch 'main' into parity/session-5
8f3477e3 Gameplay H01 T9: DefenderAI, FlyingFollowAI, HugAI and NoAI run live
d8ab1c64 Gameplay H01 T8: targetFlagActive uses the Java building status
ebe8c37d PAR-0091: ExplosionShield absorption semantics (ignoreTeam, first shield only)
fcfa753e Gameplay H01 T6: dead flying units fall as wrecks before crashing
```

### Test commands and results (final, after T14 + the main merge)

Run from `WT/client/rust` with `L="flock /tmp/opencode/mg-build.lock"; export CARGO_BUILD_JOBS=6`.

| Command | Result |
|---|---|
| `$L cargo test -p mind-core --lib --features msav-import` | **2434 passed / 0 failed / 4 ignored** (post-merge; pass 2 ended at 2402) |
| `$L cargo test -p mind-headless --lib` | **133 passed / 0 failed** |
| `$L cargo test -p mind-gdext --lib` | **40 passed / 0 failed** |
| `$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| `$L cargo run -q -p mind-headless -- parity goldens` | **all PASS** |

New tests, 15: T6 `dead_flare_falls_then_crashes`, `ground_unit_dies_instantly`,
`wreck_destroyed_by_overkill`; T7 `no_absorption_without_ignore_team`,
`only_first_shield_absorbs`; T8 `java_status_follows_building_comp`,
`java_status_empty_turret_is_no_input`, `java_status_battery_uses_charge`,
`target_flag_active_uses_java_block_status`; T9 `oct_follows_healthiest_ally`,
`quell_follows_ally_on_wave_team`, `quell_uses_flying_ai_on_player_team`,
`renale_hugs_target`, `dummy_never_moves`; T14
`ground_zero_wave_one_dies_to_drill_fed_duo`. Net +32 over pass 2 (2402 -> 2434
incl. the H02 merge tests).

### In-engine evidence

All runs: `tools/session-play.sh 5 --play` -> `{"nodes": 375.0, "unlocked": 282.0}`;
`grep -c panic` on the newest `$U/logs/*` = **0** after every step.

* **T6** (`runs/20261015-s5-H01-T6/probe.json`): Ground Zero, a team-2 flare
  spawned at (1100,600); `debug_kill_unit(id)` -> true; after `step(10)` the
  wreck is still listed (`health 0.0`, still drifting (1119.35,591.56)); after
  `step(60)` it is gone. Matches the Java `fallSpeed` fall (56 ticks).
* **T7**: headless only (the plan's verification for this residual is headless;
  live item-carrying enemies with shield projectors are needed).
* **T8**: **not run in-engine — the plan's fixture is impossible.** `SolarGenerator`
  clears `BlockFlag.generator` (`SolarGenerator.java:12-14`), so a flare
  (`targetFlags {generator, null}`) can never target a `solar-panel` in Java or
  in the port; Ground Zero's buildable limit area (x 90..160, y 20..80, the rest
  is ice/static wall) has no spot far enough from the core to separate a flagged
  target from `FlyingAI.findMainTarget`'s final out-of-range core fallback. The
  change is verified headless (`java_status_*` + `target_flag_active_*`).
* **T9**: headless only (plan: these types do not appear on early Serpulo
  sectors). Optional repo probe not run.
* **T14** (`runs/20261015-s5-H01-T14/probe.json`, screenshot
  `wave-cleared.png`): the persisted session save was already past wave 1
  (`waveTimer` false, wave 2), so `run_wave()` spawned the wave-2 group
  (**1 dagger + 2 flares**); the drill-fed duo killed both flares and the
  dagger; final `{"enemies":0,"gameOver":false,"hasCore":true,"wave":3}`,
  `has_player_unit()` true, duo alive with 16 ammo. Wave 1 (= 1 dagger) was
  covered by the pass-2 probe in `runs/20261014-s5-H01-T4/`.

### Deviations from Java (Pass 3; each with file:line)

1. **T6** — a `Falling` wreck runs only the bounds block of the environment
   pass (`environment.rs::update_falling_wreck`); Java runs the full
   `UnitComp.update` (`UnitComp.java:803-830`). Kind kinematics/status/abilities
   are skipped for the wreck (the plan's "keep it simple: bounds only").
2. **T6** — dead units skip the whole weapon pass
   (`weapons/mod.rs::update_weapons`), while Java's `WeaponsComp.update` still
   runs on dead units (a stale `mount.shoot` can fire during the fall). The
   plan directed the skip; shoot-on-death is unaffected.
3. **T6** — the controller gate uses `Health.dead` (port) for Java's
   `dead || health <= 0` (`UnitComp.java:859`); equivalent.
4. **T8** — `productionValid()` and `block.targetable` are omitted (Java's base
   `productionValid` is always true and the port has no `targetable` field);
   `inactiveUnitFactory` maps to the port's `Inactive` (the target predicate
   only tests `!= noInput`) (`BuildingComp.java:638-652`).
5. **T8** — the attack map's `BeamNode`/`HeatCrafter`/`Incinerator`
   `status()` overrides are not transcribed (their blocks carry no vanilla
   `targetFlags`); the base rule covers them.
6. **T9** — `DefenderAI`'s `u.targetable(team)`/payload/fog terms are
   approximated by `def.targetable && !dead` (`DefenderAI.java:30`); the ally
   search is own-team so fog does not apply.
7. **T9** — `HugAI`'s explicit boost-descend (`HugAI.java:57-59`) relies on the
   shared `movement::update_kinematics` canBoost approach instead of running in
   the controller.
8. **T9** — `attack_map_pushes_from_drop_zone` (T5) now registers both cores
   and keeps the unit on `NoAI`: the old form passed because the ground
   controller walked the unit toward the enemy core; with `NoAI` the drop-zone
   push is the only velocity source (`UnitComp.java:734-744`).

### Blockers / open findings

* **T10-T13 not reached** (budget). T10 (PAR-0156), T11 (avoidance), T12
  (BuilderAI assist) and T13 (Cargo/Assembler dispatch) are independent and
  remain on the plan's order.
* **T8 in-engine fixture impossible** (see above); headless-only, documented.
* **T14 in-engine wave 1** could not be re-run this pass: the session save
  persists sector progress and was already at wave 2. Wave 1 evidence is the
  pass-2 probe; a clean `--import` re-run would reset it.
* **Corner-jam follow-up (from pass 2) is still open**: T9 did not touch ground
  move orders, so it was not reproduced; the T11 avoidance work is the natural
  window.
* H02 residuals from pass 1 still stand (their half-tile sites; H02 owns them);
  the H02 pass-2 merge landed the `config_tap` work.

### Ledger changes to apply (Pass 3)

| Item | Now | Proposed | Note |
|---|---|---|---|
| PAR-0091 | fixing | **fixed** | T7 `ebe8c37d` (`explosion_absorbed` semantics) + H09's landed `dynamic_explosion` lightning/fireballs/stagger; `runs/20261015-s5-H01-T6/` has no direct capture (headless tests) |
| (new) | — | file "Dead flying units vanish instead of falling as wrecks" — **fixed by `fcfa753e` (T6)** | `UnitComp.java:980-991,803-830`; in-engine 56-tick fall |
| (new) | — | file "Flying target flags ignore working buildings without items (`targetFlagActive` uses `items.any()` only)" — **fixed by `d8ab1c64` (T8)** | `AIController.java:277-284`, `BuildingComp.java:638-652` |
| (new) | — | file "DefenderAI/FlyingFollowAI/HugAI/NoAI fall into the generic ground/flying branch (oct/renale/dummy never run their controllers)" — **fixed by `8f3477e3` (T9)** | 5 tests |
| (new) | — | file "Ground Zero wave-1 fight never verified" — **fixed by `0e1f9b60` (T14)** | headless fight + two in-engine probes |
| (note) | — | `attack_map_pushes_from_drop_zone` was passing for the wrong reason (controller velocity); T9 fixed the fixture | `cb9cb9e2` item stays fixed |

---

## Pass 4 (session 3, from T10) — 2026-10-15

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session3` (branch `parity/session-3`,
Godot bridge 6990, display :12). Start commit `69820d5b` (H04 pass 2); `git merge --ff-only main`
fast-forwarded to `146cbd44` (main @ the H04 pass-2 merge) before any work — the branch also carries
the merged H03/H09/H04 commits (expected, per the task briefing). `main` was never merged into and
nothing was pushed. Evidence under `REPO/runs/20261015-s3-H01-T10/`.

### Per-task status

| Task | Status | Commit |
|---|---|---|
| T10 PAR-0156 residuals | **done** (headless + in-engine halves) | `802ffd71` |
| T11 GroundAI stuck avoidance | **done** (headless; the plan says headless-only) | `c4002abc` |
| T11 corner-jam follow-up (pass 2) | investigated: **not reproducible** (8 variants probed; regression test kept) | `c4002abc` |
| T12 BuilderAI assist/following | not reached | — |
| T13 Cargo/Assembler dispatch | not reached | — |

Order executed: T10 -> T11 (the plan's order). T14 was already done by pass 3 (`0e1f9b60`).

### `git log --oneline main..HEAD`

```
c4002abc Gameplay H01 T11: GroundAI stuck avoidance (AvoidanceProcess + flowfield avoid id)
802ffd71 Fixes PAR-0156: turret DPS in estimateStats, enemy core fill, aiCoreSpawn, fillItems and prebuildAi defenders
```

### Test commands and results (final, after T11)

Run from `WT/client/rust` with `L="flock /tmp/opencode/mg-build.lock"; export CARGO_BUILD_JOBS=6`.

| Command | Result |
|---|---|
| `$L cargo test -p mind-core --lib --features msav-import` | **2488 passed / 0 failed / 4 ignored** (T10 +7 tests, T11 +3; 2482 total before this pass's first commit) |
| `$L cargo test -p mind-headless --lib` | **133 passed / 0 failed** |
| `$L cargo test -p mind-gdext --lib` | **42 passed / 0 failed** |
| `$L cargo run -q -p mind-headless -- parity goldens` | **97 PASS / 0 non-PASS** |
| `$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean (two T11 lints fixed: `too_many_arguments` allow + `then_some`) |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| GDScript gate | not run (no `.gd`/`.tscn` touched) |

### T10 — PAR-0156 residuals (`802ffd71`)

New tests (7): `game::runtime::tests::{base_builder_fills_enemy_core,
ai_core_spawn_caps_at_two_per_core, rts_ai_spawns_core_unit_without_idle_squads,
prebuild_ai_spawns_one_defender_per_core, estimate_stats_counts_loaded_turret}`,
`ai::rts_ai::tests::{estimate_stats_units_ignore_air_filter,
check_building_spawn_fires_every_fourth_gate}`.

In-engine (`runs/20261015-s3-H01-T10/probe.json`, screenshot `onset-evoke.png`): Onset
(`erekir:10`, resumed save), `attack:true, enemyCores:2`; after ~1600 ticks
`unit_debug_json()` lists **two team-3 `evoke`s** (ids ...00000001/2, `BuilderAI` per
`UnitTypes.java:4356`) spawned by `RtsAI.checkBuilding` (cap `cores.size`; a third gate
did not spawn), and `building_debug(287,197)` reads team 3 `core-bastion` (block 342) with
all 10 items at `1073741823` = `i32::MAX / 2` (the H09 `fillItems` half confirmed live).
`grep -c panic` on the session log = 0.

### T11 — GroundAI stuck avoidance (`c4002abc`)

New tests (3): `ai::pathfinder::flowfield::tests::get_target_tile_skips_avoided_neighbour`;
`sim::combat_tests::stuck_dagger_activates_avoidance_in_a_pocket`;
`sim::unit_runtime::tests::command_ai_ground_order_around_wall_mid_row`.

**Corner-jam follow-up (pass-2 open item): not reproducible.** Re-probed the original
`command_ai_ground_order_routes_around_walls` geometry (unit (12,16), wall x=20 y=4..=28,
dest (28,16)) plus 8 sub-tile/end-row variants (start/dest on the north end row, south end
row, mid row, half-tile offsets, 4.5/16.5/27.5 rows): every variant finished the order in
247-497 ticks on current main. The T4 `line_clear`/`segment_clear` fixes cover the
residual; the original geometry is kept as the regression test
`command_ai_ground_order_around_wall_mid_row`. The proposed ledger item can be closed as
"not reproducible on current main".

### Deviations from Java (Pass 4; each with file:line)

1. **T10** — `BulletType.rangeChange` is not modelled: turret `estimateStats` rows use
   `config.range` (`Turret.java:347-353`).
2. **T10** — `Fx.spawn.at` / `Units.notifyUnitSpawn` / `Time.run` delays of
   `BaseBuilderAI`/`Logic` are view-only or absent in the port; core picks use `ai_rng`
   instead of `Mathf.random` (determinism).
3. **T10** — `BulletType.estimateDPS` for `spawnUnit`/`despawnUnit` bullets reads the
   spawned unit's DPS from already-computed earlier bullets; a forward reference reads 0
   instead of recursing like Java's `cachedDps` (`BulletType.java:424-441`).
4. **T11** — unit ids are `EntitySeq & 0x7fff_ffff` (the port has no per-unit int id;
   `Pathfinder.java:417`/`AvoidanceProcess.java` use `unit.id`).
5. **T11** — the async, double-buffered `AvoidanceProcess` becomes a synchronous tick-start
   rebuild (`AvoidanceProcess.java:52-106`); queries read the end-of-last-tick grid, the
   same data Java's swapped buffer holds.
6. **T11** — `Units.nearby`'s quadtree box is replicated literally (`±radius/2`, inclusive)
   plus the `within(radius + other.hitSize * scale)` test (`GroundAI.java:69-73`).
7. **T10 fillItems note** — the `fillItems` rule gate itself landed with H09
   (`513eed69`/PAR-0249); this pass only removed a duplicated copy of it left by the merge.

### Blockers / open findings

* T12/T13 not reached (context budget). Both are independent and stay on the plan's order.
* The pass-2 corner-jam item is closed as not reproducible (see above).
* H02 residuals from pass 1 still stand (their half-tile sites; H02 owns them).

### Ledger changes to apply (Pass 4)

| Item | Now | Proposed | Note |
|---|---|---|---|
| PAR-0156 | seeded | **fixed** | `802ffd71`; turret DPS in `estimateStats`, core fill, `aiCoreSpawn` (both RtsAI and BaseBuilderAI paths), `prebuildAi` defenders; in-engine Onset evidence `runs/20261015-s3-H01-T10/probe.json` |
| (new) | — | file "Wave ground units never use stuck avoidance; `AvoidanceProcess` absent" — **fixed by `c4002abc` (T11)** | `GroundAI.java:24,54,63-85`, `Pathfinder.java:417`, `AvoidanceProcess.java` |
| (new) | — | file "Ground move orders can jam on a wall-end corner; the waypoint raycast ignores the unit's sub-tile offset" — **not reproducible** on current main (8 variants probed 2026-10-15, session 3); regression test `command_ai_ground_order_around_wall_mid_row` | close or keep as low-priority |

---

## Pass 5 (session 3, from T12) — 2026-10-15

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session3` (branch `parity/session-3`,
Godot bridge 6990, display :12). Start commit `c4002abc` (H01 pass 4); `main` was NOT merged into this
pass (the branch also carries the merged H03/H09/H04 commits, expected per the briefing). Nothing was
pushed; `runs/` was never staged. Evidence under `REPO/runs/20261015-s3-H01-T12/`.

### Per-task status

| Task | Status | Commit |
|---|---|---|
| T12 BuilderAI assist/following | **done** (headless + in-engine) | `43554571` |
| T13 CargoAI/AssemblerAI dispatch | **done** (headless only, per plan) | `cdd2133a` |

Order executed: T12 -> T13 (the plan's order). T14 was completed by pass 3 (`0e1f9b60`), T10/T11 by
pass 4 (`802ffd71`, `c4002abc`). With T12/T13 landed, **every H01 task (T1-T15) is complete** across
passes 1-5; no task is skipped, blocked or not reached.

### `git log --oneline main..HEAD`

```
cdd2133a Gameplay H01 T13: CargoAI and AssemblerAI dispatched live
43554571 Gameplay H01 T12: BuilderAI follows and assists active builders
```

(`main` already contains T1-T11/T14/T15 through the coordinator's merges, so only the two pass-5
commits show.)

### Test commands and results (final, after T13)

Run from `WT/client/rust` with `L="flock /tmp/opencode/mg-build.lock"; export CARGO_BUILD_JOBS=6`.

| Command | Result |
|---|---|
| `$L cargo test -p mind-core --lib --features msav-import` | **2494 passed / 0 failed / 4 ignored** (pass 4 ended at 2488; +2 T12 +4 T13 tests) |
| `$L cargo test -p mind-headless --lib` | **133 passed / 0 failed** |
| `$L cargo test -p mind-gdext --lib` | **42 passed / 0 failed** |
| `$L cargo run -q -p mind-headless -- parity goldens` | **all PASS** (97 PASS / 0 non-PASS) |
| `$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| GDScript gate | not run (no `.gd`/`.tscn` touched) |

### T12 — BuilderAI following / assist (`43554571`)

Java: `BuilderAI.java:46-100` (assist promotion, plan copy), `:143-186` (20-tick builder scan +
`onlyAssist`); `BuilderComp.java:33-35,301-309`; `HealthComp.java:16`.

* `BuilderAiState` gained `assist_following`, `following`, `timer2`; `update_builder_ai` is
  restructured to the Java order (validity sweep -> assist promotion -> following copy -> idle
  retreat -> plan validate/approach -> escort + scan + rebuild pickup).
* New helpers `unit_valid`, `can_build`, `actively_building`, `scan_follow_builder`,
  `closest_builder_player`.
* Tests (2): `assist_poly_follows_building_player`, `idle_rebuild_poly_helps_builder`.

In-engine (`runs/20261015-s3-H01-T12/probe.json`, screenshot `poly-assist.png`):
Ground Zero resumed; `debug_add_core_items("copper", 300)`; a team-1 poly spawned at (800,480) and
given `assist` (`content_list("unitCommand").find("assist")` = 3); a player wall plan queued through
`apply_sim_command_json {"op":"place","player":0,...,"x":135,"y":57}`. `construct_progress(135,57)`
samples: rate with the alpha alone **0.0278/tick** (buildSpeed 0.5 / build_cost 18); after the poly
joined the 20-tick scan, **0.05/tick** (1.8x = build speeds 0.5 + 0.4); the wall finished and
`building_debug(135,57)` reads `block 216, team 1`. Second wall pass: with the player idle the poly
left its spot and moved east toward the player ((800,480) -> (874.5,480) after 600 ticks; the escort
circle is `alpha hit 8 + poly hit 9/2 + 60 = 72.5 px`). `grep -c panic` = 0.

### T13 — CargoAI / AssemblerAI dispatch (`cdd2133a`)

Java: `CargoAI.java:26-97,99-172`, `AssemblerAI.java:11-24`, `UnitCargoLoader.java:113-118`,
`UnitAssembler.java:509-513`.

* `unit_update_system` dispatches `AiKind::Cargo`/`AiKind::Assembler` (previously the generic flying
  branch); both states are persisted components.
* `CargoAI` rewritten to the Java shape: tether-only destination, `findAnyTarget` (loader items
  most-first), `findDropTarget` (offset scan + stale fallback), 40-tick retarget, 90-tick drop
  spacing, 120-tick `emptyWaitTime`; a tether-less unit keeps its load.
* `AssemblerAI` ported (`moveTo(targetPos,1,3)`, `lookAt(targetAngle)` within 5 px, `in_position`).
* `CargoLoaderBehavior` binds the spawned manifold (`bt.building(this)`) and adopts block output
  units into the live `UnitRuntime` (shared `adopt_output_unit`; the assembler drone uses it too).
* Tests (6 new, 4 replaced): `manifold_dispatches_cargo_ai`, `assembly_drone_dispatches` (CT); the
  four cargo module tests and the two assembler module tests.

In-engine: headless only (the plan's T13 verification).

### Deviations from Java (Pass 5; each with file:line)

1. **T12** — `scan_follow_builder`/`closest_builder_player` iterate own-team units in `EntitySeq`
   order (`queries::in_radius`), not Java's `Units.nearby` quadtree order (`BuilderAI.java:152,174`).
2. **T12** — `timer2` is a 20-tick countdown rather than Arc `Interval`'s absolute-time check
   (`Interval.java`); `timerTarget2`'s 40-tick `Groups.player` break-plan check
   (`BuilderAI.java:107-116`) is omitted — the port has one local player and no other players'
   break orders to react to.
3. **T12** — Java aliases the leader's `BuildPlan` object in `unit.plans.addFirst(following.buildPlan())`
   (`BuilderAI.java:80`); the port owns a copy. The `moving`/`updateBoosting` tail
   (`BuilderAI.java:231-233`) stays unported (pre-existing).
4. **T13** — the flagged-building scan walks the live `UnitCargoUnloadPoint` entities in entity-index
   order (`CargoAI.java:105,132` uses `indexer.getFlagged` insertion order); `stale` reads the
   port's `UnitCargoUnloadPoint.stale_time <= 0` model (`world/blocks/units/mod.rs:768-780`), whose
   update rule diverges from Java's `staleTimer`/`stale` pair
   (`UnitCargoUnloadPoint.java:60-74`); `isPayload()` is assumed false (`CargoAI.java:64`).
5. **T13** — the assembler block does not arrange drone targets yet
   (`UnitAssembler.java:509-513`); a dispatched drone with the zero default target holds still, which
   matches Java before the first arrangement. Seam request for the block owner (H02): write
   `AssemblerAi.target_x/target_y/target_angle` per drone and use
   `ai::types::assembler::in_position` in the efficiency term.

### Blockers / open findings

* None. T12 and T13 both landed with their acceptance checks; the plan has no remaining tasks.
* The H02 half-tile residuals from pass 1 (their sites) still stand; H02 owns them.
* T13's loader/unload-point live loop is now wired end-to-end (spawn -> tether -> CargoAI shuttle)
  but has no in-engine capture (plan: headless only).

### Ledger changes to apply (Pass 5, and the whole plan)

| Item | Now | Proposed | Note |
|---|---|---|---|
| PAR-0174 | verified (pass 1) | keep | `8a1c4a56` |
| PAR-0202 | verified (pass 2) | keep | `8f803021` |
| PAR-0156 | seeded -> fixed (pass 4) | keep **fixed** | `802ffd71` |
| PAR-0091 | fixing -> fixed (pass 3) | keep **fixed** | `ebe8c37d` + H09's explosion bursts |
| PAR-0229 | verified | note: mount half fixed by T2 (`36e76496`) | reopen-note only |
| PAR-0237 | verified | note: absorption semantics fixed by T7 (`ebe8c37d`) | |
| PAR-0175 | verified | note: dock release fixed by T3 (`8a1c4a56`) | |
| PAR-0140 | fixed | note: `AiCtx::pathfind` arrival rule (T1) | |
| (new) | — | file "Assist command / BuilderAI follow does nothing" — **fixed by `43554571` (T12)** | in-engine 1.8x construct rate + escort, `runs/20261015-s3-H01-T12/probe.json` |
| (new) | — | file "CargoAI/AssemblerAI never run (manifold and assembly-drone use the generic flying branch)" — **fixed by `cdd2133a` (T13)** | dispatch + tether/adoption; assembler drone arrangement stays a block seam |
| (note) | — | the plan's §4 "new items" list is now fully filed by passes 1-5 (T1, T2, T5, T6, T8, T9, T11 T12, T13, T14) | T14's acceptance item was filed in pass 3 |
