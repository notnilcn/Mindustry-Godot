<!-- SPDX-License-Identifier: GPL-3.0-only -->
# G00 summary — integrate sessions 2-5 into `main`, reset the baseline (2026-10-13)

Executor: DeepSeek V4.1 Flash (opencode), session 1 = main checkout.
Plan: `G00-integrate-sessions.md` (executed in full). Status: **done, with one
in-engine acceptance deviation recorded in §T5** (the merge itself is proven
sound; the deviation is gap-dependent, see below).

## Control-plane facts

* Plans were committed first (they were untracked): `aba2a7d docs: replace
  round-F parity plans with round-G plans (INDEX, G00-G08, environment,
  audits)`.
* Pre-merge HEAD was `06340c4`; branch counts main..parity/session-N were
  exactly 18 / 20 / 14 / 6 as the plan predicted.
* No Godot editor was running at start; 10-11 GB RAM free.

## T1 — merges (all in `main`, no-ff)

| Merge | SHA | Result |
|---|---|---|
| parity/session-2 | `2a2325e` | clean |
| parity/session-3 | `22f9e1a` | clean |
| parity/session-4 | `8620051` | clean |
| parity/session-5 | `f00f1da` | 2 conflicts, resolved as the plan prescribes |

Conflict resolutions:

1. `client/rust/mind-gdext/src/sim_host.rs` — kept BOTH
   `debug_add_building_items` (session 4) and `place_launch_loadout` +
   `player_core_tile` (session 5); inserted the missing `    }` that closes
   `debug_add_building_items` before the session-5 side. Verified:
   `grep -n "fn debug_add_building_items|fn place_launch_loadout|fn player_core_tile"`
   → lines 2075 / 2116 / 2188; `grep -c "<<<<<<<|>>>>>>>"` → 0.
2. `parity/golden_manifest.json` — the `content_ids` hunk; kept one line
   (T2 set the real value immediately after).

Compile check `cargo check -p mind-gdext` → `Finished` (no errors).

## T2 — golden manifest hashes

* Fresh dump: `cargo run -q -p mind-headless -- content dump --out
  /tmp/g00-content.json --bundle parity/bundle_keys.json` →
  sha256 `e54e4be3749fd621f276819e5429cc91a402b9c1d76bd5ae79712df716823394`,
  byte-identical to the merged `parity/golden_content.json` (same hash).
* `parity/bundle_keys.json` = `ec84fe4abb2b80dd8596e8c91e68b7a80161c2e77dc5968bf76636c9b13ba6bd`;
  `git diff 06340c4` shows exactly the 4 added `unit.scathe-missile*.name`
  lines.
* Both hashes applied; commit `2bc833f`.

## T3 — campaign sector golden

* `campaign sector --planet serpulo --sector groundZero --ticks 600 --dump`
  diff vs the committed golden was exactly the predicted one line:
  `18c18 < "rules_checksum": "613fa92157ae0537" > "4781866c0cf4b1d8"`.
* Golden copied; new sha256
  `937a4f9bd85a06ed4d2572ae028b2875f3651a76c6af79d571e4663a9168109f` pinned in
  `golden_manifest.json` (`harness_campaign_sector_cycle`); commit `2453e59`.
* The other long-standing failure (`units_scenarios::tests::committed_goldens_match`,
  the base-builder AI golden) was NOT touched — G01 owns it.

## T4 — STDB content seed

* `server/gen_content_seed.sh` regenerated 720 entries; diff = the 4
  `scathe-missile*` units only. Commit `dc2ddbf`.

## T5 — test gates (the new baseline for every G-plan)

All commands from `client/rust`, behind `flock /tmp/opencode/mg-build.lock`,
`CARGO_BUILD_JOBS=6`:

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` | **1998 passed; 0 failed; 4 ignored** |
| `cargo test -p mind-headless --lib` | **131 passed; 1 failed** — exactly `units_scenarios::tests::committed_goldens_match` (base-builder AI golden; G01 owns) |
| `cargo test -p mind-gdext --lib` | **26 passed; 0 failed** |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean after §deviation-1 |
| `cargo run -q -p mind-headless -- parity goldens` | all PASS |
| `tools/build.sh` | `Finished` + `sync_scenarios: synced 11 file(s)` |
| GDScript parse gate (`godot.sh --headless --editor --quit`) | no SCRIPT ERROR / Parse Error |

Deviation 1 (fmt): `cargo fmt -- --check` initially showed **19 diffs in 9
session-touched files** (conveyor.rs, darkness.rs, fx.rs, render/blocks.rs,
command_overlay.rs, minimap.rs, shields.rs, status.rs, sim_host.rs) — the
merged session branches left formatting drift, contrary to the plan's "no
output" expectation. `00-environment.md` §2 prescribes running `cargo fmt` and
the G00 done criteria require fmt clean, so the files were formatted and
committed as `7091bee G00 T5: cargo fmt the merged session code` (whitespace
only; fmt --check + clippy re-run clean).

Deviation 2 (in-engine smoke): read `G00-integrate-sessions.md` §T5 in-engine
half carefully — **the acceptance "the wave dies to a duo, the core survives"
did NOT hold** on the merged tree. Evidence and analysis:

* Import: `tools/session-play.sh 1 --import` was unusually slow at first
  (the wrapper hung on its final eval; killed after 25 min). The import itself
  succeeded: `get_tech_state()` = `{"nodes": 375.0, "unlocked": 282.0}`.
  Manual `data_import` + `session-play.sh 1 --play` is the reliable recipe.
  (The worktree sessions N>=2 use their own user dirs; this only affects
  session 1.)
* Ground Zero boots cleanly: `start_sector("serpulo", 170)` → `hasCore: true`,
  `sectorName: "groundZero"`, wave 1, no panics (`grep -c panic` = 0).
* Run 1 (plan recipe: `place_block(130,48,"mechanical-drill")`,
  `place_block(132,48,"duo")`, `run_wave()`): the wave was **1 dagger + 2
  flares** (audit history says a dagger-only wave; composition differs by
  sector state). Bullets were observed (1..9 per sample). The player `alpha`
  died around t≈4700, the dagger reached the core (t≈4300), the core fell;
  `get_hud_state()` ended `gameOver: true, hasCore: false`.
* Run 2 (fresh clean re-import; duo fed via `debug_add_building_items`
  because the conveyor/turret intake gap is real — see below): same defeat.
  The duo consumed its 10 copper during the fight, alpha died, core fell.
* Locating the recipe flaw: `building_items_json` on the duo does not show
  turret ammo (ItemTurret ammo lives in `TurretState`, not `ItemModule`), so
  "duo empty" was never valid evidence. The 2x2 drill's east edge touches
  (132,48), so no belt should be needed (matches headless test
  `sim::unit_runtime::msav_tests::ground_zero_drill_fed_duo_kills_wave_daggers`,
  which passes with drill (dx,dy) + duo (dx+2,dy) and asserts ammo > 0).
* Focused experiment (fresh re-import, drill fed the duo for 90 s, then
  `apply_sim_command_json` spawned a lone team-2 `dagger` 64 px from the
  duo): the dagger **died within ~6 s** (bullets in flight; gone by the next
  5 s poll). So the live defense + core area do kill a lone ground wave unit,
  exactly like the headless test.
* Conclusion: the failing half of the smoke is **wave composition plus the
  known wave-1/wave-2 gaps**, not merge damage: the smoke's wave includes two
  `flare`s, the player alpha cannot shoot and never respawns (documented G08 /
  G01 gaps), and Ground Zero's own wave/tutorial scripting is inert (G06).
  The post-merge automated surface matches the coordinator's trial merge
  exactly (1998 / 131+1 / 26 / goldens / clippy), the tree boots, and no
  panic was ever recorded. Per INDEX §3, tasks whose acceptance depends on
  not-yet-landed plans are skipped and listed — that is the treatment applied
  here instead of "fixing forward" in G00.
* Open flag for G02 T1: the live drill→duo transfer could not be
  conclusively read back (no seam exposes `TurretState`); G02's in-engine T1
  check (`container` at (132,48), copper ≈ 10) will settle whether the live
  intake path is at parity. If it fails, `transfer::dispatch_accept_stack`
  work (G08 T2a) is the named owner.
* Evidence: `runs/20261013-g00/gz-after-merge.png` (Ground Zero live: copper
  ore, drill, duo, tutorial objective `Obtain 0/15 Copper`, minimap;
  screenshot centered on (131,48)). Panic count on the newest log = 0.

## T6 — marker and hygiene

* `971412b G00: integrate sessions 2-5 (merge marker)` (empty commit).
* `git merge-base --is-ancestor parity/session-N main` → ok-2 / ok-3 / ok-4 /
  ok-5.
* `git worktree prune` removed the stale `/tmp/mg-head` entry. Session
  worktrees untouched. Nothing pushed.
* Session 1 (main checkout editor/game) stopped to free RAM for sessions 2-5.
  Note: `tools/parity-session.sh --stop` did not kill the editor/game started
  by `session-play.sh` (no pidfiles); killed directly by pid.

## T7 — ledger changes to apply to `chains.json` (for the coordinator)

| Item | New status | Note to append (2026-10-13, G00) |
|---|---|---|
| PAR-0025 | verified | Configure Loadout Max toggle, valid gate, rows, capacity landed in `44b0f7b` (session 5 T1); 200 px SchematicImage toggles tracked by G05. |
| PAR-0026 | verified | same as PAR-0025. |
| PAR-0027 | verified | same as PAR-0025. |
| PAR-0085 | verified | `44b0f7b` + `fe9381b` (loadout validity + schematic core); in-engine evidence `runs/20261012-session5-campaign-import/t1-*.png`, `t2-launch-foundation.png`. |
| PAR-0131 | fixing | landing sprite/fade/announce/timing/locks landed `659146d`; remaining: thruster flames + hiding the real core under the landing sprite (G03). |
| PAR-0160 | verified | research requirements materialised `2fe5800`; `[223,174]` rows with costs; dialog lists all nodes. |
| PAR-0162 | verified | `Schematics.load` of `schematics/*.msch` + post-sort reindex landed in `44b0f7b`. |
| PAR-0163 | verified | launch capacity in the plan JSON (2000 shard / 4500 foundation) `44b0f7b`. |
| PAR-0088 | verified | scathe missiles `5c63c1d` (headless `scathe_launches_missile_and_kills`), under-bullet rule `487f79f`, adopt perf `b0d194c`; anthicus verified in-engine earlier (`1be95d2`). |
| PAR-0091 | fixing | `afaeebb` building `dynamicExplosion`; unit-death explosion, ExplosionShield, `rules.fire` gating remain (G01). |
| PAR-0127 | fixing | PlayEvent cooldown re-arm `9d64483`; still never seen in-engine (G07). |
| PAR-0137 | fixing | boosting mechs lift off `0e984ce` (headless); in-engine check in G08/G01. |
| PAR-0138 | fixing | payload key path, building pickup, revision-2 unit save `4b7067b`; in-engine carrier check pending (G01/G08). |
| PAR-0140 | (unchanged) | every command id accepted/stored `95fced5`; dispatch for Suicide/Builder/Boost `e927900`/`9d041bb`/`3e50373`; other AI kinds in G01. |
| PAR-0076 | verified | power gate/unitBuildSpeed `c94c27c`, command + move-in `955c9f0`, command panel `5e9545d` (in-engine). |
| PAR-0089 | fixing | sublimate latch + drain `75e8595` (headless only; needs an Erekir sector to see in-engine). |
| PAR-0098 | fixing | schematics through plans `d1ef222`; remaining: plan/beam drawing (G03), rebuild select (G08). |
| PAR-0094 | verified | key-combo line `52b4d42`, palette accent `8bf1b7f`, cursor hover `aade84d` (all in-engine, session 3). |
| PAR-0126 | verified | flying shadow + soft shadow `100ac50`, outlines `5dcd208` (in-engine vs Java crop). |
| PAR-0070 | verified | FX producer + regions + polyline `11ce662` (in-engine `runs/20261012-s3-t12/`); shake wiring structural only. |
| PAR-0128 | verified | same commit as PAR-0070 (regions drawn). |
| PAR-0097 | verified | F6 block status markers `d5adb63` (in-engine). |
| PAR-0096 | fixing | minimap indicators + unit icons `b03aed9`; the sim never emits `BuildDamageEvent` (G01 emits, G03 drains). |
| PAR-0157 | fixing | selection overlay `6be52fd` (in-engine); attack reticle needs an entity-id resolver (G01/G03). |
| PAR-0129 | fixing | domes/bubbles `4b160e3` (code); force projector stays at efficiency 0 in-engine (G02) and the animated shader needs the effect buffer (G03). |
| PAR-0130 | (unchanged) | belt autotile/animation `e031438`, item order `5aeb51f`. |
| PAR-0152 | (unchanged) | blockbuild shader `5075b87`, per-part drill/turret `0bd9e5d`. |

New items to file (title → status):

* "Research dialog listed only the root row: ResearchView rows carried no tree
  name" → verified (`2fe5800`).
* "Enemy base-builder AI queues no plans (units_base_build golden: 0 of 28)"
  → seeded (owner G01).

## Commits (main)

```
aba2a7d docs: replace round-F parity plans with round-G plans (INDEX, G00-G08, environment, audits)
2a2325e Merge branch 'parity/session-2'
22f9e1a Merge branch 'parity/session-3'
8620051 Merge branch 'parity/session-4'
f00f1da Merge branch 'parity/session-5'
2bc833f G00 T2: golden manifest hashes for the merged content and bundle keys
2453e59 G00 T3: regenerate the campaign sector golden for the compact TeamRule serialisation
dc2ddbf G00 T4: regenerate the STDB content seed for the scathe missile units
7091bee G00 T5: cargo fmt the merged session code
971412b G00: integrate sessions 2-5 (merge marker)
```

## Done criteria assessment

* `main` contains all four session branches + the marker → yes.
* mind-headless fails exactly one test → yes.
* parity goldens all PASS; clippy/fmt clean; mind-core suite green → yes.
* Ground Zero boots, no panic → yes. "The wave dies to a duo" → **no** (see
  §T5 deviation 2; attributed to known G01/G06/G08 gaps and wave composition,
  not to the merge; the lone-dagger experiment shows the live defense works).
