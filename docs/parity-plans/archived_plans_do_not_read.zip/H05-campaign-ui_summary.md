<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H05 — Generated sectors, campaign UI and meta screens — execution summary

Session 5 (worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session5`,
branch `parity/session-5`, bridge 7010, display `:14`). Written 2026-10-14.
Read `H-environment.md`, `H-INDEX.md` §3 and the plan first; this file is the
deliverable only (not committed).

Start state: `git merge --ff-only main` fast-forwarded to `351dc7ca` (H00, H02,
H04 wave-1 landed; H01/H09 still running). Mid-session `git merge --no-edit
main` brought H01/H09/H08 wave-2 commits (83 files) — clean merge, no conflicts,
all gates re-run green afterwards.

## Commits (`git log --oneline main..HEAD`)

```
e2ffd282 Merge branch 'main' into parity/session-5
df856e3f Gameplay H05 T9: Strings.autoFixed truncates like Arc
6781351f Gameplay H05 T7: sector invasion toasts from campaign turns
a00a4cad PAR-0112: derelict ruins in generated sectors (H05 T6)
eb78d250 PAR-0112: place the launch loadout core at the generated sector spawn (H05 T4)
ab9f87e8 PAR-0112: generated sectors are bounded by the sector polygon darkness (H05 T3)
ac60dadc PAR-0112: generated sectors use their sector rect, seed, size and threat (H05 T2)
ba24fe66 PAR-0112: Serpulo attackSectors and boot-time base coverage (H05 T1)
```

## Task status

| Task | Status | Notes |
|---|---|---|
| T1 attackSectors + boot threat | **done** | `ba24fe66` |
| T2 sector rect/size/seed/threat | **done** | `ac60dadc` |
| T3 sector polygon darkness | **done** | `ab9f87e8`; renderer/minimap switch is H03's |
| T4 launch loadout at the spawn | **done** | `eb78d250` |
| T5 enemy bases (BaseGenerator) | **not reached** | headless-only, kept last per coordinator; the shared `try_place`/`is_taken`/`set`/`BaseRand`/`get_frac` infra landed with T6, only `generate`/`post_generate` remain |
| T6 derelict ruins | **done** | `a00a4cad`; subject `PAR-0112:` not `Fixes` (T5 pending) |
| T7 sector notifications | **done (invasion half not reproduced in-engine)** | `6781351f`; off-play capture/loss toasts wait on H04 event variants |
| T8 research dialog fidelity | **not reached** | live-spend replay needs H01 T3 (`take_unlocked_content`), which is now on main |
| T9 Arc autoFixed truncation | **done** | `df856e3f` |
| T10a content info endpoint + model | **not reached** | H09 T10 (CampaignStats) is now on main, so the live-stat halves are unblocked |
| T10b-e production/logistics/factories/turrets stats | **not reached** | |
| T11a custom rules dialog rows | **not reached** | |
| T11b pause-menu rules button + live apply | **not reached** | |
| T12 hints remainder | **not reached** | `cores_destroyed` half needs H09 T10 (now on main) |
| T13 schematics cards + atlas sprite | **not reached** | |
| T14 globe drag/zoom/last-sector/reveal | **not reached** | |
| T15 rename pencil + icon picker | **not reached** | |
| T16 sector stats dialog | **not reached** | |
| T17 database icon tabs | **not reached** | |
| T18 settings fan-out | **skipped: H04 T11 owns PAR-0164** (withdrawn; H04 T11 is not on main yet) |
| T19 dialog hide fade | **not reached** | |
| T20a-c planet hex mesh/emissive/bloom | **not reached** | |
| T21 cosmetic residuals | **not reached** | |
| T22 host dialog layout | **not reached** | |
| T23 palette rebuild on world load | **not reached** | |

No task was skipped for a missing dependency mid-run; everything attempted was
completed. "not reached" = ran out of session budget. H01 T3 (unlock pipeline),
H09 T10 (stats listeners) and H03 T2/T6 landed on main after my start, so
T8/T10/T12 and the T3 renderer half are unblocked for a wave-3 re-run.

## Test commands and results (final, after the main merge)

Run from `client/rust` (one cargo command host-wide via
`flock /tmp/opencode/mg-build.lock`, `CARGO_BUILD_JOBS=6`):

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` | **2325 passed / 0 failed / 4 ignored** |
| `cargo test -p mind-headless --lib` | **132 passed / 0 failed** |
| `cargo test -p mind-gdext --lib` | **36 passed / 0 failed** |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean (0 errors/warnings) |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| `cargo run -q -p mind-headless -- parity goldens` | all PASS |
| `cargo test -p mind-headless --lib ui_goldens_match` | ok (campaign golden regenerated in T1) |
| GDScript parse gate (`bash tools/godot.sh --headless --editor --quit --path client \| grep -E "SCRIPT ERROR\|Parse Error"`) | prints nothing |

Per-task targeted tests (all green): T1 `game::universe` 17 (incl.
`serpulo_attack_sectors_marked`, `boot_threat_matches_update_base_coverage`,
`static_gen_extras_matches_campaign`); T2 `maps::planet` 21 (incl.
`sectors_differ_by_id`, `sector_size_is_even_and_from_rect` (serpulo 1 = 334),
`make_rect_center_projects`); T3 `math::arc_noise` 2 (`arc_noise_matches_java`
against the Arc-jar oracle) + `world::darkness` 5
(`sector_polygon_dark_outside`); T4 `place_structures_places_shard`,
`generated_sector_reports_spawn`; T6 `ruins_placed_when_roll_positive`
(sector 3 → 86 derelict buildings); T9 `auto_fixed_matches_arc` +
`fix_value_golden` (1.2345 → "1.234").

Golden changes: only `client/rust/mind-core/tests/goldens/ui/campaign.json`
(groundZero threat 0.0 → 0.1, checksum) regenerated in T1 with the documented
dump command; sha256 updated in `parity/golden_manifest.json`. No other golden
moved.

## In-engine evidence per task

All in `REPO/runs/20261014-s5-H05-T<n>/` (PNG + JSON). Recipe: `--import`
boot (`{"nodes": 375.0, "unlocked": 282.0}`), `grep -c panic` on the newest
session log = 0 after every step.

* **T1** `planet.png`: `campaign_section("sectors")` → sector 0
  `{has_enemy_base: true, threat: 0.8, band extreme}`; 194 preset-less rows, 0
  below the 0.3 floor, 0 rows at threat 0.0 (272 total); sectors 1/2/5 threat
  0.3. Before: every row read 0.0.
* **T2** `sector-1.png`, `sector-2.png`: preset-less sectors 1/2 load with
  `tile_debug(333,333)` in bounds and `tile_debug(334,0)` = `{}` (size 334);
  sector 1 tile (10,10) tainted-water vs sector 2 shallow-water; the world
  views differ (snow/ice vs sand + dark sand + copper ore).
* **T3** `polygon-edge.png`: open-floor tile (125,15) outside the hexagon →
  `valid_place_preview` false; (167,100) and centre (167,167) → true.
* **T4** `landed.png` (free launch serpulo 1: core at world (2192,1544),
  `hasCore` true, `gameOver` false, `has_player_unit` true, `winWave` 25,
  survives `step(600)`) and `launcher-loadout.png` (schematic index 10 + 300
  copper → `core_items_json` `{"copper":300}` right after start and after the
  pump; the launcher row index into `Schematics.all` is 10 =
  `basicShard` on this profile).
* **T6** `ruin.png`: serpulo 4 log `ruins: derelict part placed at (176, 181)
  [1 total]`; `building_team_at(176,181)` = 0; the tile holds a
  `pneumatic-drill` on `ore-lead`; loadout core at (1896,608).
* **T7** `toast-in-game.png`, `toast-in-menu.png`: 40 forced `run_turn()` calls
  with `sectorInvasion` on produced **no** invasion (0 `campaign event:` log
  lines) → "not reproduced", code kept. Menu suppression: `MindUi.toast` adds
  0 OverlayLayer children while the menu is visible (stays 8) and 1 in game
  (7 → 8).
* **T9** headless-only (formatter); oracle values cited in the test.

## Deviations from Java

* **T2** `Sector.java:255-282`: Arc `Mathf.cosDeg/sinDeg` are lookup-table
  based and `Mathf.atan2` is a polynomial approximation; `make_rect`/
  `rotate_y` use the port's libm convention (plan 06 goldens are
  Rust-recorded). `Vec3.rotate(Vec3.Y, deg)` is transcribed from
  `Mat.setToRotation`+`Vec3.mul` (axis-Y: `x' = cos*x - sin*z`,
  `z' = sin*x + cos*z`), not from the plan's simplified formula (whose sign is
  flipped).
* **T3** `World.java:484-536`: same trig deviation for
  `sector_polygon_darkness`; the Arc `Noise` port itself is exact (oracle
  matched).
* **T4** None from Java. Observation: `game/runtime.rs:436-458`
  (`sync_session_with_sim`) clears the core module and re-adds
  `session.rules.loadout` on every fresh launch, so `start_sector` without a
  loadout payload ends with an empty core (Java `Logic.play` does the same for
  a free launch); the launcher payload path keeps the items.
* **T6** `BaseGenerator.java:196-262`: (1) the oil-extractor
  `sumAttribute(Attribute.oil)` clause is skipped — the port's `Attribute` enum
  has no `oil` (oil extractors only exist in sandbox-only parts); (2) Java's
  `posc` closure closes over `ctx`/`rand`; the Rust `PosCallback` receives them
  explicitly (`base.rs` doc comment); (3) the callback writes the ore-scrap
  overlays inline (draw order preserved) via `WorldCtx`.
* **T7** `HudFragment.java:261-275`: the toast text is formatted through
  `/root/MindAssets.bundle_format` (the bundle lives on the HUD/assets node;
  `MindCampaign`'s `MemoryBundle` is empty).
* **T9** None: `Strings.autoFixed`/`fixedBuilder` transcribed with the exact
  f32/double casts.

## Blockers / follow-ups

* **T5** (enemy-base `generate`/`postGenerate`) not reached; the shared
  `try_place` infrastructure is in place, so T5 is now a smaller task.
* **T7** off-play `sector.capture`/`sector.lost` toasts need H04 to emit
  `CampaignEvent` variants for those cases (the enum has only
  `Turn`/`SectorInvasion`; seam §6).
* **T8/T10/T12** were not reached but are unblocked as of the final main merge
  (H01 T3 unlock pipeline, H09 T10 stats).
* **T11b** needs a non-campaign session to verify the pause-menu book button;
  custom-map loading has no round-H owner (round-3 note).
* Observation (not investigated): `MindCampaign` has no `set_campaign_rule`
  `#[func]`, so `campaign_rules_dialog.gd`'s `has_method("set_campaign_rule")`
  check fails and the dialog toggles do not persist; the T7 in-engine check
  used `set_campaign_rules_json` directly.
* Observation: the toast label from `ui_root.gd _toast_label` (position
  (24,24), overlay layer) did not render visibly in the in-game screenshots of
  this editor run even though the child was created; the menu behaviour was
  verified by child counts (T7 evidence JSON). The drawing path is H03/H04's.

## Ledger changes to apply (§4 expanded)

| Item | Status / note |
|---|---|
| PAR-0112 | **fixing** (T1-T4, T6 landed with in-engine evidence; T5 `BaseGenerator.generate`/`postGenerate` still missing). Note: attackSectors + boot threat (T1), sector rect/size/darkness (T2-T3), loadout (T4), ruins (T6) |
| PAR-0145 | unchanged (T8 not run) |
| PAR-0047 | unchanged (T8 not run) |
| PAR-0132 | unchanged (T11a/T11b not run) |
| PAR-0143 | unchanged (T13 not run) |
| PAR-0144 | unchanged (T17 not run) |
| PAR-0164 | unchanged (T18 withdrawn; H04 T11 not on main yet) |
| PAR-0142 | unchanged (T20a-c not run) |
| PAR-0151 | unchanged (T22 not run) |
| new | "Planet.getData attackSectors never marked; numbered-sector threat 0 until first capture" → **fixed** (T1, `ba24fe66`) |
| new | "Generated sectors are square: sector-polygon darkness missing (build gate)" → **fixed** build-gate half (T3); renderer half H03 |
| new | "Generated sectors were one 128x128 map with no core" → **fixed** (T2/T4/T6); enemy-base half T5 |
| new | "No toast for off-play sector invasions (turn events dropped)" → **fixed** (T7, invasion half not reproduced in-engine) |
| new | "Strings.autoFixed rounds instead of truncating" → **fixed** (T9, `df856e3f`) |
| new | "Content info dialog shows no stats" → T10a-e not run |
| new | "In-game rule edits are overwritten by the runtime mirror" → T11b not run |
| new | "Hints: unitSelectControl fungal-pass predicate inverted; cores_destroyed 0; cannotupgrade/factorycontrol never fire" → T12 not run |
| new | "Planet globe cannot be dragged/zoomed; last sector never stored; no preset reveal" → T14 not run |
| new | "Planet page lacks rename/icon picker; stats dialog is a text dump" → T15/T16 not run |
| new | "Dialogs hide instantly (Java fades 0.1 s)" → T19 not run |
| new | "Block palette keeps the previous planet's blocks after an in-session sector switch" → T23 not run |

---

# Pass 2 (session 4)

Session 4 (worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session4`,
branch `parity/session-4`, bridge 7000, display `:13`). Written 2026-10-15.
Start state: `git merge --ff-only main` fast-forwarded to `56717ffe` (H00, H01,
H09, H02, H04 wave-1/2 and H08 pass 2 landed; the prior session-4 H08 work is
in `main`). Dependencies checked: H00 yes, H01 T3 unlock feed yes
(`take_unlocked_content`), H09 T10 yes, H04 T11 **not on main** (T18 stays
skipped). No mid-session main merge was needed.

## Commits (`git log --oneline main..HEAD`)

```
5efcdb5a Gameplay H05 T10a: Stats model and base content stats for the content info dialog
2f413cab Fixes PAR-0145: research dialog dim, title, root selector, items and node styles; live spend verified (H05 T8)
```

## Task status

| Task | Status | Notes |
|---|---|---|
| T8 research dialog + live spend | **done** | `2f413cab`; all five fidelity points + live spend replay |
| T9 Arc autoFixed | done in pass 1 | `df856e3f` |
| T10a stats model + base stats + endpoint + renderer | **done** | `5efcdb5a`; block/item/liquid base bodies |
| T10b production/crafting/power stats | **not reached** | next in order |
| T10c logistics/storage/logic/defense stats | **not reached** | |
| T10d unit factory + payload stats | **not reached** | |
| T10e turret ammo + unit weapon stats | **not reached** | |
| T11a custom rules dialog rows | **not reached** | |
| T11b pause-menu rules button + live apply | **not reached** | in-engine half stays BLOCKED (custom-map loading has no round-H owner) |
| T12 hints remainder | **not reached** | deps (H01 T3, H09 T10) are on main; `factorycontrol` in-engine needs H08 T6b (on main) |
| T13 schematics cards + atlas sprite | **not reached** | |
| T14 globe drag/zoom/last-sector/reveal | **not reached** | |
| T15 rename pencil + icon picker | **not reached** | |
| T16 sector stats dialog | **not reached** | |
| T17 database icon tabs | **not reached** | |
| T18 settings fan-out | **skipped: H04 T11 owns PAR-0164** | `git log main \| grep "H04 T11"` = nothing at session start |
| T19 dialog hide fade | **not reached** | |
| T20a-c planet hex mesh/emissive/bloom | **not reached** | |
| T21 cosmetic residuals | **not reached** | |
| T22 host dialog layout | **not reached** | |
| T23 palette rebuild on world load | **not reached** | quick + independent; deliberately not jumped out of order |
| T5 enemy bases (BaseGenerator) | **not reached** | kept LAST per the coordinator note; headless-only |

## Test commands and results (final, at `5efcdb5a`)

Run from `client/rust` (one cargo command host-wide via
`flock /tmp/opencode/mg-build.lock`, `CARGO_BUILD_JOBS=6`):

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` | **2476 passed / 0 failed / 4 ignored** |
| `cargo test -p mind-headless --lib` | **133 passed / 0 failed** |
| `cargo test -p mind-gdext --lib` | **42 passed / 0 failed** |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| `cargo run -q -p mind-headless -- parity goldens` | 97 lines PASS, no FAIL (no golden regenerated in pass 2) |
| GDScript parse gate (`tools/godot.sh --headless --editor --quit --path client`) | prints nothing |
| `tools/build.sh` | `Finished dev profile` + `sync_scenarios: synced 11 file(s)` |

Per-task targeted tests, all green: T8 `ui::manifest` 6/0
(`repo_dialogs_manifest_complete` covers the new dialog) ; T10a
`ui::content_stats` 5/5 (`stat_ids`, `copper_item_stats`, `duo_block_stats`,
`cryofluid_liquid_stats`, `stats_sort_and_dedup`).

No golden file changed in pass 2: T8 touched no `core/ui/campaign.rs` view
struct and T10a only added a new module plus JSON endpoints.

## In-engine evidence per task

All under `REPO/runs/` (PNG + JSON). Recipe: imported profile boot
(`tools/session-play.sh 4 --play`, `{"nodes": 375, "unlocked": 282}` at start),
Ground Zero via `load_sector`/`start_sector`, `grep -c panic` on the newest
session log = 0 after every step.

* **T8** `runs/20261015-s4-H05-T8/`:
  * `tree.png` — the tree fills the viewport in the `defaultDialog` style with
    the black9 Dim (no `full_dialog`), title button 300x60 at (426, 8) with the
    32 px `block-core-shard-ui` icon, `padRight` 8, the accent "Serpulo" label
    and the trailing 32 px spacer; `@globalitems` shows 16 rows (copper 3982,
    lead 4000, ...) — the items half needs no change.
  * `root-select.png` + `erekir-tree.png` — the new `research_root_select`
    manifest dialog opened by a real mouse click on the title button: two
    centred 300x60 `flatTogglet` rows (Serpulo checked, Erekir); a real click on
    Erekir switched the tree (`root` "erekir", title "Erekir", selector hidden,
    dialog stack back to `["research"]`), and back to Serpulo by click.
  * `researched.png` — live spend replay: node 98 `scrap-wall` spends 200 scrap
    from the live Ground Zero core (4000 -> 3800), flips to unlocked, tech count
    282 -> 283; node 99 `scrap-wall-large` unlocked by a real LMB click at the
    button rect (`button_rect(99)` = (709.75, 413, 60, 60) after panning),
    tech 284 -> 285; `Input.select_block_by_name("scrap-wall")` = true right
    after the unlock (unlocked-filtered palette), and node 98/99 stay unlocked
    across a `--play` restart (285 unlocked persisted).
  * `evidence.json` — all eval outputs quoted.
* **T10a** `runs/20261015-s4-H05-T10a/`:
  * `duo-info.png` — `?` on duo: Purpose + "Fires alternating bullets at
    enemies.", General (Health 250, Size 1x1, Build Time 0.291 seconds, Build
    Cost copper 35), Liquids (Liquid Capacity 20 liquid units), Items (Item
    Capacity 10 items). Compare
    `runs/20261014-s3-verify3/java-26-duo-info.png` (Java adds the T10e
    Function/Ammo rows; everything T10a owns matches).
  * `copper-info.png` — Explosiveness / Flammability / Radioactivity / Charge
    each `0 %` plus the details line.
  * Endpoint spot checks: `content_info_json("cryofluid")` ranks
    Heat Capacity 90 / Viscosity 50 / Temperature 25;
    `MindWidgets.content_icon("sector-groundZero-ui", "sector", 32)` returns the
    `terrain` glyph (Label, U+E864).
  * `evidence.json` — quoted outputs and the deviation list.

## Deviations from Java

* **T8**: `take_unlocked_content()` is empty after a research spend. A spend
  writes the campaign/registry and `runtime.unlocked_content` directly
  (`push_campaign_to_runtime` + `invalidate_ui_block_catalog`); the drain carries
  sim-produced `UnlockRef`s (the H01 T3 seam). `MindHud.push_unlock` ->
  `hud_fragment` unlock toast still has no producer (follow-up, not part of T8).
* **T8**: the root-selector rows are a plain `flatTogglet` table (Java wraps
  them in a `Tex.button` table); the toggle "checked" style marks the current
  root as Java's `.checked(node == lastNode)` does.
* **T8 (fixed in T10a)**: the first cut of the sector-node icon fallback looked
  up `terrain` as an *atlas region*; `Icon.terrain` is an icon-font glyph, so it
  returned null and spammed warnings. `MindWidgets.content_icon` now returns the
  glyph for `type == "sector"` (`SectorPreset.java:132-134`), which also fixes
  the blank Ground Zero node.
* **T8**: the tree canvas places its node buttons from `_process`; while a
  session's frame loop is stalled the buttons keep their stale rects (the
  2026-10-15 stall was recovered with `tools/session-play.sh 4 --play`; not a
  code change).
* **T10a**: `StatCtx` holds the registry + live bundle (no `BlockTable`; every
  base stat reads `BlockDef` directly). `Block.instantTransfer` /
  `maxConsecutive` have no port field, so that branch (and the `unabletoclog`
  itemCapacity alternate) is unreachable in T10a. `ConsumeCoolant` has no
  display yet (the port consumer record carries no temperature/flammability
  filter) — T10c owns it. Unit icons are emitted as a leading `Cell::Icon`
  (icon-font glyph) instead of inline Iconc text.
  `Block.java:644-678` / `Item.java:105-110` / `Liquid.java:162-168` otherwise
  transcribed term by term (synthetic = `update || destructible`,
  `canBeBuilt` = visibility not hidden/debugOnly).

## Blockers / follow-ups

* **T10b-T10e** are the remaining stats families; the T10a model + endpoint +
  renderer are in place, so each family is now "add a `fn <family>_stats` and
  call the block base first".
* **T11b** in-engine verification stays blocked (the port's Custom Game flow
  never loads the map; round-3 note).
* **T18** withdrawn (H04 T11 owns PAR-0164; not on `main` at session start).
* **T5** has no vanilla trigger; keep it last and headless-only.
* The T8 live-spend + root-selector recipes are recorded here and in the
  evidence JSONs; the `content_info_json` endpoint is the T10b-T10e seam
  (`runs/20261015-s4-H05-T10a/evidence.json` lists the cell shapes).

## Ledger changes to apply (§4 expanded)

| Item | Status / note |
|---|---|
| PAR-0145 | **verified** (T8, `2f413cab`): live click spends from the live core, node unlocks, palette gains the block, survives a restart — `runs/20261015-s4-H05-T8/researched.png` |
| PAR-0047 | **verified** with T8 (hover info table + click spend halves) |
| PAR-0112, PAR-0132, PAR-0143, PAR-0144, PAR-0142, PAR-0151 | unchanged from the pass-1 tables |
| new ("Content info dialog shows no stats") | **fixing** after T10a (`5efcdb5a`): model + endpoint + renderer + block/item/liquid base stats verified in-engine; T10b-T10e families pending |
| new ("Research dialog is a `fullDialog` with a PopupPanel root selector; sector nodes blank") | **fixed** (T8 `2f413cab`, terrain-glyph half in T10a `5efcdb5a`) |

---

# Pass 3 (session 2)

Session 2 (worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session2`,
branch `parity/session-2`, bridge 6980, display `:11`). Written 2026-10-15.
Start state: `git merge --ff-only main` fast-forwarded `3c4284c2` -> `d38a39ba`
(H00 + wave-1/2 landed, H01 pass 4 / H05 pass 2 merged into main). Dependencies
checked: H00 yes; H01 T3 unlock feed yes; H09 T10 stats yes; **H04 T11 is not on
main** (`git log --oneline main | grep "H04 T11"` prints nothing), so T18 stays
skipped. No mid-session main merge was needed.

## Commits (`git log --oneline main..HEAD`)

```
703b2b22 Gameplay H05 T10b: production, crafting and power content stats
```

## Task status

| Task | Status | Notes |
|---|---|---|
| T10b production/crafting/power stats | **done** | `703b2b22`; all 15 production/crafting families + 10 power classes |
| T10c logistics/storage/logic/defense stats | **not reached** | 28 classes; same seam as T10b (`content_stats/production.rs` is the template; behavior downcast via `Any`) |
| T10d unit factory + payload stats | **not reached** | |
| T10e turret ammo + unit weapon stats | **not reached** | |
| T11a custom rules dialog rows | **not reached** | |
| T11b pause-menu rules button + live apply | **not reached** | in-engine half stays BLOCKED (custom-map loading has no round-H owner) |
| T12 hints remainder | **not reached** | |
| T13 schematics cards + atlas sprite | **not reached** | |
| T14 globe drag/zoom/last-sector/reveal | **not reached** | |
| T15 rename pencil + icon picker | **not reached** | |
| T16 sector stats dialog | **not reached** | |
| T17 database icon tabs | **not reached** | |
| T18 settings fan-out | **skipped: H04 T11 owns PAR-0164** | not on main at session start |
| T19 dialog hide fade | **not reached** | |
| T20a-c planet hex mesh/emissive/bloom | **not reached** | |
| T21 cosmetic residuals | **not reached** | |
| T22 host dialog layout | **not reached** | |
| T23 palette rebuild on world load | **not reached** | quick + independent; deliberately not jumped out of order |
| T5 enemy bases (BaseGenerator) | **not reached** | kept LAST per the coordinator note; headless-only |

Budget was spent on T10b (large transcription + two full rebuild/restart
verification cycles); the remaining queue is "not reached", not blocked. Nothing
partial is left uncommitted.

## Test commands and results (at `703b2b22`)

Run from `client/rust` (one cargo command host-wide via
`flock /tmp/opencode/mg-build.lock`, `CARGO_BUILD_JOBS=6`):

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` | **2526 passed / 0 failed / 4 ignored** |
| `cargo test -p mind-headless --lib` | **133 passed / 0 failed** |
| `cargo test -p mind-gdext --lib` | **44 passed / 0 failed** |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | clean |
| `cargo run -q -p mind-headless -- parity goldens` | **97 PASS / 0 FAIL** (no golden regenerated) |
| `cargo test -p mind-headless --lib ui_goldens_match` | ok (no `core/ui/campaign.rs` view struct changed) |
| GDScript parse gate | not needed (no `.gd`/`.tscn` edit) |

Per-task targeted tests (all green): T10b `ui::content_stats` 8/8, incl.
`mechanical_drill_stats` (drillSpeed `60/600*2*2` -> `0.4` + non-empty
drillables list), `graphite_press_stats` (productionTime `1.5 seconds`, output
`[lightgray]0.666/sec`, input `[lightgray]1.333/sec`),
`combustion_generator_reads_behavior_knobs` (`60 power units/second`).

## In-engine evidence (T10b)

`runs/20261015-s2-H05-T10b/` (`graphite-press-info.png`,
`mechanical-drill-info.png`, `evidence.json`). Recipe: `tools/build.sh`,
`tools/session-play.sh 2 --play` (profile `{"nodes": 375.0, "unlocked": 282.0}`),
Ground Zero via `load_sector`/`start_sector` (`hasCore` true, `campaign` true);
`grep -c panic` on the newest session log = **0** after every step.

* `content_info_json("graphite-press")`: crafting category has
  `input` coal x2 `[lightgray]1.333/sec`, `output` graphite x1
  `[lightgray]0.666/sec`, `productionTime` `1.5` + ` seconds`.
* `content_info_json("mechanical-drill")`: `drillSpeed` `0.4 items/second`;
  `drillTier` renders 6 panels (Sand/Dark Sand `0.4/sec`, Copper/Lead
  `0.36/sec`, scrap `0.4/sec`, coal `0.34/sec`), 2 per row; ore rows show the
  item's name (`OreBlock.java:17`).
* Power rows: combustion-generator `60`, solar-panel `7.2`,
  thorium-reactor `900` + `Meltdown Time 3.54 seconds when full`,
  impact-reactor `Power Use 1500`, `7800`, `Warmup Time 115.12 seconds ~
  21.16 seconds power equilibrium`; water-extractor output water `6.6`/sec.
* Regressions: `duo` still `[general, liquids, items]`; the `?` dialogs render
  (screenshots above).

## Deviations from Java

* `StatValues.blocks(attr, floating, scale, startZero, checkFloors)`: the port
  emits the registry's floors with a non-zero attribute (no live-map
  `indexer.isBlockPresent` filter), sorted by attribute value; the detailed
  `scaleEff/scaleAmount/outputs` form is not ported (`AttributeCrafter` has no
  port `outputScale`/`displayEfficiency` fields), so `AttributeCrafter` uses the
  short `blockEfficiency` list. In the menu the row is `@stat.showinmap`
  (`StatCtx.in_game`).
* `StatValues.drillables`: every drillable block in the registry is listed
  (Java filters by map presence in game); the ore glyph is the 16 px item icon,
  not `Item.emoji()`.
* `ImpactReactor` warmup tooltip (`bar.lerpwarmuptime` with t90/t99) is
  dropped: the T10a `Stats` model has no per-add tooltip slot.
* `NuclearReactor` heat output row is gated on `StatCtx.planet == "erekir"`
  (no full planet object in `StatCtx`); on Serpulo it is absent like Java.
* `WallCrafter` `itemBoosters` is not ported: no vanilla port wall-crafter has
  an item consumer.
* `AttributeCrafter.attribute == -1` (cultivator/vent-condenser) skips the
  tiles/affinities row (no port `Attribute` to name).
* Power family knobs are read from the registered behavior structs via a new
  `std::any::Any` supertrait on `BuildingBehavior` (single source of truth);
  `NuclearReactor`/`ImpactReactor`/`VariableReactor` rows come from the
  behavior `GeneratorConfig` + extra fields.
* `content_info_json` rebuilds the runtime `BlockTable` per call (the plan's
  "cache once" idea was dropped: the table would need invalidation at every
  registry reload; the build is cheap next to dialog construction).

## Blockers / follow-ups

* **Port content gap found while verifying thermal-generator**: the port's
  floor defs carry no `heat` attribute (`environment.rs` sets only
  water/oil/sand/steam/light), so `thermal-generator`/`turbine-condenser`
  `Required Tiles` reads `<none in map>` and the sim's `sumAttribute(heat)` is
  0. Java sets heat on `molten-slag` 0.85, `hotrock` 0.5, `magmarock` 0.75
  (`Blocks.java:327,365,375`). Out of H05 T10b's scope (content data + sim);
  record for the plan/content owner.
* **T10c-T10e** are the remaining stats families; `production.rs` + the
  `StatCtx.blocks`/`BuildingBehavior: Any` seams are the template. Logistics
  values (`displayedSpeed`, bridge `transportTime`, duct `speed`) live in the
  content specs/behavior knobs, so the same readback pattern applies.
* **T11b** in-engine verification stays blocked (Custom Game never loads its
  map; round-3 note).
* T18 withdrawn (H04 T11 owns PAR-0164; not on `main` at session start).

## Ledger changes to apply (§4 expanded)

| Item | Status / note |
|---|---|
| new ("Content info dialog shows no stats") | **fixing**, advanced: T10a (`5efcdb5a`) + T10b (`703b2b22`) verified in-engine; T10c-T10e families pending |
| new ("Port floor defs carry no `heat` attribute; thermal-generator `sumAttribute(heat)` = 0") | **seeded**: `Blocks.java:327,365,375` (molten-slag/hotrock/magmarock); affects sim + T10b thermal stats |
| PAR-0112, PAR-0132, PAR-0143, PAR-0144, PAR-0142, PAR-0151, PAR-0145, PAR-0047 | unchanged from the pass-1/pass-2 tables |
