<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J03 — Turret and unit draw fidelity

**Goal.** Live turrets draw per `DrawTurret` and live units per `UnitType.draw`, layer for layer.

**Evidence.** Twin report F3, F4; frames `diff/16-zoom.png`, `diff/17-duo-zoom.png`,
`diff/24-zoom.png` (duo head off-axis, no outline), `runs/20261016-J-twin/diff/52-legs-crop.png`
(atrax/arkyid without legs). Atlas check: `duo-outline`, `duo-preview`, `atrax-leg`,
`stell-treads` and `dagger-wreck0` all exist in `assets/sprites/sprites.atlas.json`. The gaps
are in the renderer, not the pack.

**Depends on.** Nothing. T1 unblocks the J02 T4 flyer draw if the unit path is shared.

## T1 — `DrawTurret` parity in the live block pass — HIGH

- Java (`world/draw/DrawTurret.java`):
  - `load` (`:146-170`): `base = <name>-base`, else the mod `basePrefix`, else
    `<basePrefix>block-<size>` (`basePrefix = "reinforced-"` for Erekir turrets). Also loads
    `preview`, `outline`, `liquid`, `top` and `heat`.
  - `draw` (`:72-119`):
    1. `base`;
    2. `Drawf.shadow(preview, x + recoil - elevation, …)` at `shadowLayer`;
    3. at `turretLayer`, `drawTurret`: `region` at `drawrot()`, `Drawf.liquid(liquid, …,
       liquids.get(toDraw) / liquidCapacity, color)`, then `top` (`:121-134`);
    4. `drawHeat` (additive at `heatLayer`);
    5. with `parts`, `outline` at `turretLayer - 0.01` and every `DrawPart` with
       `DrawPart.params` (warmup, reload progress, heat, recoil, per-part `curRecoils`, charge);
    6. `ammoParts` for the current ammo.
- Port: `mind-gdext/src/render/blocks.rs:391-440` draws `block-<size>`, `region`, `-top` and
  `-heat` (alpha, not additive). The `DrawPart` program exists
  (`mind-core/src/fx/parts/*`, `mind-gdext/src/fx/draw_turret.rs`), but is fed only by the
  `MindFx.spawn_turret_draw` debug probe with `AllRegions` (every region "found";
  `mind-gdext/src/fx.rs:489-506`).
- Change:
  1. Base lookup chain + `basePrefix`.
  2. Shadow (reuse `drawf::shadow`).
  3. Liquid region using `liquids.current()` or `liquidDraw` (wave, tsunami, Erekir).
  4. Additive heat at `heatLayer`.
  5. Feed every live turret into the `draw_turret` program each frame. Read
     `warmup/progress/heat/curRecoil(s)/charge` from `TurretState`. Bind the real atlas
     resolver instead of `AllRegions`. Draw parts at their `layer`/`turretShading`.
  6. Delete the probe-only path (or keep it as a test seam).
- Accept: zoomed captures of duo, lancer, ripple, salvo, fuse, cyclone, spectre, meltdown,
  foreshadow and two Erekir turrets (breach, diffuse) match fresh Java captures, idle and while
  firing. A `mind-core` test pins the part draw order for `lancer` (recoil part) and `fuse`.
- Ledger: new item "Turrets draw without shadow/outline/parts/liquid (DrawTurret stub)".

## T2 — Idle turret head orientation — HIGH (needs diagnosis)

- Symptom: a freshly placed duo (rotation 1, no ammo, no target) draws its head rotated off-axis
  (`diff/24-zoom.png`, right half). Java draws it facing up: `rotation = 90`, `drawrot() =
  rotation - 90 = 0`.
- Port facts: `TurretState::new` sets `rotation: 90.0` (`turrets/mod.rs:447`), and `turret_draw`
  returns `state.rotation` (`mind-gdext/src/sim_host.rs:6095-6105`). The renderer pushes
  `rotation - 90` (`blocks.rs:415`).
- Check, in order:
  1. whether the placement path overwrites `TurretState.rotation` with the block rotation;
  2. whether `push` takes radians while receiving degrees, or flips the sign for the y-up camera;
  3. whether the no-ammo branch still turns toward a stale target.

  Write the failing test first (place a duo, step 60 ticks, assert the drawn angle is 0).

## T3 — Pack-time outlines (`Block.createIcons`) — HIGH

- Java `Block.createIcons` (`world/Block.java:1600-1640`): when `outlineIcon` is set
  (`BaseTurret` → every turret, plus `Radar`, `MassDriver`, `PayloadMassDriver` and
  `RepairTurret`), the generated icon `gen[outlinedIcon or last]` is replaced **in place** under
  the same atlas name by `Pixmaps.outline(region, outlineColor, outlineRadius)`. Every
  `getRegionsToOutline` region also gets an outlined `-outline` copy. As a result, Java's live
  `duo` region already carries the dark ring.
- Port: `mind-tools/src/generate/metadata.rs` has `outline_icon(kind)`/`outline_color`, and the
  atlas holds `duo-outline`/`duo-preview`. The live `duo` the renderer draws has no ring, so either
  the in-place replacement is missing or the renderer draws the un-outlined region.
- Change: diff the packed `duo`, `lancer`, `radar` and `mass-driver` regions against Java's atlas
  (`../Mindustry/core/assets/sprites/sprites*.png` + `.aatls`, or a JVM dump). Port the in-place
  replacement for the `outlinedIcon` region, then re-pack (`tools/pack.sh`).
- Accept: the zoomed duo matches `diff/24-zoom.png` (left half).

## T4 — Legged units (`UnitType.drawLegs`) — HIGH

- Java `UnitType.drawLegs` (`type/UnitType.java:1826-…`) draws, per leg (`legCount`, from
  `Legsc.legs()` joints): `legBaseRegion` at `baseRotation`; `legRegion`/`legBaseRegion` from
  base → joint → foot with `legExtension`; `jointRegion`/`footRegion`; the `baseJointRegion`
  under the body; plus `legSplashDamage` FX. The draw order is in `draw` (`:1471-1560`: legs come
  after tank and before payload).
- Port: the leg simulation exists (`mind-core/src/entities/comp/unit/legs.rs`,
  `comp.rs:149-151` `Leg`; IK in `render/math/inverse_kinematics.rs`). `units.rs` emits body,
  weapons, cell and outline only.
- Change: expose per-leg `(base, joint, foot)` from `unit_draws()`, and emit the leg quads in
  Java order and layers (`Layer.legUnit`). Cover `crawler`, `atrax`, `spiroct`, `arkyid`,
  `toxopid` and the Erekir legged units `merui`, `cleroi`, `anthicus`, `tecta`, `collaris`
  (`UnitTypes.java:3153-3615`), plus the `allowLegStep` hover behaviour.
- Accept: spawned atrax/arkyid in a sandbox (`spawn_unit` ids 11/13) match a Java capture of the
  same units (spawn them in Java through a unit factory, or capture `UnitType` previews from
  the Core Database as a static fallback).
- Ledger: PAR-0126 → reopen ("legs not drawn").

## T5 — Tanks, crawlers/segments, wrecks, payloads — MEDIUM

- Java:
  - `drawTank` (`UnitType.java:1806-1824`): `treadRegion` + the animated `treadRegions[][]` per
    `treadRects`.
  - `drawCrawl`: `segments` for the neoplasm units `renale` and `latum`
    (`UnitTypes.java:4316,4335`; `segmentRegions/segmentCellRegions/segmentOutlineRegions`).
  - Wreck decals on death: `UnitComp.java:934-937` `Effect.decal(type.wreckRegions[i], …)`.
  - `drawPayload` for `Payloadc` units (mega, quad, oct carrying blocks and units).
- Port: 0 hits for tread/wreck/segment/payload in `mind-gdext/src/render/units.rs`.
- Change: port each draw in Java order. The wreck decals go through the FX decal path (PAR-0128
  machinery). Payload units read the carried payload list from the PAR-0138 payload state.
- Accept: stell/locus (treads), renale (segments), a destroyed dagger (wreck pieces) and a quad
  carrying a block, each against a Java capture.

## T6 — Weapon outlines, unit parts and ability draws — MEDIUM

- Java:
  - `drawWeaponOutlines` (`:1744-1761`).
  - `Weapon.outlineRegion/cellRegion` (missing from the audit).
  - `UnitType.parts` drawn after shields (`:1560`).
  - Ability `draw(Unit)` for `ForceFieldAbility`, `EnergyFieldAbility`, `ArmorPlateAbility`,
    `UnitSpawnAbility`, `MoveLightningAbility`, `SuppressionFieldAbility` and
    `ShieldArcAbility`.
- Port: `units.rs` has weapon/outline mentions. Verify whether weapon *outlines* are drawn. Unit
  `DrawPart`s and ability draws have no hits in the render tree (shields.rs covers only
  `UnitType.drawShield`).
- Change: draw weapon outlines per Java, run unit `parts` through the same `DrawPart` program as
  T1, and add one draw per ability class.
- Accept: quasar (armor plate), oct (force field), aegires (energy field), quell/disrupt (unit
  spawn/suppression) and the Erekir units with parts, each against a Java capture.

## T7 — Status marker shape — LOW (with PAR-0348)

- `BuildingComp.drawStatus` (`entities/comp/BuildingComp.java:1221-1233`) draws two
  `Fill.square(…, 45)` (a grey 2.5 and a coloured 1.5, times 0.64 for size-1 blocks) at the
  bottom-right corner. The Godot markers in `diff/24-zoom.png` are axis-aligned squares with a
  dark border. Resolve the Arc `Fill.square` rotation convention once (PAR-0348) and apply it
  here.

## Done criteria

T1, T2 and T4 landed with in-engine Java-matched frames. T5/T6 landed or recorded with exact
residuals. A summary is in `docs/J03-turret-unit-draw_summary.md`.
