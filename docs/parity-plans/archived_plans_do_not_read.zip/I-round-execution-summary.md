# Round-I parity execution — consolidated summary (for the higher-thinking verifier)

Executed 2026-10-15 13:30 → 2026-10-16 (AEST) by the scheduling coordinator with per-plan subagent executors.
Plans and schedule: `docs/parity-plans/I-INDEX.md`; shared rules: `docs/parity-plans/I-environment.md`.
This file is the one-stop synthesis; every claim below has its per-plan detail in `REPO/docs/I<NN>-*_summary.md`
and raw evidence under `REPO/runs/`.

## 1. Headline

- `main` final: `f2baaa4b` + `395cf6d0` (`chains: apply round-I ledger changes (I01-I08 summaries)`).
- Final gate (post-merge): mind-core **2693 passed / 0 failed / 4 ignored**, mind-headless **133**, mind-gdext **54**,
  mind-stdb **49** (checked at the I08 merge), `cargo clippy -D warnings` clean, `cargo fmt --check` clean,
  `parity goldens` **97 PASS / 0 other**, GDScript parse gate clean, `fx_golden` 2 passed.
- **Plans complete: I00, I01, I02, I03, I04, I05, I07.**
- **I06**: complete short of T12.9 (blocked — see §4) and recorded residual lists (T12.4/T12.5, `state.mapLocales`).
- **I08**: T1–T6 landed; **deferred by operator request mid-run** (no continuation launched; see §5).
- Round-H ledger changes were applied by I00 (36 updates/notes, 79 new items PAR-0249..PAR-0327);
  round-I ledger changes were applied in `395cf6d0` (47 updates + 13 notes, 31 new items) per §7.

## 2. Per-plan status

| Plan | State | Merges into `main` | One-line result |
|---|---|---|---|
| I00 | complete | a4578878, 91492792, c2ba1f69 | session-4 H03 merge + ledger + baseline |
| I01 | complete (T1–T16) | a40cea26, 45b9a4d6, 40c57e3d, 6f4530cd | sim residuals + verification sweep |
| I02 | complete (done criteria met) | 90d2b688, 9d32f9d0, c13b14b3 | pods/render/status/FX/toasts; T9 no-change; T11 verified |
| I03 | complete (T1–T14) | fb513f47, aa7fad13, 210aa90d, e1b85193, 51a55a23 | logic runtime + displays/canvas + full logic editor |
| I04 | complete (T1–T17) | 5a1f7989, 84eaee31, eeb11c72, f2baaa4b | campaign UI: stats, schematics, planet globe, enemy bases |
| I05 | complete (T1–T5) | 546ceaab | settings hub seam, locale, hotkeys, audit |
| I06 | near-complete | 506989c7, 0f3bf6a2, 3d029285, 767ed025, 89b01296, 872a7430, 20e160ac | custom maps + editor + 12 sub-dialog fidelity series; T12.9 blocked |
| I07 | complete (T1–T8) | 48bc7a23, 498c4a12, d60dfee3 | mods end-to-end + exports ship assets + CI smoke |
| I08 | **deferred** (T1–T6 of 13) | 726ce0cd | relay harness/identity/servers/host/join/command relay |

Coordinator fix commits on top: `4f95c4e0` (I06 settings-hub call sites, found by the merge gate).

## 3. What landed per plan (condensed; deviations → per-plan summaries)

- **I01** (s2, 3 passes): CoreItem objective text; solid closed doors; `collideLine` rounding; pathfinder health
  re-pack + `costGround`; ammo `rangeChange` turret range; air/ground area damage; Erekir `requiresCoreZone`;
  `ignoreBuildDarkness`; coolant from current liquid; fog debug readbacks; unit ids across saves + cargo-loader body;
  assembler save body + drone arrangement; queued orders over the wire (simlog v2); power-graph relink (PAR-0286);
  turret block units + core control select (**PAR-0138 verified**); verification sweep incl. a live-found
  "turrets had no TurretState after the I07 content-boot change" fix. Known deviations recorded: doors don't refuse
  to close on units; markers region skipped (all presets empty); power-ammo rangeChange reads 0; 7/78 Serpulo presets
  fail legacy import (new ledger item); PAR-0168 **did not reproduce**.
- **I02** (s4, 3 passes): finished the parked H03 T13 launch/landing pods (inverted launch alpha fixed); no
  empty/freed mesh surfaces; block status markers with the 30-tick efficiency pulse; `flashHit` wall flash; beam
  node/tower lasers + dedupe; pre-`DrawDefault` extras moved under the sprite; top-centre toasts; fog-gated step
  sounds; block FX tile size was 32 px not 8 (**fix**); doors now emit open/close FX and raw configs are no longer
  tap-throttled (**fix**). PAR-0055 verified (sprite scale within 4.2% of Java after frame-matched measure);
  PAR-0244/PAR-0129/PAR-0188/PAR-0191/PAR-0157 verified in-engine. Open follow-ups (recorded): `FxEmit::square`
  45°-vertex audit across ~30 call sites; door close-guard; power-node shimmer tick/seconds; T3 partially-powered
  crafter staging; LegsComp leg-base emitter.
- **I03** (s3 then s5, 5 passes): LogicAI `ubind`/`ucontrol`/`ulocate`; objective `completionLogicCode`; sensor/fetch
  tables + family `logic_sense` overrides; logic turret control; radar `argmax` semantics (golden re-baselined
  `a740d5e42b2bb201`→`88460edb203c67e0`, farthest 4→5, old value encoded an inverted sort); processor links +
  pencil panel; logic displays (CPU raster + render pass); canvas blocks; full logic editor (dialog, generic +
  per-statement field layouts, jump arrows, drag reorder, add dialog, variables/globals, overlays). PAR-0221/0224/
  0223/0222/0220/0218/0105/0225/0103 verified. Deviations recorded (icon-tag config dropped, CPU raster, canvas
  edge sprites, simplified icon pickers, `@add` gate on world-processor saves, etc.).
- **I04** (s2, 4 passes): palette rebuild on `world_loaded`/`block_unlocked` + loaded-world planet sourcing (merged
  with I07 T6b's live-registry catalog in the coordinator resolution); `MindHud.push_unlock` + Java-style unlock
  toast; hint predicates (`factorycontrol`, `cannotupgrade`, `cores_destroyed`); content stats families (logistics,
  storage, logic, defense, unit factories, turrets/ammo, unit weapons); schematics dialog (**PAR-0143**); database
  tabs (**PAR-0144**); dialog fade over 0.1 s; planet globe hex mesh + Serpulo emissive + bloom (**PAR-0142**);
  sector rename/icon picker + globe drag/zoom/preset reveal; sector stats dialog; enemy bases `BaseGenerator`
  (**PAR-0112 verified** — T17, headless tests + a forced-non-preset in-engine run). Note: a pass exited silently
  mid-task; its T10 work was recovered and finished by the next pass.
- **I05** (s4): `gdext/settings_hub.rs` seam (init/with_settings/reload/save) replacing facade-local flags; locale
  persistence + boot bundle selection + dialog per Java; block hotkeys/arrow navigation/pick/F1 per
  PlacementFragment; settings-effect audit (19 inert rows recorded with their Java readers); input re-verification.
  PAR-0164/0135/0214/0209 verified.
- **I06** (s5, 8 passes): custom maps load + gamemodes + Map Play dialog (**PAR-0133**), Custom Rules + pause-menu
  live edits (**PAR-0132**), save import + card actions (**PAR-0134**), map previews (**PAR-0114**), editor rendering
  (**PAR-0109**), editor menu + maps dialog + New Map (**PAR-0110**, near-complete), map view input (**PAR-0113**),
  exit confirm (**PAR-0111**), and the T12 sub-dialog series (wave info, map generate, resize, processors, banned
  content, locales, objectives incl. markers/seq editors, sector generate). Bugs found+fixed along the way:
  fastjson `rules`-tag fallback; float-vs-int rules JSON; `MindTable` invisible cells; preview pixel bugs;
  generation-filter float round-trip; `PackedStringArray` picker guard; `list_select` stacking.
- **I07** (s4, 2 passes + re-run): mod enable/fail persistence (**PAR-0117**), launch-crash restore (**PAR-0118**),
  script-mod unsupported mark (**PAR-0116**), one content-boot path + live registries + mod sprites/sounds +
  end-to-end placement (**PAR-0115**, incl. the sandbox half that found "mod blocks missing from the sandbox
  placement palette"); exports ship assets + asset-root resolution order + `export.sh` + CI `export-smoke`
  (**PAR-0119**).
- **I08**: see §5.

## 4. Blocked: I06 T12.9 (editor assets dialog)

Not attempted: the plan-20 client half does not exist, precisely — (1) no gdext node owns a `ModDataManager`
(Java `GameState.data`, consumed by Mods/Logic/NetServer/NetClient/editor); (2) the gdext decorator that applies
image/audio/bundle records is unported (core docs assign it to plans 03/18); (3) the editor writes `patches: None`
(`maps/mod.rs:463`) and the zip facades (`editor/assets.rs`) are unused; (4) the dialog is a 66-line stub vs Java's
274 + ~1,300 lines. Evidence: `docs/I06-custom-games-editor_summary.md` `# Pass 8`.

## 5. Deferred: I08 (multiplayer) — operator request, 2026-10-16

Landed and merged before the deferral (`726ce0cd`, commits on `parity/session-3`):
T1 local harness (`tools/mp-local.sh`, `MindNet.ensure_online`, `session_changed`, `@connectfail`);
T2 name/colour persist + reducers; T3 join dialog saved servers + per-server probes (**PAR-0136 verified**);
T4 host current world + snapshot publish (**PAR-0120 verified**); T5 join/late-join via snapshot
(**PAR-0123 verified**, two-client screenshots identical); T6 every player action relayed/applied
(**PAR-0120**; checksum-equality clause blocked by the `checksum_scoped` stub → T13).
Two-client evidence: `runs/20261016-s3-I08-t1/`.

Remaining (deliberately not started): T7 remote players, T8 chat, T9 player list/admin (+ reducer-error surfacing),
T10 dedicated server, T11 per-match chat filters, T12 host dialog layout (**PAR-0151**), T13 desync resync/scoped
checksum. Ledger items still open from this plan: PAR-0121, PAR-0122, PAR-0124, PAR-0125, PAR-0151.

## 6. Coordinator incidents worth knowing (all resolved, none left open)

1. Two operator "manual commit" snapshots mid-run (`046ab375`, `9811ccbe`) swept live `.opencode` caches +
   `parity-ledger.json` + docs into main. The tracked `parity-ledger.json` blocked worktree merges (worktrees keep
   it as a shared symlink); fixed by restoring the symlinks with `git update-index --skip-worktree` in all four
   worktrees. No executors read the ledger; `chains.json` untouched by them.
2. The coordinator merge gate caught I06 code written against pre-I05 APIs (`live_setting_flag`, `MindUi.settings`)
   → fix `4f95c4e0`.
3. I04's `block_catalog_json` conflict was resolved by combining both intents (live registry + loaded-world planet).
4. I04 pass 2 died silently with uncommitted T10 work; pass 3 recovered it (documented in its summary).
5. I06 pass 5 surveyed but committed nothing; pass 6 relaunched with the survey notes baked in.
6. One subagent resume failed ("session not found"); fresh sessions were used since.
7. Subagent-authored golden changes: `parity/golden_content.json` unchanged; `tests/goldens/ui/campaign.json` and
   the campaign golden were regenerated with reasons recorded in the per-plan summaries.

## 7. Ledger

- Round H: applied by I00 (`91492792`): 36 updates/notes, new items PAR-0249 (fillItems) .. PAR-0327.
- Round I: applied in `395cf6d0` — **47 updates + 13 notes, 31 new items (`PAR-0328`..`PAR-0358`)**.
  The applier mapped id-less rows onto their matching round-H placeholders instead of duplicating them
  (unit-ids/cargo-loader → PAR-0273, assembler body → PAR-0274, queued orders → PAR-0140 note, palette →
  PAR-0306, etc.); no unknown-id and no title-mismatch skips. `updated` stamp `2026-10-16T18:00:00+10:00`;
  `chains` count unchanged (49).
- New-item candidates reported but judged non-issues: PAR-0168 (did not reproduce), PAR-0285 (not a bug).

## 8. Where the detail lives

- Per-plan summaries (uncommitted unless an operator snapshot committed them): `docs/I01-sim-residuals_summary.md`,
  `I02-rendering-hud_summary.md`, `I03-logic_summary.md`, `I04-campaign-ui_summary.md`,
  `I05-settings-language-input_summary.md`, `I06-custom-games-editor_summary.md`, `I07-mods-export_summary.md`,
  `I08-multiplayer_summary.md`, `I00-coordinator_summary.md`.
- Schedule/status: `docs/parity-plans/I-INDEX.md` §5. Evidence: `runs/<date>-s<N>-<plan>-<task>/` per task.
- All executors followed: one task = one commit, flock-serialized cargo, no Java client launched,
  chains/parity-ledger never edited, `runs/` never staged.

## 9. Follow-up list (for the next round)

1. I08 T7–T13 (when multiplayer is undeferred; start with T13's `checksum_scoped` stub, needed by T6's clause).
2. I06 T12.9 (needs the plan-20 data-asset client half) + recorded T12.4/T12.5 residue + `state.mapLocales`.
3. I02 recorded FX/audio follow-ups (FxEmit square audit, door close-guard, shimmer timebase, LegsComp emitter).
4. I01 recorded deviations (door close-on-unit guard; 7 broken Serpulo preset imports — new ledger item).
5. Ledger: apply any remaining per-summary notes the applier skipped after review.
