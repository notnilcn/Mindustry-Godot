<!-- SPDX-License-Identifier: GPL-3.0-only -->
# G05 campaign UI — session 5 summary (partial: T1a-T4b, T10a, T10b landed)

Branch: `parity/session-5` @ `e9c9c54b` (3 commits on top of `main` @ `b5408b9f`), worktree
`/home/clintonnguyen/g/code_examples/Mindustry-Godot-session5`.
Wave 2 base `main` @ `ef54dfa`; dependency re-run base `main` @ `b5408b9f`.
Bridge port 7010, display :14, imported profile restored (375/282).

## Task status

| Task | Status | Commit | Notes |
|---|---|---|---|
| T1a | **done** | `cd39ed46` | research tree read model, BranchTreeLayout, canSpend, distribute_removal, `research_tree_json` |
| T1b | **done** | `863be28a` | research graph view (buttons/connectors/pan/zoom/root selector) |
| T1c | **done** | `ef2ea54f` | hover popup, `@globalitems` pool, uiUnlock emit-only |
| T2 | **done** | `86471a81` | 0.9 dim, stacked dialogs, modal prompts |
| T3 | **done** | `e2727648` | sector panel launch candidate/locked objectives/vulnerable/threat colour |
| T4a | **done** | `53d80cfc` | hints driver + hint events + `hint_state_json` |
| T4b | **done** | `4283156e` | 22 predicates, input completions (G08 `take_hint_keys`), fire/derelict hooks |
| T10a | **done** | `84cb2135` | `SchematicView.tiles` + `MindSchematicImage` + loadout cards |
| T10b | **done** | `e9c9c54b` | schematics card grid, tags row, in-game `use_schematic` |
| T5a-T5e | not started | — | content stats |
| T6-T8 | not started | — | globe controls / rename+icon / stats dialog |
| T9a-c | not started | — | generated sectors |
| T11 | not started | — | database tabs |
| T12a-c | not started | — | globe mesh/bloom |
| T13 | not started | — | cosmetics |

## Commits

```
e9c9c54b Fixes PAR-0143: schematics dialog tags row and card grid (T10b)
84cb2135 Gameplay G05 T10a: SchematicImage widget and Configure Loadout schematic toggles
4283156e Gameplay G05 T4b: remaining HintsFragment predicates and hint events
53d80cfc Gameplay G05 T4a: hints driver matches HintsFragment (no timed completion, order, playtime gate) + hint inputs
e2727648 Gameplay G05 T3: planet sector panel launch candidate, locked objectives, vulnerable rule and threat colour
86471a81 Fixes PAR-0148, PAR-0149, PAR-0150: 0.9 dialog backdrop, stacked dialogs stay drawn, modal confirm/text-input (T2)
ef2ea54f Fixes PAR-0145: research hover info, global items display and unlock sound (T1c)
863be28a PAR-0145: research dialog node graph, connectors, pan/zoom and root selector (T1b)
cd39ed46 PAR-0145: research tree read model, BranchTreeLayout port, Java canSpend and item removal (T1a)
```

## Test commands + results (final state of the branch)

* `cargo test -p mind-core --lib --features msav-import` → **2167 passed / 0
  failed / 4 ignored** (baseline 2166 + `fire_creation_records_hint_event`).
* `cargo test -p mind-headless --lib` → **132 passed / 0 failed**.
* `cargo test -p mind-headless --lib ui_goldens_match` → pass; the UI campaign
  golden regenerated twice on this branch (T3 SectorView fields, T10a
  `SchematicView.tiles` list); `harness_ui_campaign` sha256 updated each time,
  reasons in the commit bodies.
* `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` clean;
  `cargo fmt` applied.
* GDScript parse gate clean after every .gd/.tscn edit.

## In-engine evidence per task (runs/ shared with main)

* T1a `runs/20261013-s5-G05-T1a/`: 223 nodes, node 0 = core-shard (0, 90),
  `""` → serpulo, lancer locked=false reqs=0 (PAR-0160).
* T1b `runs/20261013-s5-G05-T1b/`: graph + zoom 0.9.
* T1c `runs/20261013-s5-G05-T1c/`: hover "Core: Shard / Researched"; locked
  requirement rows.
* T2 `runs/20261013-s5-G05-T2/`: stacked `[planet, research]`; confirm.png;
  single-Esc closes both prompts.
* T3 `runs/20261013-s5-G05-T3/`: launch_from 170 → Configure Loadout launcher
  170; locked objectives; threat panel.
* T4a `runs/20261013-s5-G05-T4a/`: hint survives past 30 s; wheel completes
  `zoom`.
* T4b `runs/20261013-s5-G05-T4b/`: fresh profile — 6 conveyors → `breaking`
  shown/displayed (breaking.png); copper 4000 → `coreIncinerate` shown and
  displayed (core-incinerate.png); `hint_event("derelictmouse")` lands while
  `derelict` stays hidden in the tutorial; `_hint_complete("breaking")` false
  without a break event.
* T10a `runs/20261013-s5-G05-T10a/loadout-cards.png`: core-shard 200x200 card
  with centered plan region + silhouette.
* T10b `runs/20261013-s5-G05-T10b/cards.png` (26 cards with previews/badges),
  `tags-row.png`.

## Deviations / blockers

* No player unit spawns on a fresh or imported Ground Zero
  (`spawn_player_at_best_core` returns no supported core — the G01 T10 respawn
  flow is not on main), so player-builder completion paths (break event,
  depositItems, payloads, unitControl) are covered by unit tests + input
  completions rather than live play; `cannotupgrade`/`factorycontrol` have no
  firing site in the port; `unitSelectControl` uses
  `commandMode && selection > 0` (no CommandAI targetPos readback).
* T4b: the imported Ground Zero save carries `rules.env = 31`, so
  `!hasEnv(scorching)` (Java's isSerpulo) is false there — the predicate is
  faithful, the env data is a G04 observation.
* T10a: the `schematic-background` PNG is not packed into the atlas, so the
  card uses a flat dark backing (recorded); `drawPlanConfigTop` overlays are
  skipped (plan-sanctioned).
* T10b: `showAllTags` tag editor and Steam workshop links stay deferred; the
  profile's `schematic-tags` is empty so the tags row is hidden in vanilla.
* T1b/T2: root selector is a PopupPanel; dialog hide fade-out stays instant.

## Ledger changes to apply (coordinator)

| Item | New status / note |
|---|---|
| PAR-0145 | `fixing` — T1a/T1b/T1c evidence in place; a live spend replay would settle `verified` |
| PAR-0047 | node graph + hover popup done |
| PAR-0160 | `verified` |
| PAR-0148 / PAR-0149 / PAR-0150 | `verified` |
| PAR-0143 | `fixing` — card grid + tags row + `use_schematic` click path done; in-game placement verified via G08's seam |
| PAR-0025/0026/0027/0085 | T10a cosmetic remainder done (200 px SchematicImage toggles) |
| new (T4a/T4b) | hints: no timed completion, Java predicates + input completions + fire/derelict events |
| new (T3) | planet launch candidate/locked objectives/vulnerable/threat colour |

## Handoff notes for the next session

* Branch state green (gates above); imported profile restored (375/282).
* Start at T5a (`core/ui/content_stats.rs`) then T6/T7/T8, T9a-c, T11, T12a-c,
  T13 per the plan order; `git merge --ff-only main` first (wave-2 merges may
  have landed since `b5408b9f`).
* T4b's remaining data gaps: `cores_destroyed` (GameStats per-core tracking)
  and the UnitSelectControl CommandAI/targetPos readback.
