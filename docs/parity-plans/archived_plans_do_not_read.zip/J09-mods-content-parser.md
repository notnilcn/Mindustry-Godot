<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J09 — Mod content parser coverage and mod content everywhere

**Goal.** A JSON/HJSON content mod that loads in Java loads in Godot with the same blocks,
consumers, drawers, parts, bullets, effects, weapons, AIs and abilities. Mod content then shows up
on every surface (palette hotkeys, map previews, editor), and the plan-20 data-asset client half
exists so map assets and patches work.

**Evidence.**
- Twin report §3.1: 56 classes named nowhere in the port; 13 of them are only reachable
  through `ClassMap`.
- A class-level diff of `ClassMap.classes.put(...)` (`mod/ClassMap.java`, 500 entries) against
  `parity/mod_classmap.json` (224 aliases): 276 Java names are missing. Most are `*Build`
  inner classes that mods never name; the parse-relevant remainder is listed in T1.
- `parity/ledgers/mod_fields.md` TODO rows.
- Round-I audit: `editor/preview.rs` and `MindInput.load_catalog` are base-only.

**Depends on.** J04 T2 (the explode consumer), J03 T1 (`DrawPart` live) and J02 T2 (tiled floors)
supply the runtime behaviours that the parser maps onto.

## T1 — `ClassMap` aliases that mods use — HIGH

Add `mod_classmap.json` entries and parser arms, with Java-default field values, for:

| Scope | Missing classes |
|---|---|
| Consumers | `ConsumeItemCharged`, `ConsumeItemDynamic`, `ConsumeItemEfficiency`, `ConsumeItemExplode`, `ConsumeItemExplosive`, `ConsumeItemFilter`, `ConsumeItemFlammable`, `ConsumeItemList`, `ConsumeItemRadioactive`, `ConsumeItems`, `ConsumeLiquid`, `ConsumeLiquidBase`, `ConsumeLiquidFilter`, `ConsumeLiquidFlammable`, `ConsumeLiquids`, `ConsumeLiquidsDynamic`, `ConsumePayloadDynamic`, `ConsumePayloadFilter`, `ConsumePayloads`, `ConsumePower`, `ConsumePowerCondition`, `ConsumePowerDynamic`, `ConsumeCoolant` |
| Drawers | `DrawBlock`, `DrawDefault`, `DrawMulti`, `DrawArcSmelt`, `DrawBubbles`, `DrawCells`, `DrawCircles`, `DrawCrucibleFlame`, `DrawCultivator`, `DrawFade`, `DrawFlame`, `DrawFrames`, `DrawHeatInput`, `DrawHeatOutput`, `DrawHeatRegion`, `DrawLiquidOutputs`, `DrawLiquidRegion`, `DrawLiquidTile`, `DrawMultiWeave`, `DrawParticles`, `DrawPistons`, `DrawPlasma`, `DrawPower`, `DrawPulseShape`, `DrawPumpLiquid`, `DrawSoftParticles`, `DrawSpikes`, `DrawWeave`, `DrawBlockParts` |
| Parts | `DrawPart`, `RegionPart`, `ShapePart`, `HaloPart`, `HoverPart`, `FlarePart`, `EffectSpawnerPart`, `PartProgress`, `PartMove`, `PartFunc`, `PartParams` |
| Bullets | `ContinuousBulletType`, `ContinuousFlameBulletType`, `EmptyBulletType`, `InterceptorBulletType`, `MultiBulletType`, `PointBulletType`, `PointLaserBulletType` |
| Effects | `ParticleEffect`, `RadialEffect`, `SeqEffect`, `SoundEffect`, `NoiseEffect`, `TriangleEffect`, `ExplosionShield` |
| Weapons / shoot | `Weapon`, `BuildWeapon`, `MineWeapon`, `PointDefenseWeapon`, `PointDefenseBulletWeapon`, `RepairBeamWeapon`, `HealBeamMount`, `ShootSine`, `ShootSummon` |
| AI | `BoostAI`, `FlyingAI`, `GroundAI`, `MinerAI`, `RepairAI`, `PrebuildAI`, `LogicAI` |
| Blocks | `Turret`, `BaseTurret`, `ReloadTurret`, `PayloadAmmoTurret`, `PowerGenerator`, `PowerBlock`, `PowerDistributor`, `LiquidBlock`, `PayloadBlock`, `UnitBlock`, `BlockProducer`, `SingleBlockProducer`, `DuctJunction`, `DirectionBridge`, `ControlBlock`, `UnitTetherBlock`, `HeatBlock`/`HeatConsumer`, `TiledFloor`, `TiledWall`, `WobbleProp`, `RotBlock` |
| Abilities | `ArmorPlateAbility`, `EmptyDataAbility` |
| Data | `ItemStack`, `LiquidStack`, `PayloadStack`, `UnitPlan`, `AssemblerUnitPlan`, `AmmoEntry`, `Attributes`, `Category`, `Objective`/`Objectives` |

- Java reference: `mod/ClassMap.java` (generated) and `mod/ContentParser.java` (`classParsers`,
  `parser.readValue`, the `consumes`/`drawer`/`parts` special cases).
- Regenerate with `mind-tools mods classmap` (`--check` gates drift). Each alias needs a parser
  arm or an explicit "unsupported, warn" entry, never a silent drop.
- Tests: one fixture mod under `parity/mod_fixtures/` per scope. Each loads in `mind-headless`,
  and the parsed def matches the Java default-filled values (dump them once from the JVM with
  the existing `parity/tools` harness).

## T2 — `mod_fields.md` TODO rows — MEDIUM

Close the rows still marked TODO or partial:
- `UnlockableContent` fields (`UnlockFields`);
- `consumes` JSON parse (the patch merge is done);
- `drillMultipliers` parse;
- `assembler plans`;
- weapon effect/draw parts;
- inline `MultiEffect`/array effects;
- `draw` (drawer) parsing;
- `type` partial aliases.

Update `parity/ledgers/mod_fields.md` as each row lands.

## T3 — Mod content on every surface — MEDIUM

1. `MindInput.load_catalog` builds the `1`..`0` quick-select lists from
   `mind_core::ui::campaign::block_catalog()`, which is base content
   (`mind-gdext/src/input/mod.rs:339-353`). Use `block_catalog_from(live registry, …)` like the
   palette (I07 Pass 3 note 1).
2. `MindPreview` boots its own base registry (`mind-gdext/src/editor/preview.rs:134`
   `create_base_content`), so mod blocks render as unknown in map previews and map lists. Use
   the shared content boot (`content::boot::build_registry_with_mods`).
3. Audit every other `create_base_content` call in `mind-gdext`
   (`grep -rn create_base_content client/rust/mind-gdext/src`) and route each through the live
   registry, or document why it must stay base-only.

## T4 — Plan-20 data-asset client half (`ModDataManager` host + decorator) — MEDIUM

- Java: `GameState.data = new DataManager()` (`core/GameState.java:47`), consumed by mod boot,
  `Logic.java:305`, `NetServer` and `NetClient` runtime textures, and the editor asset views.
  Image, audio and bundle records are applied to the live atlas, sounds and bundle.
- Port: `mind_core::mods::assets::ModDataManager` and `DataAsset*` exist, plus
  `editor/assets.rs` `import_zip`/`export_zip`. Nothing in gdext owns a manager, the "decorator"
  that applies records (`mods/assets/mod.rs` says "applied by the mind-gdext decorator, plan
  03/18") does not exist, and map saves write `patches: None` (`maps/mod.rs:463`). Details are in
  the I06 Pass 8 T12.9 investigation.
- Change:
  1. Add an owner node (e.g. `MindMods` or a new `MindData` autoload) holding the manager.
  2. Add the decorator: atlas image packing at runtime, `AudioStream` registration and bundle
     merge.
  3. Load/save integration: read map `patches` on load, write them on editor save.
- Unblocks J08 T5.

## T5 — Script mods — DEVIATION (keep)

Java runs JS mods (`Mods.loadScripts`, `mod/Mods.java:803-834`). The port marks them
`ScriptsUnsupported` (I07 Pass 1 deviation 1). Keep the deviation. Make sure the unsupported
reason appears in the Mods dialog row in the Java `getStateText` position.

## Done criteria

T1 and T3 landed with fixture mods. T2 rows are updated. T4 has a working owner and decorator (or
a recorded blocker with the precise missing seam). A summary is in
`docs/J09-mods-content-parser_summary.md`.
