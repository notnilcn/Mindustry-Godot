<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H00 blockers — execution summary (session 1, main checkout, 2026-10-14)

Plan: `docs/parity-plans/H00-blockers.md`. Session: 1 (main checkout,
bridge 6970, display `:10`), alone on the host. All tasks run, all acceptance
checks executed. Commits on local `main` (never pushed).

## Per-task status

| Task | Status | Evidence |
|---|---|---|
| T1 Java Env bits | **done** | commits `c3957b3a`; in-engine env 233 + alpha spawns + `runs/20261014-s1-H00-T1/gz-alpha.png` |
| T2 player plans need a builder | **done** | commit `3a4a2009`; in-engine queued plan (progress 0.278) + `runs/20261014-s1-H00-T2/plan-queued.png` |
| T2b waves start at 1 | **done** | commit `347651b5`; hud wave 1 on resume + fresh sector 98; `run_wave()` at wave 1 = exactly one dagger |
| T3 Ground Zero wave-1 smoke | **done (wave 1 passes)** | eval samples below; `runs/20261014-s1-H00-T3/wave1.png`, `wave1-cleared.png`, `wave1-core.png`; wave 2 recorded (flare kills the core — evidence for H01/H02) |
| T4 new baseline | **done** | marker commit `4fbfcf54`; numbers in "Baseline after H00" below |

`git log --oneline ffbe84dd..HEAD` (local `main`):

```
4fbfcf54 H00: blockers fixed (Env bits, player plans); baseline for round H
347651b5 Gameplay H00 T2b: waves start at 1 and spawn getSpawned(wave - 1) on every path
3a4a2009 Fixes PAR-0215: player plans with no build-capable unit are dropped instead of applied instantly
c3957b3a Fixes PAR-0174: Java Env bits for planet rules (Serpulo env 233), so the core spawns the player unit
```

(`88d9605f manual commit` is pre-existing/unrelated session data and is below
`ffbe84dd..HEAD`'s base — it does not touch `core/game/planet.rs` or
`core/sim/mod.rs fn command`; verified with `git show --stat`.)

## Exact test commands and results (final tree)

All from `client/rust` with `flock /tmp/opencode/mg-build.lock` and
`CARGO_BUILD_JOBS=6`:

| Command | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` | **2211 passed / 0 failed / 4 ignored** (baseline was 2202; +9 new tests) |
| `cargo test -p mind-headless --lib` | **132 passed / 0 failed** |
| `cargo test -p mind-gdext --lib` | **34 passed / 0 failed** |
| `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings` | clean (no output) |
| `cargo fmt -p mind-core -p mind-gdext -- --check` | exit 0 |
| `cargo run -q -p mind-headless -- parity goldens` | **97 PASS / 0 FAIL** (incl. `harness_campaign_sector_cycle`, `harness_ui_campaign`) |
| `tools/build.sh` | `Finished \`dev\` profile`, `sync_scenarios: synced 11 file(s)` |
| GDScript parse gate (`bash tools/godot.sh --headless --editor --quit --path client`) | no `SCRIPT ERROR` / `Parse Error` |
| `cargo test -p mind-headless --test fx_golden` | `fx_audit_and_smoke_pass` **ok**; `fx_scenarios_match_committed_goldens` **FAILED on `fx_program_explosion`** — identical to the documented pre-existing failure owned by H03 T1 (y2 1 ULP) |
| `grep -c panic $U/logs/godot.log` after every in-engine step | **0** |

Note: `cargo test -p mind-headless ui_goldens_match` (H-environment §2) matched
0 tests ("2 filtered out") — the test name drifted; the UI/campaign goldens are
covered by `parity goldens` and the `campaign_scenarios` golden tests inside
`mind-headless --lib`, both green.

Golden regenerated (T1): `client/rust/mind-headless/tests/golden/campaign/sector_cycle.json`.
Only line changed: `rules_checksum` `3dd8cb23026a8193` -> `dbb66943087cba6f`
(`Env` is part of the rules checksum; every other field identical). sha256 in
`parity/golden_manifest.json` updated (`468f6adb…` -> `1b1db1e4…`) in the same
commit. No other golden needed a change.

## In-engine evidence per task

Shared facts: clean profile re-import before T3
(`rm -rf ~/.local/share/godot/app_userdata/Mindustry-Godot` +
`tools/session-play.sh 1 --import` ->
`{"nodes": 375.0, "unlocked": 282.0}`; `saves/` has `sector-serpulo-170.msav`).
Ground Zero entered via the "Go" path (H-environment §4.1). Note: session 1 has
no isolated XDG dir — `U = /home/clintonnguyen/.local/share/godot/app_userdata/Mindustry-Godot`.

### T1 (`runs/20261014-s1-H00-T1/`)

After the "Go" resume on Ground Zero:

```
$MC.get_rules_json() -> env: 233.0        (was 31)
$MC.get_rules_json() -> planet: "serpulo"
$H.has_player_unit() -> true
$H.player_unit_pos() -> [1036.0, 444.0]   (pre-H01 T1 half-tile Pos, as the plan expects)
log: "[I] spawn_player_unit: core unit team 1 spawned"; "no supported core" count 0; panic count 0
```

Screenshot `gz-alpha.png`: the alpha mech on the core-shard, tutorial hint
("Move near the copper ore…") visible. Change 7 finding: **already applied on
resume** — `play_sector` calls `apply_sector_preset_rules` (`play.rs:462`)
which runs `planet_record.apply_rules` (`play.rs:314`), matching
`J/io/SaveVersion.java:203`; no code change. Fresh sector 98 also reads
`env` 233.

### T2 (`runs/20261014-s1-H00-T2/`)

```
$I.select_block_by_name("copper-wall") -> true
$H.set_paused(true); $C.tile_to_screen(135, 58) -> {"x":752.0009765625,"y":243.999755859375}
godot_input LMB press+release at viewport (752,244) -> {"ok": true} x2
$H.step(10); return $H.player_build_plans_json()
  -> [{"x":135,"y":58,"rotation":1,"block":"copper-wall","breaking":false,"progress":0.2777777910232544,"stuck":false}]
$H.construct_progress(135,58) -> {"block":"copper-wall","deconstructing":false,"progress":0.277777791023254}
$H.step(600); $H.building_debug(135,58) -> {"block":216.0,"team":1.0,...}; content_list("block")[216] == "copper-wall"
```

Screenshot `plan-queued.png`: build beam from the alpha to the ghost copper
wall, "Paused" indicator, wall not yet placed. The placement was queued, not
instant (progress < 1), and completed over time for the normal core cost.
Headless: the three T2 tests in `sim::builder` (drop place / drop break /
core-less stays instant).

### T2b

Ground Zero resume (clean profile), immediately paused:

```
$MC.get_hud_state() -> [1.0, 21600.0, true]     # wave 1 before any wave (was 0)
$H.set_paused(true); $MC.run_wave() -> true
$H.step(5); $H.unit_debug_json()
  -> alpha (team 1) + EXACTLY ONE team-2 dagger; no flares
$MC.get_hud_state().wave -> 2.0
```

Fresh preset sector 98 (`load_sector` + `start_sector`):

```
$MC.get_hud_state() -> [1.0, 14400.0, true, "serpulo", 233.0]
```

Recorded for the coordinator: `run_wave()` at `state.wave` 2 (index 1) spawns
1 dagger + 2 flares (the built-in table's wave-2 group) — the pre-fix off-by-one
is gone.

### T3

Run 1 (clean profile; drill at (130,48), duo at (132,48), 1800 ticks of
feeding first, duo ammo 24): `run_wave()` at ~tick 3210.

| sample | tick | unit count | has_player_unit | hasCore (facade) |
|---|---|---|---|---|
| 1 | 3813 | 2 | true | true |
| 2 | 4413 | 2 | true | true |
| 3 | 5013 | 1 | true | true |
| 4 | 5613 | 1 | true | true |
| 5 | 6213 | 1 | true | true |

Wave-1 acceptance: the enemy is gone ~1800 ticks after `run_wave()` (well
within 6000), the player is alive, and nothing attacked the core during the
wave. Run 2 (screenshots, fresh resume): wave-1 dagger gone by +3000 ticks,
`building_team_at(129,55) == 1` (core intact), `has_player_unit() == true`,
`player_unit_pos [1036,444]`. Screenshots: `wave1.png` (Ground Zero, paused,
drill-fed duo staged), `wave1-cleared.png` (after the launch), `wave1-core.png`
(camera over the mining site). The screenshots were taken while the harness
frame loop was stalled (see Blockers), so they show the last rendered frame.

Respawn (PAR-0174): `debug_apply_status(1000000000, "melting", 2000)` ->
`step(500)` -> old alpha gone, **new alpha id 1000000002** at the core
(1036,444), health 150, no statuses, `has_player_unit() == true`.

Wave 2 (recorded evidence, not an H00 gate): `run_wave()` once more spawned
1 dagger + 2 flares; by +3000 ticks 2 enemies were still alive (the duo killed
what it could); by ~+6000 ticks the surviving flare had destroyed the duo,
the drill, the copper wall and the core (build count 49 -> 45), killed the
alpha, and no respawn followed (no core — matches Java `PlayerComp.update`
needing a live core). Owner trail per the plan: air defence / turret lead
(H02 T16) and FlyingAI targeting (H01); `hasCore` in `get_hud_state()` went
stale only because of the stalled frame loop, the sim itself showed the
affected tiles as air.

## Deviations from Java

1. `Nulls.unit` citation (T2): the plan cites `J/entities/Nulls.java`; the
   pinned Java checkout has no `Nulls.java` (`core/src/mindustry`,
   `core/build/generated` and the Arc tree all checked). The operative Java
   guard is `BuilderComp.java:277-278` (`if(!canBuild()) return;`) with
   `canBuild()` at `BuilderComp.java:40-42`; the port guard uses exactly that.
2. Core-less dev worlds keep the port's instant `player: Some` placement
   (no Java counterpart; spine/determinism scenarios). Documented in code on
   `Sim::team_has_core` (`core/sim/builder.rs`).
3. T2b resume clamp `session.wave = record.wave.max(1)` — Java never writes 0,
   but port-native saves could hold it (`GameState.java:17` cited in code).
4. No gameplay deviations introduced by T3; the wave-2 outcome is a pre-existing
   port gap (turret lead/air defence), not an H00 change.

## Blockers / harness notes

* **Frame-loop stalls**: a `godot_exec` eval that exceeds the 15 s budget
  (e.g. a 10x `step(600)` loop) can leave the Godot frame loop stalled —
  `$H.is_paused()` reads false but the tick no longer advances and the
  `MindCampaign` facade mirror (HUD `enemies`/`isSpawning`/`hasCore`) freezes.
  `step()` evals remain authoritative. Recover with
  `tools/session-play.sh 1 --play` (used twice). Not a code bug; recorded so
  later sessions interpret facade reads correctly after a timeout.
* `enemies` counter itself is fine: a temporary headless test (added, run,
  reverted — not committed) showed `session.enemies` dropping to 0 after the
  wave units died; the in-engine "stuck" reading was the stalled mirror.

## Ledger changes to apply (coordinator; expand of plan §4)

| Item | Change |
|---|---|
| PAR-0174 | **verified** (T1 commit + T3): env 233 on Ground Zero resume, alpha spawns, and respawn proven (melting kill -> new alpha 1000000002 at the core). Evidence: `runs/20261014-s1-H00-T1/gz-alpha.png`, T3 samples above. |
| PAR-0215 | **verified**: T2 tests + in-engine queued plan (progress 0.278 at (135,58), completes to block 216 team 1). Evidence: `runs/20261014-s1-H00-T2/plan-queued.png`. |
| PAR-0189 | **verified**: T2 in-engine step shows the queued ghost (`player_build_plans_json` non-empty, `construct_progress` 0.278). |
| PAR-0052 | re-verified note: alpha spawns on resume (T1 screenshot; log "spawn_player_unit: core unit team 1 spawned"). |
| new | "Planet `Env` bits used enum order: Serpulo rules.env 31 (Java 233), Erekir 33 (Java 17), Tantros 65 (Java 5); player never spawned" -> **verified** (T1). |
| note (no new id) | T3 wave 2: a single flare destroyed the drill-fed duo + core and the player (no turret lead / air defence) — forward to H01 (FlyingAI) / H02 T16 (turret lead) as recorded evidence. |

## Baseline after H00

* `cargo test -p mind-core --lib --features msav-import`: **2211 passed / 0 failed / 4 ignored**.
* `cargo test -p mind-headless --lib`: **132 passed / 0 failed**.
* `cargo test -p mind-gdext --lib`: **34 passed / 0 failed**.
* `cargo run -q -p mind-headless -- parity goldens`: **97 PASS / 0 FAIL**.
* `cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings`: clean; `cargo fmt --check`: exit 0.
* `tools/build.sh`: `Finished \`dev\` profile` + `sync_scenarios: synced 11 file(s)`.
* GDScript parse gate: clean (no output).
* `cargo test -p mind-headless --test fx_golden`: still fails only on
  `fx_scenarios_match_committed_goldens` / `fx_program_explosion` (the known
  1-ULP y2 case owned by H03 T1); `fx_audit_and_smoke_pass` passes. Everyone
  else can ignore it per H-environment §2.
* Marker commit `H00: blockers fixed (Env bits, player plans); baseline for
  round H` is on `main` (`4fbfcf54`).
