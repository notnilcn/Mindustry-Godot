# G07 — audio + weather — session 3 summary

Executor: DeepSeek V4.1 Flash (session 3), worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session3`,
branch `parity/session-3`, base `main` @ `ef54dfa`.

## Per-task status

| Task | Status | Commit | Notes |
|---|---|---|---|
| T1 audio pump/assets/music/settings (PAR-0074) | done | `3e5f829` | 4/4 acceptance checks in-engine; decision gate: pump already dispatched (no fallback) |
| T2 weapon+ turret shoot/charge sounds | done | `95d015b` | 3 new tests; events_sim golden regenerated; in-engine 74->99 events, duo fired |
| T3 place/break/destroy/rotate sounds (PAR-0073) | done | `7987623` | 7 new tests; in-engine +1 event per construct/deconstruct finish |
| T4 loop voices (PAR-0071 p1) | done | `84c6c29` | LoopVoicePool + per-frame mixer; poller fixes; in-engine hold loop [1, 0.0998] -> 0 |
| T5 building ambient loops (PAR-0071 p2) | done | `a8d03e6e` | ambient.rs table + gates; in-engine drill loop 0.019 -> falloff 0.001; ambientvol store was 10 (restored 100) |
| T6 per-frame loop sources | done | `f39c27b1` | frame.rs sources + turret loops; in-engine flare move loop 0.199; build-beam half blocked (no player unit) |
| T7 in-game music context (PAR-0072) | done | `cf50da16` | rules/wave/boss/reset mirror + waveSpawn/landing; in-engine wave 0->1, land_playing true |
| T8 voice policy | not reached | — | budget; changes scoped in summary |
| T9 weather sim + seams (PAR-0127) | done | `55643d5e` | wind force + GeneratorEnv + weather_json/debug_create_weather; in-engine rain->wet, despawn; sandstorm displacement blocked by G01 kinematic mover |
| T10/T10b weather rendering | not reached | — | large gdext render pass; budget |
| T11 addWeather fresh sectors | not reached | — | budget |
| T12 mech steps | not reached | — | budget (optional in plan) |
| T13 UI sounds | done | `26cc8e5e` | signal listener + button/dialog/toast/unlock hooks; in-engine voice readbacks |
| T14 payload/configure sounds | done | `06e72c76` | sim emitters + play_at_ui; payload half headless only, configure structural |

## git log main..HEAD

`3e5f829` Fixes PAR-0074: MindAudio loads assets/settings and pumps every frame
`95d015b` Gameplay G07 T2: unit weapon and turret shoot/charge sounds reach the client
`7987623` Fixes PAR-0073: live place/break/destroy/rotate block sounds
`84c6c29` PAR-0071: loop voices play (LoopOutput + per-frame LoopMixer::update, ambient poller fixes)
`a8d03e6e` Fixes PAR-0071: building ambient loops (drills, conveyors, crafters, generators)
`f39c27b1` Gameplay G07 T6: build/mine/fire/unit/weather/turret loop sounds
`cf50da16` PAR-0072: in-game music context (rules, wave, boss, reset) + waveSpawn/landing audio
`55643d5e` Fixes PAR-0127: weather wind force, envAttrs, weather seams + in-engine check
`26cc8e5e` Gameplay G07 T13: UI sounds (button click, dialog back, notify, unlock)
`06e72c76` Gameplay G07 T14: payload pickup/drop and block configure sounds

## T1 — Fixes PAR-0074 (commit 3e5f829)

Changed: `gdext/audio/mod.rs` (loader asset root + dir log, `frames` counter +
deferred `set_process(true)`, `refresh_settings` from `/root/MindUi` every 30
frames, listener width `/zoom`, UI-bus routing via `StreamCache::file_of`,
pause mirror + `dialog_stack` lowpass, `is_menu` via MenuBackground),
`gdext/audio/streams.rs` (music normalize once + `file_of`, per-call loop flag
on the decoded stream), `ui/dialogs/settings_menu_dialog.gd`
(`/root/MindUi` -> `/root/Spine/MindAudio`).

Tests: `cargo test -p mind-core --lib audio` 48 passed; clippy clean; parse gate clean.

In-engine evidence `runs/20261013-s3-G07-T1/evidence.json`:
- `[audio] ready (buses ..., 207 sounds, dir .../client/../assets)`.
- Decision gate: `stats()["frames"]` 667 -> 948 over 2 s -> `MindAudio::process`
  IS dispatched in the editor; the `drive_frame` fallback was not applied
  (deferred `set_process(true)` kept per plan).
- `settings_set("sfxvol", 30)` -> `stats()["sfxvol"] == 30`, still 30 after a
  `--play` restart.
- Ground Zero + alwaysmusic: `current_track()` "game3", playing true,
  `drain_log()` empty.

Deviation/observation: in this editor run `res://assets/sounds.index.json` is
absent but `res://../assets/sounds.index.json` resolves, so the old local probe
already loaded the 207-sound index and one-shots played; the audible failures
were music decode (normalize) + unread settings. The loader path + dir logging
is kept per plan. (Pre-check evidence recorded before any edit.)

## T2 — Gameplay G07 T2 (commit 95d015b)

Changed: `core/audio/sim.rs` (`emit_weapon_sound`), `core/weapons/mod.rs`
(charge at muzzle + per-bullet shoot sound through the audio sink),
`core/world/blocks/defense/turrets/mod.rs` (TurretConfig sound fields +
TURRET_SOUNDS table + apply in `config_for`; `shoot()` charge + per-bullet
sound with the Java fallback rule; Fx-stream pitches),
`advanced.rs` (segment intercept sound).

Tests: 3 new (`turret_sound_table_matches_blocks_java`,
`hail_shot_emits_its_own_sound`, `dagger_shot_emits_default_shoot_sound`).
Full gates: mind-core `--features msav-import` 2084/0/4ignored; mind-headless
--lib 132/0; clippy/fmt/parse clean.

Golden: `audio/events_sim.json` regenerated (duo pitch random;
`Turret.java:804`), sha256 updated in `parity/golden_manifest.json`.

In-engine evidence `runs/20261013-s3-G07-T2/evidence.json`: Ground Zero, duo at
(150,53) + team-2 dagger at (1200,420): `events_applied` 74 -> 99 over 180
ticks, duo ammo 10 -> 0 (fired), `drain_log()` empty, 0 panics. LMB player
shooting produced no events (G08-owned input), fallback fixture used.

Deviations: PointDefense sound follows Java (after both damage/remove
branches), not the plan's "lethal branch" wording. Dev note: the env §4.1
Ground Zero drill/duo at (130,48)/(132,48) was absent in the imported save
(`building_debug` `{}`), so the fixture was placed via `place_block`.

## T3–T14 — per-task digest

- **T3** (`7987623`): `BlockBrokenEvent.destroyed`, `AudioEvent::Construct`,
  `core/audio/blocks.rs` (place/break/destroy tables incl. StaticProp family),
  flush_events place/break, `emit_building_destroyed` (extras + CoreBlock
  game-over Play), Rotate sound, gdext Construct handler (shouldPlay 32 ms +
  calcPitch). 7 new tests. In-engine: +1 event per construct/deconstruct
  finish (4->5->6->7); 0 panics.
- **T4** (`84c6c29`): `AmbientPoller::do_loop` sums-after-pass + persists
  between polls, `LoopVoicePool`, `GodotLoopOutput`, per-frame mixer update.
  In-engine: hold loop [1, 0.0998] -> 0 after fade; alloc-audit steady-state
  passes.
- **T5** (`a8d03e6e`): `core/audio/ambient.rs` (Blocks.java table + class
  defaults + gates/scales), sim_host `ambient_snapshot`, 20 Hz poll wired.
  In-engine: drill loop 0.019, falloff 0.00097 with the drill still efficient;
  session store `ambientvol` was 10 (restored to 100).
- **T6** (`f39c27b1`): `core/audio/frame.rs` (builder/miner/unit/tank/fire/
  weather/tractor + turret SoundLoop inputs), sim_host seams, gdext
  accumulation + `IndexMap<u64, SoundLoopState>` with voice lifecycle.
  In-engine: flare move loop (loopThruster 0.199). Build-beam half blocked: no
  player unit in the session (`spawn_player_unit: no supported core`), so
  `player:0` places bypass the queue; weather half waits on T9 (now landed).
- **T7** (`cf50da16`): `AudioGameState`/`read_game_state`, music_context fills
  rules/wave/boss/core-hp, ResetEvent mirror, WaveEvent -> waveSpawn +
  on_wave_event, `land_player`/`play_landing`/`music_debug`, campaign.rs
  landing calls. In-engine: wave 0->1 with voice 1 + due ms; land_playing true
  on fresh sector 98.
- **T9** (`55643d5e`): particle wind force, `GeneratorEnv` insertion,
  `weather_json`/`debug_create_weather`, `unit_debug_json` statuses+vel.
  In-engine: entries [] on GZ, rain -> wet, despawn, clean log. Deviation:
  sandstorm displacement not observable (ground mover overwrites Vel —
  `ai/types/ground.rs:79-86`; movement-model G01 finding).
- **T13** (`26cc8e5e`): UI signal listener (`on_ui_sound`/`_ex`) + button hook
  + dialog back + toast notify + research unlock. In-engine: play_ui_sound ->
  voice 1; close_dialog -> uiBack voice 1; button pressed hook -> voice 1.
  Deviation: synthetic GUI mouse click did not reach the control (input layer).
- **T14** (`06e72c76`): payload pickup/drop emitters + `play_at_ui` configure
  sound. Payload half headless only (no payload unit in Ground Zero);
  play_at_ui -> voice 1 structurally.

## Not reached (with reasons)

- **T8 voice policy** (VoicePool per-slot metadata + `active_voices`/
  `play_world_at`/`set_voice_volume`, play_state admission + checkFrame
  intensify in `play_sound`, falloff offset from the priority table): not
  started — session budget ran out after 10 tasks. Nothing is half-done; the
  policy tables are already unit-tested in `core/audio/priority.rs`; only the
  gdext wiring remains.
- **T10/T10b weather rendering** (`WeatherRenderer` on the Weather/Debris
  bands, corrected `weather_fx` RNG sequences, noise layers): not started —
  largest remaining item (new gdext render pass + FX builder rewrite), needs a
  fresh budget. The T9 seams it depends on are landed
  (`debug_create_weather`, `weather_json`).
- **T11 addWeather**: not started (medium; fresh-sector call site + stop rule).
- **T12 mech step sounds**: not started (plan's optional/lowest priority item).

## Cross-area findings for the coordinator

1. Ground movement is kinematic (`ai/types/ground.rs:79-86` sets `vel` and
   integrates `pos` in one step), so external `Vel` contributions (weather
   wind, partial knockback) are discarded — this is why T9's sandstorm
   displacement check cannot pass; G01 territory.
2. `SimHost.spawn_player_unit` fails on Ground Zero ("no supported core in the
   loaded sector"), so campaign sectors start with zero live units; player
   build/shoot/payload paths (`player:0`, LMB, payload carriers) are untestable
   in-engine. Blocks T6's build-beam half, T14's payload half, G08's input
   acceptance.
3. Synthetic bridge GUI clicks did not reach Controls (T13); world mouse
   events work. Input-layer follow-up for G08.
4. `cargo test -p mind-headless --test fx_golden` fails on `main` (1-ULP
   `fx_program_explosion` y2; verified pre-existing with T2 stashed);
   `parity goldens` passes (hash-only). Not touched.

## Ledger changes to apply (coordinator)

- PAR-0074 -> verified (T1: frames counter + settings mirror + persisted
  slider + playing track; asset-root observation recorded).
- PAR-0073 -> verified (T3: construct/break +1 event per finish; destroy
  unit-tested incl. CoreBlock game-over Play).
- PAR-0071 -> verified for the loop plumbing + building ambients (T4/T5
  in-engine evidence); the per-frame loop sources (T6) are in-engine verified
  for unit move loops, build-beam/weather halves blocked as above.
- PAR-0072 -> verified in-game half (T1/T7: assets dir, music decode + loop
  flag, is_menu from MenuBackground, rules/wave/boss context, ResetEvent
  mirror, waveSpawn + landing); menu half (planet launchMusic, editor) still
  needs its own pass; WIP branch `agent/par0072-menu-music` superseded for the
  listed parts.
- PAR-0127 -> verified weather sim half (T9: forced rain in-engine, status
  applied, entity despawns, weather_json readbacks; screenshots are T10's, not
  reached). Note: "Ground Zero's imported save names `snow` (unresolvable
  content name; Java drops it too) — no natural weather on GZ in either
  client".
- New items to file per plan §4: unit weapons silent (fixed T2); most turrets
  no shoot sound (fixed T2); weather attributes never reaching generators
  (fixed T9); sandstorm/sporestorm wind force (implemented T9; displacement
  blocked by the movement model — cross-link G01); fresh-sector addWeather
  (T11 not reached); UI sounds unconnected (fixed T13); payload/configure
  sounds (fixed T14).
