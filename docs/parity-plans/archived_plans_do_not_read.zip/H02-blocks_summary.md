<!-- SPDX-License-Identifier: GPL-3.0-only -->
# H02 (blocks) — session 4 summary (written 2026-10-14, parity/session-4)

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session4` (session 4,
bridge 7000, display :13). Started from main @ `4fbfcf54` (H00 marker); merged
`main` once more at the end (`22ea48c1`, chains.json only, no wave-1 commits had
landed). `git merge --no-edit main` succeeded cleanly.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T1 campaign core incineration | done (in-engine verified) | `dbb2ca2b` |
| T16 turret aim/lead | done (in-engine verified; 600-tick kill not achievable with a circling flare — see below) | `be80e18a` |
| T2 sync_build_rules + validBreak | done (in-engine verified) | `dc6818e4` |
| T3 Build.validPlace + kind_rotates + preview seam | done (in-engine verified) | `4ee70402` |
| T4 core upgrade + canPlaceOn | done (in-engine verified) | `0d1d4484` |
| T8 drill boost/warmup | done headless-only (no build/restart needed) | `655c2de5` |
| T5 configure values on the wire + PAR-0190 + bridge hang | not reached | — |
| T6 tap-to-link (+ H06 seam) | not reached | — |
| T7 force projector | not reached | — |
| T9 overdrive canOverdrive | not reached | — |
| T10 liquids current-liquid | not reached | — |
| T11 unitOn (shock mines/conveyors) | not reached | — |
| T12 surge/phase walls | not reached | — |
| T13 save bodies (RepairTurret/cargo) | not reached | — |
| T14 verification tests | not reached | — |
| T15 beam node | not reached | — |

## `git log --oneline main..HEAD`

```
655c2de5 Gameplay H02 T8: drills use per-block liquid boost and warmup speed
5eeccc71 Merge branch 'main' into parity/session-4
0d1d4484 Gameplay H02 T4: core upgrade placement keeps items; core canPlaceOn
4ee70402 Gameplay H02 T3: Build.validPlace team, water, rotation, visibility, core radius; kind_rotates
dc6818e4 Gameplay H02 T2: sync_build_rules, validBreak team and core rules
be80e18a Gameplay H02 T16: turrets re-aim every tick and lead targets (Turret.targetPosition, Predict.intercept)
dbb2ca2b Gameplay H02 T1: campaign cores incinerate overflow; core hooks read rules
```

## Exact test commands and results (final state, after T8)

```bash
cd WT/client/rust; L="CARGO_BUILD_JOBS=6 flock -w 900 /tmp/opencode/mg-build.lock"
$L cargo test -p mind-core --lib --features msav-import   # 2234 passed / 0 failed / 4 ignored
$L cargo test -p mind-headless --lib                      # 132 passed / 0 failed
$L cargo test -p mind-gdext --lib                         # 34 passed / 0 failed
$L cargo run -q -p mind-headless -- parity goldens        # 97 PASS (none regenerated)
$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings   # clean
cargo fmt -p mind-core -p mind-gdext -p mind-headless     # clean (units_scenarios.rs drift reverted, not mine)
```
Targeted per task (all pass): `core_incinerat`/`core_rejects_when_not_incinerating`/`core_capacity_unifies`
(T1); five `turret_*`/`scathe_does_not_predict` (T16); `sync_build_rules_copies_rules`/
`cannot_break_enemy_building`/`last_core_unbreakable` (T2); `cannot_replace_enemy_conveyor`/
`cannot_build_on_deep_water`/`same_block_same_rotation_rejected`/`derelict_same_block_repair`/
`enemy_core_radius_blocks_placement`/`banned_block_rejected_for_player_only`/`kind_rotates_matches_java` (T3);
`core_upgrade_*`/`core_needs_existing_core` (T4); `blast_drill_boost_knobs_match_java`/
`drill_warmup_scales_with_time_scale` (T8).
GDScript parse gate: no `.gd`/`.tscn` edits this session.

## In-engine evidence (Ground Zero sector 170; panic count 0 after every step)

All runs under `REPO/runs/` (symlink; never staged):

* **T1** `runs/20261014-s4-H02-T1/` (`t1-core-incinerates.png`, `evidence.json`):
  core seeded 4000 copper; conveyor(131,55,rot 2) fed by item-source(132,55):
  after 300 and 600 ticks `core_items_json` = `{"copper":4000}` and
  `building_items_json(131,55)` = `{"copper":2}` (pre-fix jam was `{"copper":3}`);
  source switched to lead → `{"copper":4000,"lead":23}` (overflow incinerated,
  lead flows). `rules.coreIncinerates` = true.
* **T16** `runs/20261014-s4-H02-T16/` (`t16-drill-duo-flare.png`, `evidence.json`):
  drill(130,48)→duo(132,48) loaded to 20 rounds; team-2 flare spawned at
  (1176,384) was killed after ~1800 ticks of circling flight with ~30 rounds
  total. The plan's "dead within 600 ticks on a straight line" was not
  stageable from the bridge (no AI/velocity seam; H01 T15 not on main); the
  straight-line lead is pinned exactly by `turret_leads_moving_target`.
* **T2** `runs/20261014-s4-H02-T2/evidence.json`: `"player":0` break of the
  last core (129,55) → plan list `[]`, tile stays `core-shard`, `hasCore` true;
  derelict scrap-wall (169,167, team 0) break → plan
  `[{"x":169,"y":167,"breaking":true,...}]`; staged team-2 copper-wall (140,66)
  break → no new plan.
* **T3** `runs/20261014-s4-H02-T3/` (`t3-validplace.png`, `evidence.json`):
  `valid_place_preview(145,60,copper-wall)`=true; conveyor(146,60) placed,
  preview same rot 0=false, rot 1=true; core tile=false; staged team-2
  conveyor(140,66) → `titanium-conveyor` preview=false (pre-fix true); API
  `place_block(138,62,"power-source")`=true (sandbox recipe intact) while
  `valid_place_preview(144,60,"power-source")`=false (visibility gate).
* **T4** `runs/20261014-s4-H02-T4/` (`t4-core-upgrade.png`, `evidence.json`):
  core seeded 4000/4000/4000; `player:0` foundation(340) on free ground
  (140,60) → no plan; same plan over the shard (129,55) → after step(300) tile
  `core-foundation`, `core_items_json` = `{"copper":1000,"lead":1000,
  "silicon":2000}`, plan list `[]` (instant upgrade, items minus cost).
* **T8**: headless-only by plan design (two unit tests above).

## Deviations from Java (explicit)

* T3: `environmentBuildable()` (per-planet block lists, `Block.java:1117-1119`)
  treated as true — the runtime registry has no planet block list (plan D3).
* T3: `requiresWater` treated false (`BlockDef` has no field; no Serpulo block
  sets it, `grep "requiresWater = true" J/content/Blocks.java` → Erekir pumps).
* T3: `Block.ignoreBuildDarkness` and `Block.placeOverlapRange` are not
  `BlockDef` fields; darkness/`placeOverlapRange = 50` default are applied
  unconditionally (`Block.java` defaults).
* T3: fog footprint check (`staticFog && fog && !isDiscovered`) left out
  (plan D1, H03/H04 own fog discovery).
* T3: `BuildVisibility::CoreZoneOnly` uses a grid scan for the `core-zone`
  floor (`Blocks.java:587`) instead of `BlockIndexer.isBlockPresent`; the
  `!state.isGame()` half of the Java condition is not modelled.
* T4: `requiresCoreZone` treated false (no Erekir cores in the port;
  `Blocks.java:3198,3218,3236` never sets it for Serpulo).
* T4: `PlaceFlags::API` (dev/test staging) skips `canPlaceOn` like it skips
  visibility/core-radius; the player form (`PlaceFlags::PLAYER`) matches Java
  exactly. This keeps the MCP/test staging seams usable (Java's editor escape
  is `state.isEditor()`, `CoreBlock.java:189`).
* T4: `Rules.blockLimits` is per-block upstream (`Rules.java:187`); the port's
  `BuildRules.block_limits` is (team, block)-keyed, so `sync_build_rules`
  files positive limits under the default team (`Block.java:1044-1048`).
* T6-provided seam note: `T3` AI caller `BaseBuildInput`
  (`core/ai/base_builder_ai.rs:414`) has no `&World`, so it keeps the
  `valid_place` wrapper (no visibility/core-radius); H01 should revisit if the
  input grows a world (plan §6).
* `assets/parity/region_names.txt` shows a 20-line pack-output diff in
  `git status` (wreck regions) caused by `tools/pack.sh`; left unstaged (not a
  client/parity/tools path).

## Blockers / notes for the next session

* T5/T6 (the H06/H08 seams `config_tap`, `SimCommand::ConfigTap`,
  `MindInput.close_block_config`, `preview_config_tap`, wire `Point2`/
  `Point2Array`/`ContentId`) were not reached; H06/H08 must either define them
  with the H-INDEX §3 names or wait for a re-run. `valid_place_preview` and
  `Sim::valid_place_player` DID land (T3) and are ready to consume.
* T7/T9/T10 (golden-affecting: force-projector consumers, `canOverdrive`,
  `LiquidModule.current_liquid`) not reached; expect `parity/golden_content.json`
  regeneration when they run.
* T16's in-engine acceptance ("flare dead within 600 ticks") needs H01 T15's
  unit velocity/NoAi seam or a straight-line staging seam; the intercept math is
  covered by tests.
* The test helpers `sim_with_player()` (builder.rs, audio/frame.rs,
  ai/types/player.rs) now sync `BuildRules.default_team = 1` like a campaign
  load; the sorter test was restaged (its 3x3 vaults overlapped) and two
  `sim/tests.rs` cases stage `coreZoneOnly` cores through the API form.

## Ledger changes to apply (do not edit chains.json here; plan §4 expanded)

| Item | Change |
|---|---|
| PAR-0190 | unchanged this session (T5 not reached). |
| PAR-0188 | unchanged (T5 not reached). |
| PAR-0129 | unchanged (T7 not reached). |
| PAR-0098 | T2/T3/T4 landed as a slice: `sync_build_rules` + `validBreak` team/core rules + full `validPlace` + core upgrade + `valid_place_preview`. Status stays per the remaining H03/H08 halves; note the slice. |
| PAR-0244 | unchanged (T6 not reached). |
| PAR-0220 | unchanged (T6 not reached). |
| PAR-0209 | no change (H08). |
| New | "Campaign cores never incinerate overflow: belts into a full core back up" → **fixed** by T1 (`dbb2ca2b`), in-engine verified. |
| New | "Turrets aim at stale positions and never lead moving targets" → **fixed** by T16 (`be80e18a`); the plan's H00 T3 metric (25 ammo / ~4 hits) improved to a kill in ~30 rounds. |
| New | "Placement guard ignores team, deep water, same-block rotation, derelict repair, core radius, visibility, sector bans; validBreak allows enemy buildings and the last core" → **fixed** by T2+T3, in-engine verified. |
| New | "Cores cannot be upgraded; core-foundation placeable on free ground" → **fixed** by T4, in-engine verified. |
| New | "Drill liquid boost/warmup ignore per-block values" → **fixed** by T8 (headless-only). |

---

# Pass 2 (session 2, parity/session-2, 2026-10-15)

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session2` (session 2,
bridge 6980, display :11). Started from main @ `2219e2e0` (`git merge --ff-only`),
merged `main` again at the end (`e2aa272b`, clean; H01 pass-2 T4/T5 velocity model
and H07 wave 3 T1-T12 landed). Commit order: H01-T1-residual conversion, T5, T6.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T5 configure values on the wire + PAR-0190 + bridge hang | done (in-engine verified; hang not reproduced) | `3e46e8ca` |
| T6 tap-to-link + H06/H08 seam | done (in-engine verified; player-chain in-engine half blocked by H01 builder) | `e2f58037` |
| H01 T1 residual (H02 call sites) | done (prep; nodes/explosion/payload) | `88795ae0` |
| T7 force projector | not reached | — |
| T10 liquids current-liquid | not reached | — |
| T9 overdrive canOverdrive | not reached | — |
| T11 unitOn | not reached | — |
| T12 wall reactions | not reached | — |
| T13 save bodies | not reached | — |
| T14 verification tests | not reached | — |
| T15 beam node | not reached | — |

## `git log --oneline main..HEAD`

```
e2aa272b Merge branch 'main' into parity/session-2
e2f58037 Gameplay H02 T6: tap-to-link for bridges, conduits, drivers and nodes; liquid bridge config and IO
3e46e8ca PAR-0190: configure values keep their type over the wire; bridge link hang
88795ae0 Fixes H01 T1 residual: H02 call sites use the tile*8+offset building centre
```

## Exact test commands and results (after the final `git merge main`)

```bash
cd WT/client/rust; L="CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock"
$L cargo test -p mind-core --lib --features msav-import   # 2422 passed / 0 failed / 4 ignored
$L cargo test -p mind-headless --lib                      # 133 passed / 0 failed
$L cargo test -p mind-gdext --lib                         # 40 passed / 0 failed
$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings   # clean
$L cargo run -q -p mind-headless -- parity goldens        # 97 PASS / 0 FAIL (none regenerated)
bash tools/godot.sh --headless --editor --quit --path client | grep -E "SCRIPT ERROR|Parse Error"  # nothing (after the .gd edit)
grep -nE '///.*\S\s{2,}#\[' client/rust/mind-gdext/src/sim_host.rs       # nothing
```

New tests: `config_wire_point2_roundtrip`, `config_wire_content_id_roundtrip`,
`to_sim_config_keeps_relative_point`, `to_sim_config_number_integral_is_int`,
`to_sim_config_carries_content_id`, `configure_reaches_sorter_door_switch`,
`bridge_configure_int_absolute_links_and_ticks`, `bridge_configure_point_relative`,
`node_configure_point_array` (T5); `config_tap` suite (bridge link/unlink,
reverse tap, out-of-range, liquid bridge, sorter double tap, mass driver self,
node autolink+clear, default semantics), `sim_config_tap_command_applies`,
`player_bridge_chaining_links_and_skips_proximity`,
`liquid_bridge_body_matches_java` (T6). `ConfigTap` also joined the codec
round-trip tables.

## In-engine evidence (Ground Zero 170; panic count 0 after every step)

* **T5** `runs/20261014-s2-H02-T5/` (`t5-bridge-int-linked.png`,
  `t5-door-sorter.png`, `evidence.json`): `int 9371716` links (140,68)->(143,68)
  (`{"type":"point","x":3,"y":0}`); `int -1` reads `{"x":-141,"y":-69}`;
  `point 3,0` re-links; `number 9371716` links; door `bool true` reads `true`;
  sorter `item copper` reads `{"type":"item","id":0}`. Paused, one call per eval
  (`configure -> pending 1 -> step(1) -> read -> step(60)`); no stage stalled.
* **T6** `runs/20261015-s2-H02-T6/` (`t6-link-panel-open.png`,
  `t6-tapped-links.png`, `evidence.json`): real `godot_input` taps. Tap A opens
  the link panel (`config_selected_json` `[140,70]`, no item list); tap B links
  (`{"x":0,"y":3}`); tap B again unlinks. Reverse case: with C's panel open,
  tapping the bridge A that links C applies both configs and switches the panel
  (`{"x":-3,"y":0}` on C, `{"x":-138,"y":-71}` on A, selection `[137,70]`).
  Bridge-conduits link by tap. Node -> battery: self-tap clears (graphs 2/3),
  tapping the battery re-links (both graph 2), panel stays.

## Deviations from Java (explicit)

* T5: `ConfigValue`'s serde switched from internal to adjacent tagging —
  internal tagging cannot represent tuple variants and already failed at
  runtime for primitive newtypes; the binary codec
  (`encode_config`/`decode_config`) is the wire format and nothing serializes
  `ConfigValue` (grepped). Wire tags 7-9 are append-only.
* T5: the G03 bridge-configure hang was **not reproduced** (root cause not
  found; matches session 3). A defensive guard was added for
  `transportTime == 0` on the non-buffered bridge path only. The render-side
  `bridge_links` guard (plan T5 step 5) was not needed and was not added.
* T6: Java computes `onConfigureBuildTapped` client-side and sends `configure`;
  the port's input layer holds no rules, so the sim computes the tap
  (`SimCommand::ConfigTap`) and `preview_config_tap` mirrors the outcome for
  the panel decision (plan-endorsed).
* T6: on `Switch` with a non-configurable/non-interactable target the port
  consumes the tap and hides the panels (Java `config.hideConfig()`,
  `InputHandler.java:1998-2001`); for `SwitchBlock` the panel closes and the tap
  toggles through the normal switch branch (Java keeps the old panel visible
  through `BlockConfigFragment.showConfig` + `SwitchBlock.java:58-62`
  `configTapped`, `BlockConfigFragment.java:41`).
* T6: the player-built chaining in-engine check did not progress (queued
  `"player":0` bridge-conduit plans at (144,70)/(144,73) stayed at progress 0
  for 800 ticks with three alphas nearby - `stuck` flags; H01 builder/player
  unit territory). The chaining logic is pinned headlessly
  (`player_bridge_chaining_links_and_skips_proximity` covers link, proximity
  guard and the liquid bridge).
* H01-T1-residual: `BuildHarness::tile_center` (`world/harness.rs:614`, a
  generic "somewhere in this tile" spawn helper) was left as-is; the task named
  only the power-node hitbox, reactor explosion and payload placement.

## Blockers / notes for the next session

* The H06 T15 / H08 T4 seam is now on `parity/session-2`: trait
  `on_configure_build_tapped`, `world::config_tap::config_tap`,
  `SimCommand::ConfigTap` (tag 16), `Sim::last_config_tap`,
  `MindSimHost::preview_config_tap`, `MindInput::close_block_config`,
  `DesktopBridge.config_selected`. The logic-block arm of
  `on_configure_build_tapped` remains H06 T15's.
* T6's `config_spec` link spec + `DesktopBridge.config_selected` are the node
  H08 T14 will move into the HUD group; `MindInput` has two path constants to
  update then (`BLOCK_CONFIG_PATH`, `BLOCK_INVENTORY_PATH`).
* T7/T9/T10 (golden-affecting: force-projector consumers, `canOverdrive`,
  `LiquidModule.current_liquid`) remain; expect `parity/golden_content.json`
  regeneration when they run. T7's coolant should use T10's
  `current_liquid()` once it lands.
* T11/T12 touch H01's files (`unit/environment.rs`, `combat/bullet/mod.rs`);
  H01 pass 2 (velocity) is on main now, keep hunks small.

## Ledger changes to apply (do not edit chains.json here; plan §4 expanded)

| Item | Change |
|---|---|
| PAR-0190 | T5 landed: wire keeps config types; sorter/door/switch/bridge/node configs proven (headless + in-engine). The sorter sprite still does not draw its item icon -> render invalidation stays H03; keep `fixing` assigned to H03. |
| PAR-0188 | No H02 change; T5 evidence: config JSON changed while the sorter sprite did not. |
| PAR-0244 | T5/T6 unblock the bridge half: links can be staged by tap or `"point"` configure. Note for H03. |
| PAR-0220 | T6 provides `on_configure_build_tapped` + `world::config_tap::config_tap` + `SimCommand::ConfigTap` -> "unblocked for H06"; the LogicBlock arm is H06 T15's. |
| PAR-0098 | T5/T6 don't change it; slice note stands (T2/T3/T4 from pass 1). |
| PAR-0129 | unchanged (T7 not reached). |
| PAR-0209 | no change (H08). |
| New | "Bridges/nodes/drivers cannot be linked by tapping; bridge conduits cannot be linked or saved" -> **fixed** by T6 (`e2f58037`), in-engine + headless. |
| New | "Configure values are mangled or rejected over the wire (relative Point2 as absolute, content as 'complex', Number narrowed to f32)" -> **fixed** by T5 (`3e46e8ca`). |
| New | "H02 call sites still used the half-tile building centre (power node hitbox/overlap, reactor explosion, payload tile placement)" -> **fixed** by `88795ae0` (H01 T1 residual). |
| New | "Player-built bridge chaining never runs for bridge conduits / lacks the proximity guard" -> **fixed** by T6 (headless test; in-engine plan-progress half blocked by the H01 builder). |

---

# Pass 3 (session 2, from T7)

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session2` (session 2,
bridge 6980, display :11). Started from main @ `a093a1b2` (pass-2 merge already in
the branch); merged `main` again twice: mid-pass for the T5/T6-era pickups, then at
the end (`11b6cdda`, clean) for H01 pass 3 + H09 pass 2
(`f4333ff5`/`bc01447f`, 14 commits). Commit order: T7, T10, T9, T11.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T7 force projector (PAR-0129 sim half) | done (in-engine verified; golden regenerated) | `66031b6a` |
| T10 liquids current-liquid + mixing reactions | done (headless; in-engine check partial, no liquid-type seam) | `55032f91` |
| T9 overdrive canOverdrive + duration rule | done headless-only (no golden change — see deviations) | `3513060a` |
| T11 unitOn (shock mines/conveyors) | done (in-engine verified) | `158b7d1d` |
| T12 wall bullet reactions | not reached | — |
| T13 save bodies (RepairTurret/cargo) | not reached | — |
| T14 verification tests | not reached | — |
| T15 beam node | not reached | — |

## `git log --oneline main..HEAD`

```
11b6cdda Merge branch 'main' into parity/session-2
158b7d1d Gameplay H02 T11: unitOn hook for shock mines and conveyors
3513060a Gameplay H02 T9: canOverdrive and the applyBoost duration rule
55032f91 Gameplay H02 T10: liquid modules track the current liquid; one liquid per conduit; mixing reactions
66031b6a PAR-0129: force projector charges with power, absorbs live bullets, phase boost and coolant
```

## Exact test commands and results (final state, after the last merge)

```bash
cd WT/client/rust; L="flock /tmp/opencode/mg-build.lock"; export CARGO_BUILD_JOBS=6
$L cargo test -p mind-core --lib --features msav-import   # 2460 passed / 0 failed / 4 ignored
$L cargo test -p mind-headless --lib                      # 133 passed / 0 failed
$L cargo test -p mind-gdext --lib                         # 40 passed / 0 failed
$L cargo run -q -p mind-headless -- parity goldens        # 97 PASS / 0 FAIL
$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings   # clean
cargo fmt -p mind-core -p mind-gdext                      # clean
grep -nE '///.*\S\s{2,}#\[' client/rust/mind-gdext/src/sim_host.rs        # nothing
```

Per-task targeted: `force_projector_*` (10 tests), `liquid` (51), `overdrive`
(4), `apply_boost_keeps_duration_for_weaker_boost`, `shock_mine*`,
`conveyor_carries_dagger` — all pass. No GDScript/.tscn edits (parse gate not
needed).

## In-engine evidence (Ground Zero 170; panic count 0 after every step)

All runs under `REPO/runs/` (symlink; never staged):

* **T7** `runs/20261015-s2-H02-pass3-t7/` (`t7-force-projector-live.png`,
  `evidence.json`): `force-projector` (140,62) + adjacent `power-source`
  (138,62), paused 120 ticks → `building_debug(140,62)` `{"efficiency": 1.0,
  "force_radscl": 0.99999917, "force_broken": false}` (PAR-0129's
  "efficiency stays 0" does NOT reproduce; kept as regression coverage).
  A team-2 dagger spawned inside the dome (1080,512) → `force_buildup` 6.0
  (live absorption). Screenshot shows the hexagon dome with a hit glow.
* **T10** optional check (no dedicated run dir): `liquid-source` (145,64) set
  to water + `conduit` (146,64): after 30 paused ticks `liquid_debug(146,64)`
  = `{"current": 6.6667, "has_any": 1}` while the source holds 19986.67.
  Reconfiguring the source to oil kept the conduit's amount falling (one-liquid
  rejection) but `liquid_debug` has no liquid-type readback, so the type-level
  acceptance/reaction checks stay headless (`conduit_refuses_second_liquid`,
  `slag_into_oil_conduit_damages`, `hot_into_cold_evaporates`).
* **T11** `runs/20261015-s2-H02-pass3-t11/` (`t11-mine-belts.png`,
  `evidence.json`): `shock-mine` (135,60): team-2 dagger on the tile went
  150 → 50 health (`unit_debug_json`) and `building_bars_json(135,60)` = 0.86
  (43/50, tileDamage paid). `titanium-conveyor` (137..140,66) rot 0 with a
  team-1 dagger at (1096,528): after 60 paused ticks x = 1137.43 (+41.4).

## Deviations from Java (explicit)

* T7: `hit -= 1f/5f * Time.delta` uses the fixed-step 1, not the building
  delta (plan text said `delta / 5`; Java is `Time.delta`, `ForceProjector.java:255`).
* T7: `buildup` is no longer clamped to 0 after `-= delta() * scale`
  (`ForceProjector.java:240` does not clamp; `broken` clears on `<= 0`).
* T7: the phase fabric consumer is `optional + booster` per `Consume.boost()`
  = `optional(true, true)` (`Consume.java:33-35`), so a projector without
  phase fabric still charges; only `phaseHeat` needs the item
  (`ForceProjector.java:207`).
* T9: `parity/golden_content.json` was regenerated and came out **byte-identical**
  (`aeff4aa1`); the parity audit does not dump `can_overdrive`, so there is no
  golden/manifest change despite the plan's note. `EmpBulletType`'s
  `canOverdrive` check stays H01's.
* T10: `current_amount` remains the total (plan wording); Java's
  `currentAmount()` is the current slot's amount — `current_liquid_amount()` is
  the exact counterpart, and `accept_liquid` uses Java's variant per node kind
  (conduit/router: `current_amount < 0.2`; bridges:
  `current_liquid_amount() < 0.2`, `ItemBridge.java:447-452`).
* T10: `first_available_liquid` (`world/update.rs:615`, the generic coolant
  optional-efficiency path) and the Erekir heat-coolant pick
  (`power/behavior.rs:856`) still take the first non-zero slot; not touched
  (out of scope) — listed for a follow-up.
* T11: Java's `unitOnAny` call (`UnitComp.java:832`) is not modelled (no
  vanilla block in scope uses it for units). The `unit_on` call site sits at
  the end of `update_unit_environment` (after the `vel` write-back) so the belt
  impulse survives; Java order is otherwise respected.
* T11: the plan's dagger spawn (164,164) is the corner between tiles because
  `WorldGrid::to_tile` rounds; the tests spawn at `tile * 8`.

## Blockers / notes for the next session

* T12/T13/T14/T15 not reached; T13 needs the cargo loader's deferred
  `readUnitId` resolution (EntitySeq lookup — Java `UnitCargoLoader.java:174-185`)
  and the assembler PayloadSeq codec.
* The merge brought H01 pass 3 (`velocity` module already in use by T11's belt
  push) and H09 pass 2 (`ItemModule::set`, static fog); my hunks in
  `unit/environment.rs`, `combat/bullet/mod.rs`-adjacent files did not overlap.
* T5/T6 seams (config_tap, ConfigTap command, close_block_config) are still on
  the branch as committed in pass 2.

## Ledger changes to apply (do not edit chains.json here; plan §4 expanded)

| Item | Change |
|---|---|
| PAR-0129 | T7 landed (`66031b6a`): powered efficiency 1.0/radscl, live bullet absorption (buildup), phase boost consume, coolant decay scale. Render half (dome draw) stays H03. |
| PAR-0190 | unchanged (pass 2). |
| PAR-0098 | unchanged (pass 1 slice stands; T9 adds `can_overdrive` to the placement-adjacent block defs). |
| PAR-0244 | unchanged (pass 2); T10's `current_liquid()` is now live for H03. |
| PAR-0220 | unchanged (pass 2 seam). |
| New | "Force projector never absorbs live bullets; phase/coolant unused" -> **fixed** by T7 (in-engine + headless). |
| New | "LiquidModule has no current liquid: conduits mix liquids, no mixing reactions" -> **fixed** by T10 (headless; in-engine type readback seam missing). |
| New | "Overdrive affects `canOverdrive = false` blocks and refreshes weaker boosts' duration" -> **fixed** by T9 (headless-only). |
| New | "Shock mines and conveyor unit transport inert" -> **fixed** by T11 (in-engine + headless). |

---

# Pass 4 (session 5, from T12) — 2026-10-15

Worktree `/home/clintonnguyen/g/code_examples/Mindustry-Godot-session5` (session 5,
bridge 7010, display :14). Started from main @ `dc106367` (already a fast-forward:
main held only the session-5 merge). Commit order: T12, T13, T14, T15 — the whole
remaining set of the plan.

## Per-task status

| Task | Status | Commit |
|---|---|---|
| T12 surge/phase wall reactions | done headless-only (plan: headless by design) | `b7b79d3c` |
| T13 save bodies (RepairTurret + cargo unload point) | done headless-only; cargo loader + assembler blocked (recorded below) | `e8e2ca2a` |
| T14 verification tests (separator, mass driver, thermal, steam, unloader, bridge) | done headless-only; three in-place fixes found by the tests | `9c4f0e80` |
| T15 beam node / beam tower | done headless-only (Erekir; plan: headless by design) | `e6e675c8` |

## `git log --oneline main..HEAD`

```
e6e675c8 Gameplay H02 T15: beam nodes link power along four directions
9c4f0e80 Gameplay H02 T14: verification tests for separator, mass driver, thermal, steam, unloader, bridge
e8e2ca2a Gameplay H02 T13: save bodies for repair turrets and cargo blocks
b7b79d3c Gameplay H02 T12: surge wall lightning and phase wall deflection
dc106367 Merge branch 'parity/session-5' into main (H03 pass 2: T18,T7,T8)
```

## Exact test commands and results (final state, after T15)

```bash
cd WT/client/rust; L="CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock"
$L cargo fmt -p mind-core -p mind-gdext -p mind-headless                         # clean
$L cargo test -p mind-core --lib --features msav-import                          # 2497 passed / 0 failed / 4 ignored
$L cargo test -p mind-headless --lib                                             # 133 passed / 0 failed
$L cargo test -p mind-gdext --lib                                                # 44 passed / 0 failed
$L cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings          # clean
$L cargo run -q -p mind-headless -- parity goldens                               # 97 PASS / 0 FAIL (none regenerated)
```

New tests: `phase_wall_reflects_low_damage_bullet` (custom 20-damage bullet ->
11/40 deflected at chance 10/20; 195/400 with 400 bullets), `surge_wall_arcs`
(T12); `repair_turret_body_matches_java`, `cargo_unload_point_body_matches_java`,
`unload_point_stale_flips` (T13); `separator_weighted_results` (600 crafts),
`mass_driver_shoots_to_linked`, `thermal_generator_reads_heat_floor` (3.6/tick),
`steam_generator_needs_water`, `unloader_pulls_from_graphite_press`,
`bridge_conveyor_throughput` (80 +-10% in the 400-tick window), (T14);
`beam_node_links_battery_in_line` (T15). No `.gd`/`.tscn` edits (no parse gate).

## In-engine evidence

None for T12-T15: every one of these sections says "Verify in-engine: Headless
only" / "verification tests by design". Per-task evidence JSONs (cause, tests,
Java citations) live under `REPO/runs/20261015-s5-H02-T12/`, `…T13/`, `…T14/`,
`…T15/`. Panic count n/a (no engine boots this pass); the unit/golden suites all
run with 0 panics.

## Deviations from Java (explicit)

* T12: `hit = 1f` (white flash) and `flashHit` are render state -> H03; the
  `lightningSound`/`deflectSound` calls are H07.
* T12: fixed a live-bug the reaction exposed - the `BulletComp.tileRaycast`
  closure and the direct-overlap fallback re-used the bullet's pre-tick team, so
  a deflected bullet was re-rolled and double-damaged by the fallback in the same
  tick (probe: 291 rolls for 400 bullets, 93 survivors; 400 rolls / 195 after the
  fix). Both spots now re-read the live team like Java's per-tile `build.team !=
  team`.
* T13: `UnitCargoUnloadPoint`'s stale timer now follows Java (`staleTimer`
  counts up while full for `staleTimeDuration = 360`); the previous port field
  counted DOWN while empty. `dumpAccumulate()`'s reset is not modelled (the
  port's unload point has no dump path). Read of an out-of-range item id yields
  `Some(ItemId)` where Java's `content.item()` would be null (same as the
  unloader body).
* T14: separator pick keeps the port's deterministic `CrafterState.rng` draw
  instead of Java's `Mathf.randomSeed(seed++)`; same uniform draw over the weight
  sum. The bridge test feeds the source buffer with past-stamped items so the
  74-tick ready latency is pre-satisfied - the assertion pins the send timer,
  which is the sustained rate (12/s, not the `speed = 74` number).
* T15: Java's `connectedPower` is constant-true (`grep "connectedPower = false"`
  finds nothing), so the neighbour test is `PowerModule` presence; the
  `instanceof PowerNode` exclusion is `PowerNodeConfig` presence. Links are
  entities mirrored into `PowerModule.links` (the port has no per-building
  `dests` array).

## Blockers / notes for the next session

* **T13 cargo loader body is still missing** (recorded, not implemented, per the
  pass-3 note): Java stores a deferred `readUnitId` and resolves it in
  `updateTile` through `Groups.unit.getByID` (`UnitCargoLoader.java:84-103,
  174-185`). The port has no seam for it: `LiveEntitySink::read_entity` discards
  the saved entity id (`io/sim_io.rs`) and `Sim::apply_decoded_entities` respawns
  units with fresh `EntitySeq`s, so neither a deferred id nor an id->entity map
  exists. A save with a cargo loader still misreads the next building; the fix
  needs (a) restoring `EntitySeq` on unit load and (b) a `get_by_id`-style
  lookup. `H04` was named as the owner of per-kind bodies.
* **T13 assembler body is still missing**: Java writes `progress`, the assembled
  `units` id list, the `blocks` PayloadSeq and `commandPos`
  (`UnitAssembler.java:756-789`); the port's `UnitAssembler` state has none of
  the PayloadSeq/units-list/commandPos model, so the body would misalign the
  reader. Needs the PayloadSeq codec + an assembled-units list first.
* T14 fixed three real gaps found by the tests: floor heat attributes were
  missing entirely (molten-slag 0.85/hotrock 0.5/magmarock 0.75,
  `Blocks.java:327,365,375`); the live sim has no `WorldGrid` ECS resource, so
  `refresh_thermal_sum` always returned early - added `refresh_thermal_sum_grid`
  + `SimRuntime.thermal_generators` + `Sim::refresh_thermal_generators`
  (mirrors the T5 facing-drill pass); `UnloaderBehavior::VANILLA.speed` was 1.0
  instead of `60f / 11f` (`Blocks.java:2164`).
* T15's per-tick `refresh_beam_nodes` runs whenever a beam node exists; the
  status/`draw` halves (laser beams) are H03's.
* No regressions found in the H01/H03/H04/H09 code that shares these files.

## Ledger changes to apply (do not edit chains.json here; plan §4 expanded)

| Item | Change |
|---|---|
| PAR-0129 | unchanged (pass 3: sim half fixed, render half H03). |
| PAR-0190 | unchanged (pass 2). |
| PAR-0098 | unchanged (pass 1 slice stands). |
| PAR-0244 | unchanged (pass 2). |
| PAR-0220 | unchanged (pass 2 seam). |
| PAR-0209 | no change (H08). |
| New | "Surge walls never arc lightning and phase walls never deflect bullets" -> **fixed** by T12 `b7b79d3c` (headless: reflection + arc tests). |
| New | "RepairTurret and the cargo unload point have no save body (a save with them misreads the next building); UnitCargoUnloadPoint's stale timer is inverted" -> **fixed** by T13 `e8e2ca2a` (headless). |
| New | "UnitCargoLoader has no save body (blocked: no deferred readUnitId/EntitySeq resolution in the port)" -> **seeded**, owner H04. |
| New | "UnitAssembler has no save body (blocked: no PayloadSeq codec / assembled-units list / commandPos)" -> **seeded**, owner H04. |
| New | "Thermal generator never produces: floor heat attributes missing and the live sim has no WorldGrid resource for `refresh_thermal_sum`" -> **fixed** by T14 `9c4f0e80` (headless). |
| New | "Unloader runs 5.45x too fast (`speed` 1.0 vs `60f/11f`)" -> **fixed** by T14 `9c4f0e80`. |
| New | "Beam nodes (beam-node/beam-tower) connect nothing" -> **fixed** by T15 `e6e675c8` (headless). |
