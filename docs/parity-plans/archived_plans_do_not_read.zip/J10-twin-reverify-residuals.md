<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J10 — Twin harness, small residuals and the final round-J twin re-walk

**Goal.** Make the twin walk reproducible as a script, close the small residuals that do not
belong to another plan, and finish round J with an independent twin re-walk of every surface in
`docs/J-round-twin-verification.md` §1.

**Depends on.** T1 and T2 can start at once. T3 runs last, after J01–J09 merge.

## T1 — Commit the twin harness helpers — MEDIUM

The 2026-10-16 walk used ad-hoc shell helpers (`/tmp/jtwin/env.sh`, not in the repo). Turn them
into `tools/twin.sh` (bash, sourced) + `tools/twin_pointer.py`:

- `JW x y [button]`: Java click at window-relative coordinates. The origin is read **per call**
  from `xwininfo -name Mindustry` (never from `window_ctl.py`'s printout; see the 2026-10-16
  `java-leg-learnings.md` entry).
- `JM`, `JD` (drag), `JK` (key/keydown/keyup) and `JS name` (raise + capture into
  `$RUN/java/name.png`).
- `GC x y` (Godot dialog click = one `godot_input` sequence), `GW x y` (Godot world click =
  separate press/release), `GK Escape` (Godot key by name), `GS name` (game screenshot) and
  `GE 'expr'` (single-statement eval that prints `result`).
- `GP x y`: move the **real** pointer over the embedded Godot game. The origin comes from
  `xwininfo` of the `Mindustry-Godot (DEBUG)` child window. This is required for hover UI.
- `SIDE name`: `frame_diff.py` with JSON + side-by-side into `$RUN/diff/`.
- `ZOOM name x0 y0 x1 y1`: a 2x crop pair.
- A launch preamble that:
  1. backs up `parity-java-home/.local/share/Mindustry/settings.bin`;
  2. launches Java with `setsid` and gates on "Total time to load";
  3. places the Java window so it does **not** overlap the Godot game window (Java pointer
     moves that cross it land in Godot);
  4. on teardown, moves session-created saves out of both profiles and restores
     `settings.bin`.

Add a short section to the `parity-eval` skill pointing at it.

## T2 — Small residuals — LOW

1. **Inert graphics settings** (still inert after `3ae546b9`):
   - `bloomintensity` / `bloomblur` → `Renderer.java:393-394`
     (`bloom.setBloomIntensity(getInt("bloomintensity", 6) / 4f + 1f)`,
     `bloom.blurPasses = getInt("bloomblur", 1)`); feed the port's bloom pass
     (`mind-core/src/render/bloom.rs`, the `World/Bloom` node in `game.tscn`, `mind-gdext/src/render.rs`).
   - `linear` → texture filter on atlas pages (`SettingsMenuDialog.java:540-550`,
     `Drawf.java:59`, `Mods.java:204`).

   The other inert rows (`playerchat`, `playerindicators`, `showpings`, `showotherbuildplans`)
   belong to deferred multiplayer.
2. **Rapid skip-wave clicks**: two `godot_input` clicks 300 ms apart on the wave skip button
   advanced a fresh Godot sandbox only one wave (twin row 25). Java was not given the same double
   click. Run both clients with the same double click; if Java advances two waves, look for a
   debounce/tap-throttle on the port's button. Java's single-player `logic.skipWave()` has no
   cooldown.
3. **Settings page wheel scroll**: an injected wheel did not scroll the Graphics page (twin row
   36). Re-test with the real pointer and a real wheel (`xdotool`/pynput). Fix it if it fails
   there too.
4. **Hover info over UI**: Java hides the hovered-block box while `Core.scene.hasMouse()`.
   Re-check Godot with the real pointer resting on the palette.
5. **Round-I FX/audio follow-ups**:
   - PAR-0348 `FxEmit::square` 45° convention: decide once and apply across the ~30 call sites
     (shared with J03 T7).
   - The `LegsComp` leg-base emitter (I02 follow-up), after J03 T4.
   - PAR-0346: keep the power-node shimmer as is. The I02 summary's claim that it is wrong was
     itself wrong (round-I twin report §2 item 8).
6. **Harness hazards**: PAR-0345 (mixed-indentation evals hang the frame loop) and PAR-0347
   (`$I.configure_building` on a door times out). Reproduce each, then add a guard to
   `tools/gmcp.py` (indentation normaliser; a 10 s eval watchdog that issues `stop`/`play`) or
   record the root cause in the ledger.

## T3 — Final twin re-walk (round-J verification) — HIGH, last

- Re-run every row of `docs/J-round-twin-verification.md` §1 with T1's harness on fresh builds
  of both clients. Keep the same maps and the same actions, plus the plan-specific acceptance
  frames listed in J01–J09.
- Normalise the Godot unlock state before the campaign rows (J07 note).
- Write `docs/K-round-twin-verification.md` in the same shape: verdicts, findings ranked, ledger
  notes. Apply the ledger changes listed in every J summary (coordinator only).

## Done criteria

`tools/twin.sh` is committed and documented. The T2 items are landed or recorded. The round-K
twin report exists, and every J plan acceptance frame is MATCH or carries a recorded deviation.
