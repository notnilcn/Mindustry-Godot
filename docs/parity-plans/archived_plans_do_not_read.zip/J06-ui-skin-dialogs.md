<!-- SPDX-License-Identifier: GPL-3.0-only -->
# J06 — UI skin, dialog shells and per-dialog fidelity

**Goal.** Buttons, sliders and dialog shells use the Java `Styles` and `BaseDialog` geometry.
Every dialog the twin walk flagged matches Java side by side.

**Evidence.** Twin report rows 01, 06, 07, 13, 26-30, 32, 36-41, 44 and finding F6/F10/F11.
Java frames: `runs/20261016-J-twin/java/{01-play,06-pause,07-afterquit,26-quitconf,30-mapinfo,
32-edmenu,36-graphics,38-controls,39-load,41-caldera,44-wave,50-final}.png`.

**Depends on.** Nothing. Start with T1/T2: they are shared by every later task.

## T1 — `TextButton` + icon layout and the `defaultt` skin — HIGH

- Java: `table.button("@text", Icon.x, runnable)` is a `TextButton` in `Styles.defaultt`
  (`Tex.button`: black body with a grey border; `over`/`down` variants; `ui/Styles.java`) with
  the `Icon.*` drawable in a left cell at icon size and the label centred in the remaining
  width. Frames: `java/06-pause.png` (pause menu), `java/07-afterquit.png` (confirm),
  `java/32-edmenu.png` (editor menu).
- Port: `MindWidgets.icon_button` (`client/ui/mind_widgets.gd:87-138`) centres an `HBox` of an
  18 px glyph + label. The pause menu, confirm prompt, editor menu and Map Info instead put the
  glyph inline in the label text ("✖ Cancel") on a flat slate fill. That fill is the wrong theme
  variation; check which `theme_type_variation` `paused_dialog.gd` and the prompt use against
  `styles_manifest.json`.
- Change:
  1. Make `icon_button` reproduce the Java cell layout: left icon at `iconMed` (32 px for the
     icon font) with a fixed pad, label centred over the remaining width.
  2. Make every `button(text, icon)` call site use it. Grep `client/ui` and `client/scenes`
     for inline glyph + text labels.
  3. Check the `defaultt` style box against `Tex.button`/`buttonOver`/`buttonDown` nine-patches.
- Accept: the pause menu, quit confirm and editor menu frames match the Java frames above.

## T2 — Dialog shells (`BaseDialog`, `showConfirm`, fill vs float) — HIGH

- Java:
  - `BaseDialog` fills the screen, has the accent title bar and a `buttons` row at the bottom
    (`addCloseButton`: 210x64 `@back` + `Icon.left`).
  - `UI.showConfirm` (`core/UI.java:582-606`) is a non-filling `BaseDialog`: text `width(500)`
    wrapped and centred, buttons `size(200, 54).pad(2)` (`@cancel` `Icon.cancel`, `@ok`
    `Icon.ok`), Enter confirms, Escape cancels.
- Port: `MindDialog` draws a boxed panel for several fill dialogs: Map Info (`java/30-mapinfo.png`
  vs Godot), the editor menu, Game Over, Load Game. The prompt draws as a boxed inline panel.
- Change: give `MindDialog` the two Java modes, `fill_parent` (default true, no panel box, dimmed
  backdrop) and floating (`setFillParent(false)`). Port each flagged dialog to the right mode
  with Java's `cont`/`buttons` cell sizes:
  - `PausedDialog`: `dw = 220`, `height 55`, `pad 5`; Abandon/Host `colspan 2` widths
    `dw*2+10`; Quit `dw+10` (`ui/dialogs/PausedDialog.java:73-116`).
  - Editor `MapEditorDialog` menu, `MapInfoDialog`, `LoadDialog`, `GameOverDialog`.
- Accept: frames 06, 07, 26, 30, 32 and 39 match.

## T3 — Slider style `Styles.defaultSlider` — HIGH

- Java: `SettingsMenuDialog.SliderSetting` (`ui/dialogs/SettingsMenuDialog.java:840-870`) stacks
  a `Slider` in `defaultSlider` with a title/value table drawn over it. `Styles.defaultSlider`
  (`ui/Styles.java:374-378`) uses `background = sliderBack` with
  `knob/knobOver/knobDown = sliderKnob*`. The row is a framed box with a tall knob
  (`java/36-graphics.png`).
- Port: `MindWidgets.slider` (`mind_widgets.gd:193-199`) sets `theme_type_variation =
  "defaultSlider"`, but the theme defines no `HSlider` styles for it. Godot's default thin track
  and grabber show through the title text (`godot/36-graphics.png`).
- Change: in `ui/theme/theme_builder.gd`, map `defaultSlider` → `HSlider` `slider` stylebox
  (`sliderBack` nine-patch), `grabber_area`/`grabber_area_highlight` (none), and
  `grabber`/`grabber_highlight`/`grabber_disabled` icons (`sliderKnob`, `sliderKnobOver`,
  `sliderKnobDown`). Set the min row height to the Java stack height. Check that the title and
  value labels sit inside the 33 px margins.
- Accept: the Graphics page matches `java/36-graphics.png`. Hovering a row shows the
  description tooltip (Java `tooltip(description)`; check with the real pointer).

## T4 — Rebind Keys dialog — MEDIUM

- Java `KeybindDialog` (`ui/dialogs/KeybindDialog.java:35,95-114`): an accent 3 px title rule.
  Axis labels are `min + " [red]/[] " + max` rendered as **markup**. Key names are coloured
  `Pal.accent` (`darkGray` when unset), `minWidth(90)`. The table is a centred column.
- Port: `keybind_dialog.gd` puts the raw string in a plain `Label` (shows `A [red]/[] D`),
  colours keys white and stretches to full width (`godot/38-controls.png`).
- Change: render key cells through `MindRichLabel` (Arc colour markup), colour them per Java and
  centre the table at Java widths.

## T5 — Load Game dialog — MEDIUM (with J01 T4/T5)

- Java `LoadDialog`: slot cards with an accent title, the `emptyTogglei`/`emptyi`
  save/trash/pencil/export icon buttons, the preview image, meta lines, and bottom buttons
  `@back` + `@save.import` at BaseDialog size (`ui/dialogs/LoadDialog.java:70-200`).
- Port: tiny Back/Import buttons at the bottom edge, white titles, wide cards
  (`godot/39-load.png`).
- Change: card width/colours and the button row at Java sizes. Previews and ordering are J01.

## T6 — Game Over dialog — HIGH

- Java `GameOverDialog` (`ui/dialogs/GameOverDialog.java:60-185`):
  - A single title (the headline replaces the title text).
  - A `Styles.black3` pane.
  - `StatLabel` rows: 50 px tall, starting `Pal.accent` then animating to `Pal.darkestGray` over
    0.3 s while scaling in, value counting up with `Interp.slowFast` after 0.3 s.
  - `stats.wave = state.stats.wavesLasted` only when `rules.waves`.
  - A **Time Played** row when `control.saves.getCurrent() != null`.
  - Buttons: `@menu` 140x60 (custom) or `@continue` 170x60 (campaign).
- Port (`client/ui/dialogs/game_over_dialog.gd`):
  - Rows stay bright accent (no colour tween; `:67-100`).
  - The waves stat read **0** where Java read 2. The key is right:
    `MindCampaign.game_stats_json` emits `"wave": session.stats.waves_lasted`
    (`mind-gdext/src/campaign.rs:5429-5443`). The value is wrong:
    - `waves_lasted = wave` is set only in `play::game_over` (`mind-core/src/game/play.rs:746-750`),
      and the wave-event increment only touches the campaign planet stats
      (`game/runtime.rs:486-491`).
    - Java sets `state.stats.wavesLasted = state.wave` both in the `GameOverEvent` listener
      (`core/Control.java:133`) and in `Logic.gameOver` (`core/Logic.java:436`).
    - Find which path the custom-game core-loss takes (probably `update_game_over` or a
      facade-side session copy) and set the stat there.
  - No Time Played row.
  - The title is duplicated.
  - The Menu button is small.
- Accept: the custom-game game over matches `java/50-final.png` (dark rows, Waves Defeated =
  wave reached, Buildings Built, Time Played). Add a GDScript or Rust test for the stats context
  keys.
- Ledger: new item "Game Over shows Waves Defeated 0 and no Time Played".

## T7 — Map Play dialog clipping (portrait previews) — HIGH

- Symptom: for Ancient Caldera (a portrait preview), the Godot Map Play content is shifted
  right and clipped at the dialog edge (`godot/41-caldera.png`). The sandbox map
  (square) lays out correctly (`diff/10-mapplay-side.png`).
- Java `MapPlayDialog` (`ui/dialogs/MapPlayDialog.java`) fits the preview into a fixed cell and
  keeps the mode table centred.
- Change: constrain the preview cell (`TextureRect` `STRETCH_KEEP_ASPECT_CENTERED` inside a
  fixed `custom_minimum_size`) so the content width does not change with the preview's aspect
  ratio. Re-test every shipped map.

## T8 — Placement palette details — MEDIUM

- Java `PlacementFragment`:
  - Block icons are tinted `Color.gray` unless the team has infinite resources or the core can
    afford the block **and** `player.isBuilder()` (`ui/fragments/PlacementFragment.java:315`).
  - The grid has 4 columns with a `smallPane` scroll.
  - Category buttons are `clearTogglei` with no cell background.
- Port: no affordability tint (`godot/46-conv-sel.png` vs Java), the first column clipped at
  the panel's left edge when the scroll bar shows (`diff/13-palette-zoom.png`), and dark cell
  backgrounds on the category buttons.
- Change: add the tint (refresh on core item change), fix the grid margins and the scroll bar
  width, and drop the category cell background.

## T9 — Small fidelity items — LOW

1. Main menu: the open submenu's parent button stays checked in `Styles.flatToggleMenut`
   (`checked = flatDown`; `MenuFragment.java:271,291`; `ui/Styles.java:210-218`). Godot shows
   only a hover tint (`diff/01-play-side.png`).
2. Full dialogs with translucent backdrops: Core Database (`godot/28-coredb.png` covers the
   menu with an opaque slate) and the tech tree (`godot/40-tech.png`). Java draws them over a
   dimmed scene.
3. Keyboard focus outlines: Godot draws a focus frame on the planet page's Go button
   (`godot/03-sector.png`). Java never shows focus. Set `focus_mode = FOCUS_NONE` (or an empty
   `focus` style) for mouse-driven buttons globally.
4. Sector panel: "Under attack!" centred; the Stats button style is `cleart`, not filled
   (`diff/03-sector-side.png`).
5. Wave panel: Java wraps "2 Enemies / Remaining" left-aligned at a fixed width; Godot widens
   the panel on one centred line (`diff/43-wave-side.png`).
6. Editor block palette: the selected-entry highlight is too faint; the "Show Blocks/Terrain/
   Floor" check rows use square boxes (Java round toggles; `diff/31-editor-open-side.png`).

## Done criteria

T1–T3, T6 and T7 landed and matched in-engine. The rest are landed or recorded. A summary is in
`docs/J06-ui-skin-dialogs_summary.md`.
