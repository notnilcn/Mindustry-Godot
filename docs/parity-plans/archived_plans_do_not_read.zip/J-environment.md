<!-- SPDX-License-Identifier: GPL-3.0-only -->
# Round J — shared environment and work rules

Every J plan follows these rules. Plan-specific notes override them only where the plan says so.

## 1. Work rules

1. **One task = one commit**, message `J<NN> T<n>: <summary>`, plus `Fixes PAR-####` when a
   ledger item closes. Docs/summary commits are separate from code commits.
2. **Java is the spec.** Every behaviour change cites the Java source as `File.java:line` in the
   code comment or the commit body. When the port intentionally deviates, write the deviation
   into the plan summary with the Java location.
3. Respect the tree invariants in `client/AGENTS.md` and `client/rust/AGENTS.md`:
   - GDScript is UI-only. Rules live in `mind-core`.
   - `mind-core` stays Godot/tokio-free.
   - Node building in code needs a `# code-instantiated:` reason.
   - Bundle keys go through `_t("@key")`.
   - New dialogs must be registered in all three manifest places.
4. **Ledger.** Executors never edit `chains.json` or `parity-ledger.json`. Each plan summary ends
   with a "Ledger changes to apply" list, and the coordinator applies it (see the memory note: use
   `chains.json` as-is, no git archaeology of ledgers).
5. Never stage `runs/` or `.opencode/parity-session/`. Evidence goes under
   `runs/<date>-s<N>-J<NN>-T<n>/`.
6. Cargo is serialized with `flock` when several sessions share a host (round-I convention):
   `CARGO_BUILD_JOBS=6 flock /tmp/opencode/mg-build.lock tools/build.sh`. Relaunch the editor after every build; a running
   editor keeps the old `libmind_gdext.so` mapped.
7. Write the per-plan summary to `docs/J<NN>-<slug>_summary.md` using the round-I shape:
   - per-task status
   - commits
   - exact test commands and results
   - in-engine evidence
   - deviations with Java file:line
   - blockers
   - ledger changes
   - done criteria

## 2. Gates (run before each merge)

```bash
cargo fmt --manifest-path client/rust/Cargo.toml --all -- --check
cargo clippy --manifest-path client/rust/Cargo.toml --workspace --all-targets -- -D warnings
cargo test --manifest-path client/rust/Cargo.toml -p mind-core
cargo test --manifest-path client/rust/Cargo.toml -p mind-headless
cargo test --manifest-path client/rust/Cargo.toml -p mind-gdext
bash tools/godot.sh --headless --editor --quit --path client      # GDScript parse/import gate
godot4 --headless --path client --script res://tools/shaders_check.gd
cargo run -q --manifest-path client/rust/Cargo.toml -p mind-headless -- parity goldens   # tools/ci.sh runs the full gate
```

A golden that changes on purpose is regenerated with `tools/regen_goldens.sh`. The reason (Java
location of the behaviour that moved it) goes in the commit body and the plan summary.

## 3. In-engine verification (what "verified" means in round J)

Round I marked several items verified that the round-I and round-J twin walks contradicted. In
round J, an item is verified only when:

1. the behaviour has a Rust test (or a GDScript widget/scene check) that fails before the fix,
   and
2. a **real-input** in-engine walk reproduces the Java frame of
   `runs/20261016-J-twin/java/<frame>.png` (named in the plan task) or a fresh Java capture. A
   facade call (`emit_signal("pressed")`, `configure_building` via eval) can stage state but
   never counts as the action under test.

Launch/drive recipes are in the `parity-eval` and `playtest` skills. Round-J harness facts (see
also `open-godot-mcp-learnings.md` / `java-leg-learnings.md`, 2026-10-16 entries):

- **Godot hover reads the real X pointer.** Injected `godot_input mouse_motion` does not move
  `get_viewport().get_mouse_position()`. To test hover UI (hover info, tooltips), move the real
  pointer over the embedded game window. Get its origin from `xwininfo -id <game window>`; on
  2026-10-16 it was (704,489). Example: pynput `Controller().position = (704+x, 489+y)`. Any Java
  pointer move that crosses the Godot game window also lands in Godot.
- **Java clicks need the real window origin.** `window_ctl.py` can print a stale geometry after
  `move`. Read `xwininfo -name Mindustry` before computing click coordinates. After a move, the
  client may keep its old idea of its own origin until it is moved once more.
- `godot_input key` takes Godot key names: `{"key":"Escape"}`. `KEY_ESCAPE` is accepted and
  silently does nothing.
- World clicks in Godot: send press and release as two separate `godot_input mouse_button`
  calls. Dialog buttons work with one `sequence` (motion + press + release, `frame_delay` 1).
- Never index a `find_children` result or loop inside an eval. A failed eval pins the frame loop
  (`Engine.get_process_frames()` freezes); recover with `tools/session-play.sh <N> --play`.
- `MindCampaign.start_map_mode(...)` starts the sim but leaves the main menu up. Use the UI path
  (Play → Custom Game → card → Play) for anything visual.
- Ground units and turrets: stage with `SimHost.place_block(x, y, name)` and the
  `apply_sim_command_json({"op":"spawn_unit","unit":<id>,…})` op (ids follow the registry order;
  read names back with `unit_debug_positions()`).
- The Java profile carries the full tech tree. Do not re-import it through the UI and never clear
  its Game Data. The Godot session-1 profile is partial (282/375 unlocks), so campaign
  comparisons must normalise state first. Prefer custom games for like-for-like frames.

## 4. Parallelism

At most about 4 Godot sessions per host (14 GB RAM; memory note `mindustry-godot-parallel-sessions`).
`tools/parity-session.sh --session N` creates worktree N with display `:(9+N)` and bridge
`6970+10(N-1)`; `tools/session-play.sh N` restarts/plays. Only one Java client may run per display
and per data dir.
