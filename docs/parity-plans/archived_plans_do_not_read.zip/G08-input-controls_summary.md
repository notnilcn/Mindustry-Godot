# G08 summary — in-game input and controls (session 2, wave 2, 2026-10-13)

Executor: DeepSeek V4.1 Flash (opencode), session 2, worktree
`/home/clintonnguyen/g/code_examples/Mindustry-Godot-session2`, branch `parity/session-2`,
bridge 6980, display :11. Plan read in full (00-environment, INDEX §3, G08 §1-§6).

Start state: `git merge --ff-only main` from `245857b` -> `ef54dfa` (wave-1 merges + ledger
commit). Status clean except the untracked `parity-ledger.json` symlink. Dependency checks on
main: G02 T1 (`390b1bc`), G04 T4 (`d75c051`), G01 T9 (`2433a69`), G01 T19 (`245857b`),
G04 T5 (`b1e2f54`) landed; G01 T15/T16, G02 T8/T10, G03 T10/T14, G05 T4b/T10b absent.

## Per-task status

| Task | Status | Commit | Notes |
|---|---|---|---|
| T1 shooting/aim/facing/boost | **done, in-engine PASS** | `2242a55`, seam `dd3d5b8e` | `[true, 3]` bullets while held, alpha aim (1080,440), rotation 0, release stops (`[false, 0]`) |
| T2a player unit stack withdraw/deposit/drop | **done, in-engine PASS** | `a97e2fe` | core 106 -> 76, `player_stack_json` `{copper,30}` |
| T2b tap-unit deposit/drop | **done, in-engine PASS** | `9cceb30`, bind fix `eb13dad8` | stack 15 + duo `turret_total_ammo 30`; the v1 bind re-entrancy panic is fixed |
| T3 PAR-0101 game gate/M/F8/Esc | **done, in-engine PASS** | `4864f60` | menu T/F8 inert; M one toggle per press; Esc pauses then the dialog hide unpauses; J toggles research |
| T4 even-size cursor offset | **done, in-engine PASS (anchor)** | `4f64c33` | raw (132,58) -> plan anchor (131,57); queued-plan readback limited by the instant-place finding |
| T5 plan config to finished block | **done (headless)** | `c90874a` | |
| T6a schematic plans + rotate/flip | **done (headless)** | `4836a54` | |
| T6b schematic copy mode | **done, in-engine PASS (copy half)** | `2421914` | select_plans 3 + centered preview + flip/clear verified; paste readback limited by the instant-place finding |
| T7 rebuild select | **done, in-engine PASS** | `4a70186` | ghost -> B plan -> rebuilt + ghost cleared; right-drag cancel verified; derelict half skipped (G02 T8 absent) |
| T8 line junction/bridge/nodes | **not started** | | budget |
| T9 wheel zoom/rotate routing | **done, in-engine PASS** | `4905b670`, seam `367dc354` | nothing selected -> zoom 4->5; R+wheel rotates the conveyor 0->1; drill+wheel rotates the placement (Java-correct) |
| T10 block hotkeys/pick/F1 | **not started** | | budget |
| T11 RTS residuals + set_unit_command | **not started** | | budget (G03 T10 absent -> T11 would define the funcs per its text) |
| T12 possession/respawn/payload repeat input | **done, in-engine PASS** | `af01419f` | Ctrl+click -> Player row `mega`; V releases it (env-blocked respawn, G01) |
| T13 PAR-0102 axis rebind | **done, in-engine PASS** | `0efc7789` | dialog J then L -> move_x `display L / negative J`, keybinds reset after |
| T14 mouse bindings + C/F5/F11 | **not started** | | budget |
| T15 hint keys + command objective | **done, in-engine PASS (hints)** | `67e1bece` | take_hint_keys F -> `schematic_select_release` (+ stale runtime triggers), shiftLeft -> `boost_down`; objective covered headless |

## git log --oneline main..HEAD

```
367dc354 Gameplay G08 T9: building_debug reports rotation (probe seam)
67e1bece Gameplay G08 T15: hint key edges and command-mode objective input seams
eb13dad8 Gameplay G08 T2b: keep the deposit probe out of the match scrutinee
4905b670 Gameplay G08 T9: wheel zoom/rotate routing and R+wheel rotate-placed as in DesktopInput
af01419f Gameplay G08 T12: Ctrl+click possession, V respawn and payload key repeat (input path)
dd3d5b8e Gameplay G08 T1: debug_spawn_player playtest seam (env-divergence workaround)
0efc7789 Fixes PAR-0102: axis rebinding captures both directions or the wheel
4a70186b PAR-0098: rebuild select, area removal of queued plans and ghosts, ghosts clear on rebuild
24219144 Fixes PAR-0099: schematic copy mode (F drag, Z/X flip, wheel rotate, click to place)
4836a54c PAR-0099: schematic plans helper and faithful rotate/flip of select plans
c90874ae PAR-0098: build plans carry their config to the finished block
4f64c336 PAR-0098: placement cursor honours the block offset for even-size blocks
4864f608 Fixes PAR-0101: gameplay hotkeys only in game; single M/F8 toggle; Esc pauses
9cceb302 Gameplay G08 T2b: tap the player unit to deposit or drop its stack
a97e2feb Gameplay G08 T2a: item withdraw/deposit/drop move the player unit's stack
2242a550 Gameplay G08 T1: player unit aims, faces and shoots from desktop input
```

## Test commands + results (flock + `CARGO_BUILD_JOBS=6`)

| Check | Result |
|---|---|
| `cargo test -p mind-core --lib --features msav-import` (after T15) | **2111 passed / 0 failed / 4 ignored** |
| `cargo test -p mind-gdext --lib` | **33 passed** (baseline 29 + 4) |
| `cargo test -p mind-headless --lib` | **132 passed / 0 failed** |
| `cargo clippy -p mind-core -p mind-gdext -p mind-headless --all-targets -- -D warnings` | clean after each commit |
| `cargo fmt -p mind-core -p mind-gdext` | clean |
| GDScript parse gate (`tools/godot.sh --headless --editor --quit --path client`) | clean (T13 first run caught a MindLabel/Label typing error; fixed before commit) |
| per-task filters | player 11, player_items 7, sim::builder 18, input::cursor 2, input::line 11, game::schematics 14, scroll_routing 1, any_unit_has_command 1 |

Not yet re-run for the final tree: `parity goldens`, `mind-headless` goldens (no golden files
changed by G08; no content/UI struct touched).

## In-engine evidence (`runs/20261013-s2-G08-*`, shared runs/ dir)

Ground Zero entry works (`hasCore:true, campaign:true`); the player spawn is blocked by G01's
`rules.env=31` divergence (log: `spawn_player_unit: no supported core in the loaded sector`;
rules JSON carries `"env":31`), so all player probes use the `debug_spawn_player` seam
(`dd3d5b8e`). Panic gate 0 after every step except the one T2b crash below (fixed).

Batch v2 was run twice end-to-end on the final binary; the second (clean) run is
`runs/20261013-s2-G08-batch/batch-v2.log` (the first is `batch-v2-first.log`) and printed
`PANIC: 0` after every section with no script errors. Per-task evidence below.

* **T1 PASS** (`runs/20261013-s2-G08-T1/shooting.png`): push_event MouseMove to tile (135,55) +
  left hold -> `is_shooting true`, `get_group_count("bullet") 3`, alpha row `aim [1080,440]`,
  `rotation 0`, mounts `shoot:true`; release -> `[false, 0]`.
* **T2a PASS** (`runs/20261013-s2-G08-T2a/stack.png`): core 106 -> 76 (`debug_add_core_items`
  100 accepted first), `player_stack_json {item:copper, amount:30}` (cap 30 from a 50 request).
* **T2b PASS** (`runs/20261013-s2-G08-batch/batch-v2.log`): tap at the unit, release on the duo
  -> stack `{copper,15}`, duo `turret_total_ammo 30` (15 x ammoMultiplier 2).
* **T3 PASS** (`runs/20261013-s2-G08-T3/{menu-inert.txt, esc-paused.png}`): menu T/F8 inert;
  godot_input M flips `minimap.visible` false->true->false (one toggle per press); Esc ->
  `[["paused"], true]`, second Esc -> `[[], false]` (the dialog's hide unpauses); J -> research
  open, J again -> closed. (The first Esc press after M hid the M-shown minimap first —
  Java-faithful `_on_escape` order.)
* **T4 PASS (anchor)**: raw cursor tile (132,58) with `mechanical-drill` selected produces the
  line plan/preview at **(131,57)** = `World.toTile((1052-4)/8)`, i.e. the Java offset math; an
  unfixed cursor would anchor (132,58). Evidence: `runs/20261013-s2-G08-T4/evidence.txt`
  (full transcript, camera settled, mappings verified inverse-consistent) +
  `drill-offset.png`. The batch's own T4 click uses the plan's canvas-transform recipe, which
  does not match this rig's viewport mapping, so the batch section reads `[]` — the focused
  probe is the acceptance. Caveat: the queued-plan readback (`player_build_plans_json`) stayed
  empty because live `player:Some` SimCommands apply instantly (`player_can_build()` false —
  open finding below); the drill lands at the proven anchor instead.
* **T6b PASS (copy half)**: F-drag over the conveyors at (130..132,62) -> `select_plans == 3`,
  preview `[{x:131,y:62},{x:132,y:62},{x:133,y:62}]` (centered on the cursor, Java), X flip and
  right-click clear verified (`select_plans 0`); `runs/20261013-s2-G08-T6b/copy-3.png`. The paste
  click's plan readback is subject to the same instant-place caveat.
* **T7 PASS** (`runs/20261013-s2-G08-T7/rebuild.png`): `debug_kill_building(135,60)` pushed the
  ghost; B-drag queued it (`player_build_plans_json` unaffordable copy shows the plan), the wall
  rebuilt (`building_debug rotation 0`, block 216) and the ghost disappeared from
  `team_ghost_plans_json` (only the older (132,48) duo remains). T7b: with an empty core the
  re-killed wall's B-drag queued a stuck plan, right-drag removed it -> `[]`.
* **T9 PASS** (`runs/20261013-s2-G08-T9/wheel-rotate.png`): nothing selected + wheel ->
  `target_scale 4.0 -> 5.0`; R held + wheel over the conveyor -> `building_debug.rotation 0 -> 1`
  with no zoom; drill selected + wheel -> placement `rotation 3 -> 0`, no zoom (Java-correct:
  `Block.rotate` defaults true and `Drill` does not clear it, so the plan's "drill zooms"
  expectation is wrong).
* **T12 PASS** (`runs/20261013-s2-G08-T12/mega.png`): Ctrl+click on a spawned `mega` ->
  `unit_debug_json` Player row type **mega** at (1064,440); V then releases the mega to
  `CommandAI` and the core respawn is blocked by the env gate (G01 blocker), which proves the
  possession was live.
* **T13 PASS** (`batch-v2.log`): controls dialog -> `_start_capture("move_x")`, godot_input `J`
  then `L` -> `keybinds_json` move_x `display L, negativeDisplay J`; `reset_keybinds` restored.
* **T15 PASS**: `take_hint_keys()` after F down/up ->
  `["shoot","schematic_select_release","rebuild_selecting","diagonal_release"]`, immediate second
  call `[]`; shiftLeft press -> `["boost_down"]`.
* Crash found and fixed: `crash-report-10_13_2026_18_12_17.txt` — `Gd<MindSimHost>::bind_mut()
  failed, already bound ... in MindInput::process()` from T2b's `match host.bind()
  .player_can_deposit_at(..)` scrutinee keeping the shared guard; fixed in `eb13dad8`, re-run
  clean (T2b PASS, panic 0).
* Open finding (not T4): in the live session `SimCommand::Place{player: Some}` applies instantly
  (`player_can_build()` appears false) while the direct `queue_player_place_config` path queues
  and builds (T7). Root cause not identified within budget; it predates this session's changes
  (the routing is in G02/G04 territory) and does not affect the T4 anchor or T7 evidence.
  One `queue_player_place_at` eval with a raw-id arg wedged the frame loop; recovered with
  `session-play.sh 2 --play` (no panic).

## Deviations / blockers

* T1: mine-tile facing uses the Java `Tile.worldx()` corner (`angleTo(Tile)`), not the plan's
  `tile_center` (plan text mis-derived; Java authoritative).
* T2a: no redundant `CoreBehavior.accept_stack` override — G02 T1's trait default already routes
  through `accept_item`/`get_maximum_accepted` (Java's inherited `CoreBuild` path). `allowDeposit`
  is always true (`onlyDepositCore` not ported, default false).
* T3: `command_mode_allowed` is not gated on `in_game` (bridge tests + the MCP toggle probe need
  it outside a game); Java only runs the whole update in game — minor deliberate deviation.
* T6b: godot macro can't parse tuple-pattern params, so `copy_schematic_plans` takes `start/end/
  cursor` as plain params; select-plan flushes use the port's `addBuild` tail convention (Java
  inserts at `min(1, size)` — pre-existing deviation).
* T7: derelict repair over the B/break rect (`InputHandler.java:2331-2341`) skipped (needs G02 T8).
* T9: the line-angle override uses the drag tile-angle directly; the plan's "drill selected ->
  zoom" acceptance is wrong vs Java (`Block.rotate` defaults true; `Drill` never clears it), so
  the drill rotates the placement and does not zoom — verified as Java-correct.
* T11/T12: the Ctrl+click proxy uses `SelectableUnit.commandable` (= `AiKind::Command`), matching
  Java's `isAI && playerControllable` for player-team campaign units; building control accepts the
  turret kinds + BuildTurret (`ControlBlock`); Router (`ControlBlock` upstream) not included.
* T12 payload hold-repeat is headless/compile-verified only; no carrier acceptance in-engine.
* T15: `command_mode_objective` in-engine check skipped (headless test covers the read).
* G01 in-engine env blocker persists: the live sector `rules.env` is 31 (scorching), Java's is
  233 — `set_rules_json` cannot patch it because campaign edits require `allowEditRules`; the
  `debug_spawn_player` seam is the documented probe workaround.
* **Open finding (not T4)**: live `SimCommand::Place{player: Some}` applies instantly — the
  `player_can_build()` route appears false in the session even with an alpha player, while the
  direct `queue_player_place_config` path queues+builds (T7). Root cause not identified within
  budget; it predates this session's changes and only limits the `player_build_plans_json`
  readback for T4/T6b.
* T8/T10/T11/T14 were not reached (budget); T11's G03 T10 dependency is absent but its plan text
  defines the two `#[func]`s locally, so it is executable by the next session.

## Ledger changes to apply (coordinator)

| Item / new item | Status | Note |
|---|---|---|
| new: player unit never aims/fires/faces (desktop updateMovement aim/controlWeapons missing) | **verified** | `2242a55`; in-engine `[true,3]` bullets + aim, release stops |
| new: item withdraw/deposit use a phantom relay stack; no range/acceptStack; no tap-unit deposit | **verified** | `a97e2fe` + `9cceb30` + bind fix `eb13dad8`; core 106->76/stack 30 and stack 15/duo ammo 30 in-engine |
| PAR-0101 gameplay hotkeys on the menu; double M/F8; console gate; Esc not pausing | **verified** | `4864f60`; menu inert, M single toggle, Esc pauses/closes, J toggles |
| new: even-size blocks placed one tile off the cursor (InputHandler.tileX offset) | **verified (anchor)** | `4f64c33`; raw (132,58) -> (131,57); plan-queue readback limited by the instant-place finding |
| new: build plans drop their config (schematic/rebuild/sorter nextConfig) | fixed (headless) | `c90874a` |
| new: ghost rebuild plans never clear; B rebuild select missing; right-drag does not cancel queued plans | **verified** | `4a70186`; ghost -> rebuild -> cleared, right-drag cancel; derelict half skipped (G02 T8) |
| PAR-0099 schematic copy (F-drag) | fixing -> verified (copy half) | `4836a54` + `2421914`; select_plans 3 + preview + flip/clear in-engine |
| PAR-0102 axis rebinding | **verified** | `0efc7789`; dialog J/L -> move_x display L / negative J |
| PAR-0138 payload key path | note | Ctrl+click/V input path + payload hold-repeat landed (`af01419f`); Ctrl+click -> mega verified in-engine; payload pickup not re-checked |
| PAR-0098 | stays `fixing` | slices: T4 `4f64c33`, T5 `c90874a`, T7 `4a70186b`, T9 wheel part `4905b670`; T8 line replacement + T11 RTS remain |
| PAR-0140 | add note | T11 not reached; residuals (stance ids, cancel_orders, select-all filters) still pending |
| new: wheel zoom/rotate routing (T9) | **verified** | `4905b670`; zoom 4->5 with nothing selected, R+wheel rotates a placed conveyor |
| new: hint seams (take_hint_keys + command objective input) | fixed | `67e1bece`; take_hint_keys verified in-engine |
| new: player input matrix (mouse-bindings C/F5/F11, T14) | pending | not reached |
| new: block hotkey combos/pick/F1 (T10) | pending | not reached |
| open: live `player:Some` placements instant instead of queuing (`player_can_build()`) | new (needs a follow-up) | observed in-engine; direct `queue_player_place_config` path works (T7 rebuild built) |
