# I04 — Campaign UI (session 2) — summary

Session 2, worktree `Mindustry-Godot-session2`, branch `parity/session-2`,
bridge 6980, display :11. Plan: `docs/parity-plans/I04-campaign-ui.md` (17
tasks). Executed 2026-10-16.

Status: **T1–T7 done (8 commits). T8–T17 not reached (budget).** The branch is
clean and fully committed; all gates green at the last task.

## Per-task status

| Task | Status | Evidence |
|---|---|---|
| T1 palette rebuild on world load/unlock | done (incl. extra fix) | runs/20261016-s2-I04-T1 (onset palette = ducts, back to GZ = conveyors) |
| T2 unlock toast | done | runs/20261016-s2-I04-T2 (scrap-wall research toast + merged 2-icon grid) |
| T3 hint predicates/events | done | runs/20261016-s2-I04-T3 (`hint_state_json` events ["factorycontrol"]) |
| T4 logistics/storage/logic/defense stats | done | runs/20261016-s2-I04-T4 (titanium-conveyor Move Speed 10) |
| T5 unit factory/payload stats | done | runs/20261016-s2-I04-T5 (additive-reconstructor pairs) |
| T6 turret+ammo / unit weapons | done (2 commits) | runs/20261016-s2-I04-T6 + -T6b (duo ammo vs java-26-duo-info.png; dagger weapons) |
| T7 schematics dialog (Fixes PAR-0143) | done | runs/20261016-s2-I04-T7 (menu cards + GZ card = 100 select plans + info dialog) |
| T8 planet globe drag/zoom/last sector/reveal | not reached | — |
| T9 sector rename + icon picker | not reached | — |
| T10 sector stats dialog + Abandon | not reached | — |
| T11 database planet tabs (Fixes PAR-0144) | not reached | — |
| T12 dialog fade | not reached | — |
| T13 planet hex mesh (PAR-0142 p1) | not reached | — |
| T14 Serpulo emissive glow (PAR-0142 p2) | not reached | — |
| T15 planet bloom (Fixes PAR-0142) | not reached | — |
| T16 campaign UI cosmetics | not reached | — |
| T17 enemy bases (PAR-0112 step 3, headless) | not reached | — |

No task was skipped for a cross-plan dependency; T8–T17 are simply beyond the
session budget.

## Commits (`git log --oneline main..HEAD`)

```
9f07b0de Fixes PAR-0143: schematics cards, tags row and info dialog per SchematicsDialog
30f726c6 Gameplay I04 T6: unit weapon and ability content stats
ff3037b1 Gameplay I04 T6: turret and ammo content stats
6224b980 Gameplay I04 T5: unit factory and payload content stats
28c2bd32 Gameplay I04 T4: logistics, storage, logic and defense content stats
67a6ae8a Gameplay I04 T3: remaining hint predicates and hint events
8d213c5e Gameplay I04 T2: unlocking content shows the HUD unlock toast
90355c94 Gameplay I04 T1: placement palette rebuilds on world load and block unlock
```

## Tests (last run, all green)

```
cargo test -p mind-core --lib --features msav-import
  test result: ok. 2657 passed; 0 failed; 4 ignored
cargo test -p mind-headless --lib      -> ok. 133 passed; 0 failed
cargo test -p mind-gdext --lib         -> ok. 51 passed; 0 failed
cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings -> clean
cargo fmt -p mind-core -p mind-gdext -- --check -> clean
cargo run -q -p mind-headless -- parity goldens -> 97 PASS / 0 other
bash tools/godot.sh --headless --editor --quit --path client | grep SCRIPT ERROR|Parse Error -> nothing
```

Task tests: T3 `factory_command_records_hint`, `locked_upgrade_blocks_and_fires_hint`;
T4 `conveyor_stats`, `mender_stats`, `liquid_junction_has_no_liquid_capacity`;
T5 `additive_reconstructor_lists_unlocked_upgrades`; T6
`duo_ammo_lists_copper_graphite_silicon`, `dagger_weapon_stats`.
Goldens regenerated: `client/rust/mind-core/tests/goldens/ui/campaign.json`
(T7: view fields `power_consumption`/`power_production` + filtered loadouts +
fixture change) with `harness_ui_campaign` sha256 updated. Panic count 0 after
every in-engine step.

## In-engine evidence (paths under the shared `runs/`)

* T1: `runs/20261016-s2-I04-T1/{gz-conveyor-selected,onset-after-load,gz-back-conveyors}.png`;
  Onset palette = 7 ducts, `block` null after load, GZ back to conveyor.
* T2: `runs/20261016-s2-I04-T2/{unlock-toast,unlock-toast-merged}.png`;
  `_unlock_grid` [2, [24.0, 24.0]].
* T3: `runs/20261016-s2-I04-T3/{factory-command.png,hint-events.json}`;
  `hint_state_json` events `["factorycontrol"]`, fabricators 1.
* T4: `runs/20261016-s2-I04-T4/{database,titanium-conveyor-info}.png`;
  `itemsMoved` = `["10"," items/second"]`.
* T5: `runs/20261016-s2-I04-T5/additive-reconstructor-{info,scrolled}.png`.
* T6: `runs/20261016-s2-I04-T6/duo-info-ammo.png` (copper 9 damage / 2 ammo/item,
  inaccuracy 2 degrees) matches `runs/20261014-s3-verify3/java-26-duo-info.png`;
  `runs/20261016-s2-I04-T6b/dagger-info.png`.
* T7: `runs/20261016-s2-I04-T7/{schematics-menu,schematic-info,gz-card-placement}.png`;
  card press -> dialog hidden + `placement_preview_json()` = 100 plans.

## Deviations from Java (by task)

* T1: `MindCampaign.block_catalog_json` keys the campaign planet off the loaded
  world (`last_sector_rules().planet`) when one exists — Java's `state.rules`
  is the loaded world's from `World.loadSector` on, while the port's facade
  session flips only in `start_sector` (the posted `WorldLoadEvent` rebuild
  would otherwise read the old planet; `PlacementFragment.java:78-84`).
* T2: the shared `HudFragment.scheduleToast` 3.5 s slot is not ported (the port
  shows the toast at once when no box lives; `HudFragment.java:729-740`); the
  toast icon resolves by `<type>-<name>-ui` region candidates (the signal
  carries the name, not `content.uiIcon`).
* T4: plan's `duct_junction_has_no_item_capacity` unbuildable — Java
  `DuctJunction` has no vanilla block (mod `ClassMap` only; same in the port);
  test uses `LiquidJunction` (`LiquidJunction.java:21`). `CoreBlock` unit panel
  drops the `?` button/`console` name row. `ForceProjector` coolant panel not
  ported (`ForceProjector.java:117-140`).
* T5: plan's "dagger -> mace first" is Java-reversed — `Blocks.java:6345-6352`
  lists nova -> pulsar first; the test asserts the Java order.
* T6: turret coolant booster panels (`ReloadTurret.java:17`,
  `LaserTurret.java:26`) not ported; frag/interval panels render expanded (no
  collapse button, `StatValues.java:906-945`); `statusText` emoji skipped
  (`StatValues.java:229`); `reloadWhileCharging` absent (Java default true).
  Unit `mineTier` omits the `StatValues.drillables` list
  (`UnitType.java:824-833`); abilities render as name+knob panels (Java calls
  each ability's own `display`).
* T7: Tags pencil adds a tag through the shared text prompt (Java's
  `showAllTags` editor and `checkTags` are not ported); `pencilSmall` is
  approximated by `pencil`.
* Incidental fixes found while landing the above:
  `content_info_dialog.gd` rendered `Cell::Icon` null amounts as `<null>` and
  flattened nested panel rows onto one line (T5/T6); the schematics dialog's
  `_in_game()` used `== "playing"`, so in a `should_pause` match every card
  click opened the info dialog instead of starting placement (T7, folded into
  the PAR-0143 fix).

## Blockers / notes

* **Merge with main**: `main` advanced to `872a7430` (I06 pass 7) while this
  session ran. `git merge --no-edit main` conflicted in
  `client/rust/mind-gdext/src/campaign.rs` (both sides edited `campaign.rs`);
  per policy the merge was aborted (`git merge --abort`) and the branch left
  clean. The coordinator must resolve that conflict when merging
  `parity/session-2` (likely both keep-additions in `campaign.rs`; my hunks
  are the T1 palette planet source, the T2 unlock producers + `StatCtx.campaign`
  and the T7 `list_schematics`-adjacent code).
* The T7 fixture change (`vanilla_fixture` keeps one file-backed schematic)
  changes the `harness_ui_campaign` golden; regenerated per env §2.

## Ledger changes to report

| Item | After |
|---|---|
| PAR-0143 | verified (T7) |
| new | "Placement palette keeps the previous planet's blocks" -> verified (T1) |
| new | "Unlock toast never shows (no `MindHud.push_unlock` producer)" -> verified (T2) |
| note | T3: `cannotupgrade`/`factorycontrol` now have producers; the hint JSON `cores_destroyed` reads the session stats |
| note | T4/T5/T6 content-stats families landed (blocks/units); remaining stats deviations listed above |
| note | `content_info_dialog` null-amount + panel-row rendering bugs fixed (T5/T6) |
| note | schematics `_in_game()` paused-state bug fixed under PAR-0143 (T7) |
| PAR-0144, PAR-0142, PAR-0112 | **not reached** (T11, T13-T15, T17 remain for a follow-up session) |

## Done criteria

Not met in full: T1–T7 are committed with their checks, suites/goldens/parse
gate are green, and the T7 golden was regenerated; T8–T17 remain for a
follow-up session (the branch is clean and ready for the coordinator merge).

# Pass 3 (session 2, 2026-10-16)

Worktree `Mindustry-Godot-session2`, branch `parity/session-2`, bridge 6980,
display :11. Pass 2 exited without a report; T8/T9 were already merged to main
(`84eaee31`), T10 was recovered from the uncommitted worktree and finished.
`T8–T16 are done`; **T17 was not reached (budget)**.

## Per-task status

| Task | Status | Evidence |
|---|---|---|
| T8 globe drag/zoom/last sector/reveal | done (pass 2, merged) | commits `312ac469`; merged to main in `84eaee31` |
| T9 sector rename + icon picker | done (pass 2, merged) | commit `16400d7f`; merged to main in `84eaee31` |
| T10 sector stats + Abandon | **recovered + done** | `e63cb66c`; runs/20261016-s2-I04-T10 (see recovered-T10 note) |
| T11 database planet tabs (Fixes PAR-0144) | done | `c832a6d0`; runs/20261016-s2-I04-T11 |
| T12 dialog fade | done | `3d45c186`; runs/20261016-s2-I04-T12 |
| T13 planet hex mesh (PAR-0142 p1) | done | `b7070e73`; runs/20261016-s2-I04-T13 |
| T14 Serpulo emissive glow (p2) | done | `85bc61ed`; runs/20261016-s2-I04-T14 |
| T15 planet bloom (Fixes PAR-0142) | done | `b7d0fe9d`; runs/20261016-s2-I04-T15 |
| T16 campaign UI cosmetics | done | `979a788b`; runs/20261016-s2-I04-T16 |
| T17 enemy bases (PAR-0112 step 3, headless) | **not reached (budget)** | — |

**Recovered-T10 note.** The uncommitted worktree held T10 mid-task (view
fields + golden + facade + the `sector_stats` dialog). This pass finished it:
added the plan's missing `sector_stats_rows_in_item_order` test, fixed two
clippy `redundant_closure` errors, fixed the description row (the live registry
boots with the empty `MemoryBundle`, so the builder's `is_hidden()` proxy is
always true there — `campaign_views_json` now resolves
`sector.<preset>.description` against the host bundle like
`UnlockableContent.java:91`), and switched the Time row to
`Strings.formatMillis` (`h:mm:ss`, ARC `Strings.java:813`) instead of the
shared `UI.formatTime`-style helper. Verified with a real Stats click on
Ground Zero (description, `Time: 1:13:21`, Wave/Threat/Resources/lockdown,
Back + Abandon) and on Erekir Onset (`0:00:00`).

## Commits (pass 3, `git log --oneline main..HEAD`)

```
979a788b Gameplay I04 T16: campaign UI cosmetic residuals
b7d0fe9d Fixes PAR-0142: planet globe bloom
85bc61ed PAR-0142: Serpulo emissive sector glow on the globe
b7070e73 PAR-0142: planet globe hex mesh with generator colours and planet shader
3d45c186 Gameplay I04 T12: dialogs fade out over 0.1 s like Arc
c832a6d0 Fixes PAR-0144: database planet tabs render icons and default to the current planet
e9dc17c2 Merge branch 'main' into parity/session-2
e63cb66c Gameplay I04 T10: sector stats dialog with item rows, playtime and abandon
```

(pass-2 `312ac469` T8 / `16400d7f` T9 are ancestors via the coordinator's
`84eaee31`; the merge `e9dc17c2` brought I03 pass 5 + I08 pass 1 into the
branch with no conflicts.)

## Tests (last full gate, all green)

```
cargo test -p mind-core --lib --features msav-import
  test result: ok. 2688 passed; 0 failed; 4 ignored
cargo test -p mind-headless --lib      -> ok. 133 passed; 0 failed
cargo test -p mind-gdext --lib         -> ok. 54 passed; 0 failed
cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings -> clean
cargo fmt -p mind-core -p mind-gdext -- --check -> clean
cargo run -q -p mind-headless -- parity goldens -> 0 non-PASS (97 PASS)
bash tools/godot.sh --headless --editor --quit --path client | grep SCRIPT ERROR|Parse Error -> nothing
```

Task tests: T10 `sector_stats_rows_in_item_order` + `ui::manifest`;
T11 `database_tab_icons`, `banned_entries_mark_and_sort_last`;
T13 `build_hex_counts`, `build_hex_emissive_channel`,
`serpulo_color_alpha_from_albedo`; T14 `serpulo_emissive_returns_sector_glow`.
Goldens: the T10 `harness_ui_campaign` sha256 was updated (view fields);
`parity/golden_content.json` is byte-identical (the dump does not project
block render fields, so `albedo` left it unchanged — re-run to confirm).
Panic count 0 after every in-engine step.

## In-engine evidence (under `runs/`, bridge 6980)

* T10: `20261016-s2-I04-T10/gz-stats-v2.png` (Ground Zero Stats: description,
  `1:13:21`, resources, lockdown, Back + Abandon; opened by a real click),
  `onset-stats.png` (Erekir `0:00:00`) vs `20261014-s3-verify3/java-07-gz-stats.png`.
* T11: `20261016-s2-I04-T11/menu-database.png` (fill-parent dialog, centered
  50 px icon tabs: eye / ff9266 Erekir / 7d4dff Serpulo) vs
  `java-04-database.png`; `ingame-database-serpulo.png` (defaults to the
  played planet, `_tab` "serpulo").
* T12: `20261016-s2-I04-T12/notes.md` — hide keeps `visible` with `is_shown`
  false, mid-fade `[true, 0.067, true]`, final `[false, 1.0, false]`, re-show
  cancels `[true, 0.0, false, true] -> [true, 1.0, true]`.
* T13: `20261016-s2-I04-T13/planet-hex-front.png` / `cull-back-test.png`
  (shaded hex globe with real floor colours, atmosphere halo) vs
  `step-140-planet.png`; `planet_mesh` readback 43740 verts, indexed,
  emissive channel.
* T14: `20261016-s2-I04-T14/glow-{a,b,c}.png`; `emissive_count` 2746 of 43740
  vertices from the 59 live enemy-base sectors.
* T15: `20261016-s2-I04-T15/planet-bloom.png` + tuned WorldEnvironment values
  in its `notes.md`.
* T16: `20261016-s2-I04-T16/{planet-culled,planet-zoomed-fade,sector-list-black8}.png`;
  `ui_alpha` 1e-17 at zoom 2.0; `_preset_pulse()` 0.2206 -> 0.9670 in 1 s.

## Deviations from Java (pass 3)

* T10: the played-sector Abandon routes to the existing
  `MindCampaign.abandon_sector` (record clear + save delete; the port's paused
  menu behavior) instead of Java's hide-then-kill-cores game over
  (`PlanetDialog.java:1166-1177`); `playtime_ms` scans the save slot once
  (`Saves.java:385-386`, the live slot's in-memory accumulation is not added).
* T11: the banned cross is model-verified only in-engine — a campaign session
  refuses `bannedBlocks` edits (`set_rules_json` -> false), matching Java's
  campaign restriction; custom-game bans land with I06.
* T13: `parity/golden_content.json` unchanged (the dump does not project
  `albedo`/map colours); `u_lightdir` keeps the pre-T13 fitted `LIGHT_NORMAL`;
  Godot `ARRAY_CUSTOM0` is fed as float RGBA (PackedColorArray is rejected).
* T14: `planet_mesh` is cached in `MindCampaign` (invalidated by
  capture/abandon) because the debug-build per-tile noise pass is ~10 s; the
  emissive glow is subtle in this profile (only Ground Zero has light coverage).
* T15: bloom values are the tuned Godot equivalents recorded in
  `runs/20261016-s2-I04-T15/notes.md`.
* T16: markers rebuild only when `ui_alpha`/pulse drift (>0.02 / >0.04) —
  Java redraws every frame.

## Blockers / notes

* T17 not reached: the pass budget went to recovering T10 plus T11–T16; T17
  (BaseGenerator generate/postGenerate + Serpulo wiring + the headless tests)
  is untouched and remains for a follow-up pass. PAR-0112 stays open.
* The branch is merged up to main at `e9dc17c2` (no conflicts); main has since
  advanced (I06 pass 8 / I08) — the coordinator's merge will bring it in.

## Ledger changes to report

| Item | After |
|---|---|
| PAR-0144 | verified (T11) |
| PAR-0142 | verified (T13 hex mesh + colours, T14 emissive glow, T15 bloom) -> closeable |
| PAR-0305 | verified (T12 dialog hide fade) |
| PAR-0304 | verified (T9 rename/icon picker + T10 stats dialog) |
| PAR-0303 | verified by pass 2 (T8; merged as `312ac469`) |
| PAR-0306 / new palette item | verified by pass 1 (T1) — recorded in the pass-1 table |
| note | T10: `sector_stats` dialog registered; `playtime_ms`, `destination`, `import_sources`, `lockdown`, `preset_description_key` view fields; item-id row ordering |
| note | T13/T14: `BlockDef.albedo` added; `MeshBuilder.buildHex` port; `MindCampaign.planet_mesh`; T15: planet bloom |
| PAR-0112 | **not touched** (T17 remains; steps 1/2/4 landed in round H) |

## Done criteria

Not met in full: T1–T16 are committed with their checks, suites/goldens/parse
gate are green, and the T10/T7 goldens were regenerated; **T17 remains** for a
follow-up session (the branch is clean and ready for the coordinator merge).

# Pass 4 (session 2, 2026-10-16)

Worktree `Mindustry-Godot-session2`, branch `parity/session-2`, bridge 6980,
display :11. Session started from `main` @ `eeb11c72` (pass-3 merge,
fast-forward). One task remained: **T17 — enemy bases (`BaseGenerator`) for
generated attack sectors (PAR-0112 step 3)**. Commit `88109f11`
(`Fixes PAR-0112: enemy bases (BaseGenerator) for generated attack sectors`,
task id `I04 T17` in the body).

## Per-task status

| Task | Status | Evidence |
|---|---|---|
| T17 enemy bases (BaseGenerator; PAR-0112 step 3) | **done** (headless acceptance + in-engine forced run) | `88109f11`; `runs/20261016-s2-I04-T17/` |

## Commits (`git log --oneline main..HEAD`)

```
88109f11 Fixes PAR-0112: enemy bases (BaseGenerator) for generated attack sectors
```

## Tests (full gate, all green)

```
cargo test -p mind-core --lib maps::generators::base
  -> ok. 4 passed; 0 failed (get_frac_clamps, difficulty_wall_order,
     post_generate_charges_batteries, enemy_base_places_cores_and_parts)
cargo test -p mind-core --lib --features msav-import
  -> ok. 2693 passed; 0 failed; 4 ignored
cargo test -p mind-headless --lib -> ok. 133 passed; 0 failed
cargo test -p mind-gdext --lib    -> ok. 54 passed; 0 failed
cargo clippy -p mind-core -p mind-gdext --all-targets -- -D warnings -> clean
cargo fmt -p mind-core -p mind-gdext -> applied
cargo run -q -p mind-headless -- parity goldens -> 97 PASS / 0 other
bash tools/godot.sh --headless --editor --quit --path client | grep SCRIPT ERROR|Parse Error -> nothing
```

`enemy_base_places_cores_and_parts` uses the real `assets/baseparts` catalog
(skips with a printed note when absent), forces
`SectorGenExtras { threat: 0.5, has_enemy_base: true }` on serpulo sector 1,
and asserts one team-2 core per enemy room, every item at `itemCapacity` on
those cores, and non-core team-2 buildings outside the player core radius.

## In-engine evidence (under `runs/20261016-s2-I04-T17/`, bridge 6980)

* Control — `load_sector("serpulo", 2)` + `start_sector("serpulo", 2)`:
  `get_hud_state()` -> `{"attack": false, "enemyCores": 0.0, "hasCore": true,
  "winWave": 25.0}`.
* Forced — `set_sector_gen_extras("serpulo", 1, 0.5, true, false)` then
  load + start sector 1: `{"attack": true, "enemyCores": 1.0, "hasCore": true,
  "winWave": 0.0}`; `get_group_count("build") = 2265`;
  `building_debug(80,109)` -> team 2 `battery-large`;
  `run_wave()` + `unit_debug_positions()` -> one air-only `flare` at the enemy
  spawn; `core_items_json()` -> serpulo items `1073741823` (the campaign's
  wave-team `fillItems` -> `getMaximumAccepted` = MAX/2 under
  `coreIncinerates`, `Logic.java:552-561`, `CoreBlock.java:749-751`),
  erekir-only items `4000` (the generator's own item fill).
* `inengine-enemy-base.png` / `inengine-enemy-base-wide.png`: team-2 base with
  power links and walls, HUD `Wave 2 / 1 Enemy Remaining`, minimap red enemy
  territory.
* The live log's panic count is 0. The two `$U/crashes/` reports at
  12:43/12:44 are eval-orchestration artifacts (a later eval ran while a
  timed-out eval still held a `MindSimHost` bind: `bind_mut() failed, already
  bound`), not engine-code panics.

## Deviations from Java (each with Java file:line)

* `post_generate` calls `Sim::rebuild_power_graphs` before the node pass:
  Java's `PowerModule` construction gives every power building a fresh
  `PowerGraph`, so `getPotentialLinks` (`PowerNode.java:400-411`) can link
  immediately; the port only merges graphs on the runtime placement path
  (`SimRuntime::set_block_raw`) and `base::generate` places through `WorldCtx`.
* `get_difficulty_wall` sorts with a stable `build_time` comparison (Arc's
  `Seq.sort` is unstable; vanilla wall build times are distinct).
* `Angles.angle`/`angleDist` use std `atan2` (port-wide convention, e.g.
  `logic::ops::angle`) instead of Arc's fast `atn` approximation.
* `any_enemy_core_within` uses Java's strict `Mathf.within` (`<`), not `<=`
  (one-tile boundary fix shared with the ruins pass).
* The path clearing collects one core's clears and applies them after the walk
  (same final set — clears are idempotent); the shared
  `maps::generators::astar::pathfind` keeps the port's deterministic
  tie-breaking rather than Arc's `PQueue` order.
* `get_difficulty_wall` list for serpulo is
  `[scrap-wall, copper-wall, titanium-wall, thorium-wall, surge-wall,
  phase-wall]` (1x1) — `scrap-wall` first because `Wall.buildCostMultiplier =
  6` while `scrap-wall` overrides to 4 (`Blocks.java:1708-1829`).

## Blockers / notes

* None blocking. The in-engine session created sector records/saves for
  serpulo sectors 1 and 2 (preset-less cells) in this session's profile.
* The branch is clean and fully committed; the coordinator's merge brings T17
  to `main`.

## Ledger changes to report

| Item | After |
|---|---|
| PAR-0112 | **verified / closeable**: step 3 (`BaseGenerator`) landed in `88109f11`, steps 1/2/4 in round H; the in-engine forced run covers the item's recorded "to" procedure (launch a non-preset sector and inspect the world) |

## Done criteria

**Met**: every I04 task T1-T17 is committed with its checks (T1-T16 in passes
1-3, T17 here); the suites are green (mind-core 2693 / headless 133 / gdext
54), `parity goldens` is 97 PASS, the Godot parse gate prints nothing, and
T17's acceptance tests plus a live forced-enemy-base sector run are recorded
in `runs/20261016-s2-I04-T17/`. PAR-0112 closes with this pass; PAR-0142,
PAR-0143, PAR-0144 and PAR-0303..0306 were closed in passes 1-3.

